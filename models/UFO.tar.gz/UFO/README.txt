UFO Model for SM EFT

Obscure issues to be aware of if planning on general use (these do not affect the results of TopFitter):

Because of the stupidly large number of Wilson Coefficients in the (non-MFV) SMEFT, four-fermion operator coefficients in particular are not all consistently included (i.e. not all of the possible flavour configurations are represented by distinct Wilson Coefficients). This does not apply to TopFitter, where the _interfering_ four-fermion operators behave as they should. 

However leptonic 4F operators, those with odd flavour configurations (such as in FCNCs) and others which weren't relevant may not be hermitian, as the full set of flavour symmetry properties in their coefficient matrices have not been reflected. Ensuring this for each of these by eye involves populating a few dozen 3x3x3x3 matrices of real and complex parameters in a way that avoids double counting, the conditions for which are different for each of the 4F subclassifications. 

A fully general, consistent implementation of this parameter counting for these cases is something I'll do soon as part of the release of AllYourBasis, where this is taken care of automatically and at the symbolic level.
