# This file was automatically created by FeynRules 2.3.3
# Mathematica version: 9.0 for Linux x86 (64-bit) (February 7, 2013)
# Date: Tue 6 Oct 2015 05:32:50


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



GC_1 = Coupling(name = 'GC_1',
                value = '-(C1lequ*delta*complex(0,1))',
                order = {'NP':2})

GC_2 = Coupling(name = 'GC_2',
                value = 'C1lequ*delta*complex(0,1)',
                order = {'NP':2})

GC_3 = Coupling(name = 'GC_3',
                value = 'C1lq*delta*complex(0,1)',
                order = {'NP':2})

GC_4 = Coupling(name = 'GC_4',
                value = 'C1qd1111*delta*complex(0,1)',
                order = {'NP':2})

GC_5 = Coupling(name = 'GC_5',
                value = 'C1qd1122*delta*complex(0,1)',
                order = {'NP':2})

GC_6 = Coupling(name = 'GC_6',
                value = 'C1qd1133*delta*complex(0,1)',
                order = {'NP':2})

GC_7 = Coupling(name = 'GC_7',
                value = 'C1qd1212*delta*complex(0,1)',
                order = {'NP':2})

GC_8 = Coupling(name = 'GC_8',
                value = 'C1qd1221*delta*complex(0,1)',
                order = {'NP':2})

GC_9 = Coupling(name = 'GC_9',
                value = 'C1qd1313*delta*complex(0,1)',
                order = {'NP':2})

GC_10 = Coupling(name = 'GC_10',
                 value = 'C1qd1331*delta*complex(0,1)',
                 order = {'NP':2})

GC_11 = Coupling(name = 'GC_11',
                 value = 'C1qd2112*delta*complex(0,1)',
                 order = {'NP':2})

GC_12 = Coupling(name = 'GC_12',
                 value = 'C1qd2121*delta*complex(0,1)',
                 order = {'NP':2})

GC_13 = Coupling(name = 'GC_13',
                 value = 'C1qd2211*delta*complex(0,1)',
                 order = {'NP':2})

GC_14 = Coupling(name = 'GC_14',
                 value = 'C1qd2222*delta*complex(0,1)',
                 order = {'NP':2})

GC_15 = Coupling(name = 'GC_15',
                 value = 'C1qd2233*delta*complex(0,1)',
                 order = {'NP':2})

GC_16 = Coupling(name = 'GC_16',
                 value = 'C1qd2323*delta*complex(0,1)',
                 order = {'NP':2})

GC_17 = Coupling(name = 'GC_17',
                 value = 'C1qd2332*delta*complex(0,1)',
                 order = {'NP':2})

GC_18 = Coupling(name = 'GC_18',
                 value = 'C1qd3113*delta*complex(0,1)',
                 order = {'NP':2})

GC_19 = Coupling(name = 'GC_19',
                 value = 'C1qd3131*delta*complex(0,1)',
                 order = {'NP':2})

GC_20 = Coupling(name = 'GC_20',
                 value = 'C1qd3223*delta*complex(0,1)',
                 order = {'NP':2})

GC_21 = Coupling(name = 'GC_21',
                 value = 'C1qd3232*delta*complex(0,1)',
                 order = {'NP':2})

GC_22 = Coupling(name = 'GC_22',
                 value = 'C1qd3311*delta*complex(0,1)',
                 order = {'NP':2})

GC_23 = Coupling(name = 'GC_23',
                 value = 'C1qd3322*delta*complex(0,1)',
                 order = {'NP':2})

GC_24 = Coupling(name = 'GC_24',
                 value = 'C1qd3333*delta*complex(0,1)',
                 order = {'NP':2})

GC_25 = Coupling(name = 'GC_25',
                 value = 'C1qu1111*delta*complex(0,1)',
                 order = {'NP':2})

GC_26 = Coupling(name = 'GC_26',
                 value = 'C1qu1122*delta*complex(0,1)',
                 order = {'NP':2})

GC_27 = Coupling(name = 'GC_27',
                 value = 'C1qu1133*delta*complex(0,1)',
                 order = {'NP':2})

GC_28 = Coupling(name = 'GC_28',
                 value = 'C1qu1212*delta*complex(0,1)',
                 order = {'NP':2})

GC_29 = Coupling(name = 'GC_29',
                 value = 'C1qu1221*delta*complex(0,1)',
                 order = {'NP':2})

GC_30 = Coupling(name = 'GC_30',
                 value = 'C1qu1313*delta*complex(0,1)',
                 order = {'NP':2})

GC_31 = Coupling(name = 'GC_31',
                 value = 'C1qu1331*delta*complex(0,1)',
                 order = {'NP':2})

GC_32 = Coupling(name = 'GC_32',
                 value = 'C1qu2112*delta*complex(0,1)',
                 order = {'NP':2})

GC_33 = Coupling(name = 'GC_33',
                 value = 'C1qu2121*delta*complex(0,1)',
                 order = {'NP':2})

GC_34 = Coupling(name = 'GC_34',
                 value = 'C1qu2211*delta*complex(0,1)',
                 order = {'NP':2})

GC_35 = Coupling(name = 'GC_35',
                 value = 'C1qu2222*delta*complex(0,1)',
                 order = {'NP':2})

GC_36 = Coupling(name = 'GC_36',
                 value = 'C1qu2233*delta*complex(0,1)',
                 order = {'NP':2})

GC_37 = Coupling(name = 'GC_37',
                 value = 'C1qu2323*delta*complex(0,1)',
                 order = {'NP':2})

GC_38 = Coupling(name = 'GC_38',
                 value = 'C1qu2332*delta*complex(0,1)',
                 order = {'NP':2})

GC_39 = Coupling(name = 'GC_39',
                 value = 'C1qu3113*delta*complex(0,1)',
                 order = {'NP':2})

GC_40 = Coupling(name = 'GC_40',
                 value = 'C1qu3131*delta*complex(0,1)',
                 order = {'NP':2})

GC_41 = Coupling(name = 'GC_41',
                 value = 'C1qu3223*delta*complex(0,1)',
                 order = {'NP':2})

GC_42 = Coupling(name = 'GC_42',
                 value = 'C1qu3232*delta*complex(0,1)',
                 order = {'NP':2})

GC_43 = Coupling(name = 'GC_43',
                 value = 'C1qu3311*delta*complex(0,1)',
                 order = {'NP':2})

GC_44 = Coupling(name = 'GC_44',
                 value = 'C1qu3322*delta*complex(0,1)',
                 order = {'NP':2})

GC_45 = Coupling(name = 'GC_45',
                 value = 'C1qu3333*delta*complex(0,1)',
                 order = {'NP':2})

GC_46 = Coupling(name = 'GC_46',
                 value = 'C1ud1111*delta*complex(0,1)',
                 order = {'NP':2})

GC_47 = Coupling(name = 'GC_47',
                 value = 'C1ud1122*delta*complex(0,1)',
                 order = {'NP':2})

GC_48 = Coupling(name = 'GC_48',
                 value = 'C1ud1133*delta*complex(0,1)',
                 order = {'NP':2})

GC_49 = Coupling(name = 'GC_49',
                 value = 'C1ud1212*delta*complex(0,1)',
                 order = {'NP':2})

GC_50 = Coupling(name = 'GC_50',
                 value = 'C1ud1221*delta*complex(0,1)',
                 order = {'NP':2})

GC_51 = Coupling(name = 'GC_51',
                 value = 'C1ud1313*delta*complex(0,1)',
                 order = {'NP':2})

GC_52 = Coupling(name = 'GC_52',
                 value = 'C1ud1331*delta*complex(0,1)',
                 order = {'NP':2})

GC_53 = Coupling(name = 'GC_53',
                 value = 'C1ud2112*delta*complex(0,1)',
                 order = {'NP':2})

GC_54 = Coupling(name = 'GC_54',
                 value = 'C1ud2121*delta*complex(0,1)',
                 order = {'NP':2})

GC_55 = Coupling(name = 'GC_55',
                 value = 'C1ud2211*delta*complex(0,1)',
                 order = {'NP':2})

GC_56 = Coupling(name = 'GC_56',
                 value = 'C1ud2222*delta*complex(0,1)',
                 order = {'NP':2})

GC_57 = Coupling(name = 'GC_57',
                 value = 'C1ud2233*delta*complex(0,1)',
                 order = {'NP':2})

GC_58 = Coupling(name = 'GC_58',
                 value = 'C1ud2323*delta*complex(0,1)',
                 order = {'NP':2})

GC_59 = Coupling(name = 'GC_59',
                 value = 'C1ud2332*delta*complex(0,1)',
                 order = {'NP':2})

GC_60 = Coupling(name = 'GC_60',
                 value = 'C1ud3113*delta*complex(0,1)',
                 order = {'NP':2})

GC_61 = Coupling(name = 'GC_61',
                 value = 'C1ud3131*delta*complex(0,1)',
                 order = {'NP':2})

GC_62 = Coupling(name = 'GC_62',
                 value = 'C1ud3223*delta*complex(0,1)',
                 order = {'NP':2})

GC_63 = Coupling(name = 'GC_63',
                 value = 'C1ud3232*delta*complex(0,1)',
                 order = {'NP':2})

GC_64 = Coupling(name = 'GC_64',
                 value = 'C1ud3311*delta*complex(0,1)',
                 order = {'NP':2})

GC_65 = Coupling(name = 'GC_65',
                 value = 'C1ud3322*delta*complex(0,1)',
                 order = {'NP':2})

GC_66 = Coupling(name = 'GC_66',
                 value = 'C1ud3333*delta*complex(0,1)',
                 order = {'NP':2})

GC_67 = Coupling(name = 'GC_67',
                 value = '-(C3lequ*delta*complex(0,1))',
                 order = {'NP':2})

GC_68 = Coupling(name = 'GC_68',
                 value = 'C3lequ*delta*complex(0,1)',
                 order = {'NP':2})

GC_69 = Coupling(name = 'GC_69',
                 value = '-2*C3lequ*delta*complex(0,1)',
                 order = {'NP':2})

GC_70 = Coupling(name = 'GC_70',
                 value = '2*C3lequ*delta*complex(0,1)',
                 order = {'NP':2})

GC_71 = Coupling(name = 'GC_71',
                 value = 'C3lq*delta*complex(0,1)',
                 order = {'NP':2})

GC_72 = Coupling(name = 'GC_72',
                 value = '2*C3lq*delta*complex(0,1)',
                 order = {'NP':2})

GC_73 = Coupling(name = 'GC_73',
                 value = '4*C3qq1111*delta*complex(0,1)',
                 order = {'NP':2})

GC_74 = Coupling(name = 'GC_74',
                 value = '2*C3qq1122*delta*complex(0,1)',
                 order = {'NP':2})

GC_75 = Coupling(name = 'GC_75',
                 value = '2*C3qq1133*delta*complex(0,1)',
                 order = {'NP':2})

GC_76 = Coupling(name = 'GC_76',
                 value = '2*C3qq1221*delta*complex(0,1)',
                 order = {'NP':2})

GC_77 = Coupling(name = 'GC_77',
                 value = '2*C3qq1331*delta*complex(0,1)',
                 order = {'NP':2})

GC_78 = Coupling(name = 'GC_78',
                 value = '4*C3qq2222*delta*complex(0,1)',
                 order = {'NP':2})

GC_79 = Coupling(name = 'GC_79',
                 value = '2*C3qq2233*delta*complex(0,1)',
                 order = {'NP':2})

GC_80 = Coupling(name = 'GC_80',
                 value = '4*C3qq3333*delta*complex(0,1)',
                 order = {'NP':2})

GC_81 = Coupling(name = 'GC_81',
                 value = 'C8qd1111*delta*complex(0,1)',
                 order = {'NP':2})

GC_82 = Coupling(name = 'GC_82',
                 value = 'C8qd1122*delta*complex(0,1)',
                 order = {'NP':2})

GC_83 = Coupling(name = 'GC_83',
                 value = 'C8qd1133*delta*complex(0,1)',
                 order = {'NP':2})

GC_84 = Coupling(name = 'GC_84',
                 value = 'C8qd1212*delta*complex(0,1)',
                 order = {'NP':2})

GC_85 = Coupling(name = 'GC_85',
                 value = 'C8qd1221*delta*complex(0,1)',
                 order = {'NP':2})

GC_86 = Coupling(name = 'GC_86',
                 value = 'C8qd1313*delta*complex(0,1)',
                 order = {'NP':2})

GC_87 = Coupling(name = 'GC_87',
                 value = 'C8qd1331*delta*complex(0,1)',
                 order = {'NP':2})

GC_88 = Coupling(name = 'GC_88',
                 value = 'C8qd2112*delta*complex(0,1)',
                 order = {'NP':2})

GC_89 = Coupling(name = 'GC_89',
                 value = 'C8qd2121*delta*complex(0,1)',
                 order = {'NP':2})

GC_90 = Coupling(name = 'GC_90',
                 value = 'C8qd2211*delta*complex(0,1)',
                 order = {'NP':2})

GC_91 = Coupling(name = 'GC_91',
                 value = 'C8qd2222*delta*complex(0,1)',
                 order = {'NP':2})

GC_92 = Coupling(name = 'GC_92',
                 value = 'C8qd2233*delta*complex(0,1)',
                 order = {'NP':2})

GC_93 = Coupling(name = 'GC_93',
                 value = 'C8qd2323*delta*complex(0,1)',
                 order = {'NP':2})

GC_94 = Coupling(name = 'GC_94',
                 value = 'C8qd2332*delta*complex(0,1)',
                 order = {'NP':2})

GC_95 = Coupling(name = 'GC_95',
                 value = 'C8qd3113*delta*complex(0,1)',
                 order = {'NP':2})

GC_96 = Coupling(name = 'GC_96',
                 value = 'C8qd3131*delta*complex(0,1)',
                 order = {'NP':2})

GC_97 = Coupling(name = 'GC_97',
                 value = 'C8qd3223*delta*complex(0,1)',
                 order = {'NP':2})

GC_98 = Coupling(name = 'GC_98',
                 value = 'C8qd3232*delta*complex(0,1)',
                 order = {'NP':2})

GC_99 = Coupling(name = 'GC_99',
                 value = 'C8qd3311*delta*complex(0,1)',
                 order = {'NP':2})

GC_100 = Coupling(name = 'GC_100',
                  value = 'C8qd3322*delta*complex(0,1)',
                  order = {'NP':2})

GC_101 = Coupling(name = 'GC_101',
                  value = 'C8qd3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_102 = Coupling(name = 'GC_102',
                  value = 'C8qu1111*delta*complex(0,1)',
                  order = {'NP':2})

GC_103 = Coupling(name = 'GC_103',
                  value = 'C8qu1122*delta*complex(0,1)',
                  order = {'NP':2})

GC_104 = Coupling(name = 'GC_104',
                  value = 'C8qu1133*delta*complex(0,1)',
                  order = {'NP':2})

GC_105 = Coupling(name = 'GC_105',
                  value = 'C8qu1212*delta*complex(0,1)',
                  order = {'NP':2})

GC_106 = Coupling(name = 'GC_106',
                  value = 'C8qu1221*delta*complex(0,1)',
                  order = {'NP':2})

GC_107 = Coupling(name = 'GC_107',
                  value = 'C8qu1313*delta*complex(0,1)',
                  order = {'NP':2})

GC_108 = Coupling(name = 'GC_108',
                  value = 'C8qu1331*delta*complex(0,1)',
                  order = {'NP':2})

GC_109 = Coupling(name = 'GC_109',
                  value = 'C8qu2112*delta*complex(0,1)',
                  order = {'NP':2})

GC_110 = Coupling(name = 'GC_110',
                  value = 'C8qu2121*delta*complex(0,1)',
                  order = {'NP':2})

GC_111 = Coupling(name = 'GC_111',
                  value = 'C8qu2211*delta*complex(0,1)',
                  order = {'NP':2})

GC_112 = Coupling(name = 'GC_112',
                  value = 'C8qu2222*delta*complex(0,1)',
                  order = {'NP':2})

GC_113 = Coupling(name = 'GC_113',
                  value = 'C8qu2233*delta*complex(0,1)',
                  order = {'NP':2})

GC_114 = Coupling(name = 'GC_114',
                  value = 'C8qu2323*delta*complex(0,1)',
                  order = {'NP':2})

GC_115 = Coupling(name = 'GC_115',
                  value = 'C8qu2332*delta*complex(0,1)',
                  order = {'NP':2})

GC_116 = Coupling(name = 'GC_116',
                  value = 'C8qu3113*delta*complex(0,1)',
                  order = {'NP':2})

GC_117 = Coupling(name = 'GC_117',
                  value = 'C8qu3131*delta*complex(0,1)',
                  order = {'NP':2})

GC_118 = Coupling(name = 'GC_118',
                  value = 'C8qu3223*delta*complex(0,1)',
                  order = {'NP':2})

GC_119 = Coupling(name = 'GC_119',
                  value = 'C8qu3232*delta*complex(0,1)',
                  order = {'NP':2})

GC_120 = Coupling(name = 'GC_120',
                  value = 'C8qu3311*delta*complex(0,1)',
                  order = {'NP':2})

GC_121 = Coupling(name = 'GC_121',
                  value = 'C8qu3322*delta*complex(0,1)',
                  order = {'NP':2})

GC_122 = Coupling(name = 'GC_122',
                  value = 'C8qu3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_123 = Coupling(name = 'GC_123',
                  value = 'C8ud1111*delta*complex(0,1)',
                  order = {'NP':2})

GC_124 = Coupling(name = 'GC_124',
                  value = 'C8ud1122*delta*complex(0,1)',
                  order = {'NP':2})

GC_125 = Coupling(name = 'GC_125',
                  value = 'C8ud1133*delta*complex(0,1)',
                  order = {'NP':2})

GC_126 = Coupling(name = 'GC_126',
                  value = 'C8ud1212*delta*complex(0,1)',
                  order = {'NP':2})

GC_127 = Coupling(name = 'GC_127',
                  value = 'C8ud1221*delta*complex(0,1)',
                  order = {'NP':2})

GC_128 = Coupling(name = 'GC_128',
                  value = 'C8ud1313*delta*complex(0,1)',
                  order = {'NP':2})

GC_129 = Coupling(name = 'GC_129',
                  value = 'C8ud1331*delta*complex(0,1)',
                  order = {'NP':2})

GC_130 = Coupling(name = 'GC_130',
                  value = 'C8ud2112*delta*complex(0,1)',
                  order = {'NP':2})

GC_131 = Coupling(name = 'GC_131',
                  value = 'C8ud2121*delta*complex(0,1)',
                  order = {'NP':2})

GC_132 = Coupling(name = 'GC_132',
                  value = 'C8ud2211*delta*complex(0,1)',
                  order = {'NP':2})

GC_133 = Coupling(name = 'GC_133',
                  value = 'C8ud2222*delta*complex(0,1)',
                  order = {'NP':2})

GC_134 = Coupling(name = 'GC_134',
                  value = 'C8ud2233*delta*complex(0,1)',
                  order = {'NP':2})

GC_135 = Coupling(name = 'GC_135',
                  value = 'C8ud2323*delta*complex(0,1)',
                  order = {'NP':2})

GC_136 = Coupling(name = 'GC_136',
                  value = 'C8ud2332*delta*complex(0,1)',
                  order = {'NP':2})

GC_137 = Coupling(name = 'GC_137',
                  value = 'C8ud3113*delta*complex(0,1)',
                  order = {'NP':2})

GC_138 = Coupling(name = 'GC_138',
                  value = 'C8ud3131*delta*complex(0,1)',
                  order = {'NP':2})

GC_139 = Coupling(name = 'GC_139',
                  value = 'C8ud3223*delta*complex(0,1)',
                  order = {'NP':2})

GC_140 = Coupling(name = 'GC_140',
                  value = 'C8ud3232*delta*complex(0,1)',
                  order = {'NP':2})

GC_141 = Coupling(name = 'GC_141',
                  value = 'C8ud3311*delta*complex(0,1)',
                  order = {'NP':2})

GC_142 = Coupling(name = 'GC_142',
                  value = 'C8ud3322*delta*complex(0,1)',
                  order = {'NP':2})

GC_143 = Coupling(name = 'GC_143',
                  value = 'C8ud3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_144 = Coupling(name = 'GC_144',
                  value = '2*Cdd1111*delta*complex(0,1)',
                  order = {'NP':2})

GC_145 = Coupling(name = 'GC_145',
                  value = 'Cdd1122*delta*complex(0,1)',
                  order = {'NP':2})

GC_146 = Coupling(name = 'GC_146',
                  value = 'Cdd1133*delta*complex(0,1)',
                  order = {'NP':2})

GC_147 = Coupling(name = 'GC_147',
                  value = '2*Cdd1212*delta*complex(0,1)',
                  order = {'NP':2})

GC_148 = Coupling(name = 'GC_148',
                  value = 'Cdd1221*delta*complex(0,1)',
                  order = {'NP':2})

GC_149 = Coupling(name = 'GC_149',
                  value = '2*Cdd1313*delta*complex(0,1)',
                  order = {'NP':2})

GC_150 = Coupling(name = 'GC_150',
                  value = 'Cdd1331*delta*complex(0,1)',
                  order = {'NP':2})

GC_151 = Coupling(name = 'GC_151',
                  value = '2*Cdd2121*delta*complex(0,1)',
                  order = {'NP':2})

GC_152 = Coupling(name = 'GC_152',
                  value = '2*Cdd2222*delta*complex(0,1)',
                  order = {'NP':2})

GC_153 = Coupling(name = 'GC_153',
                  value = 'Cdd2233*delta*complex(0,1)',
                  order = {'NP':2})

GC_154 = Coupling(name = 'GC_154',
                  value = '2*Cdd2323*delta*complex(0,1)',
                  order = {'NP':2})

GC_155 = Coupling(name = 'GC_155',
                  value = 'Cdd2332*delta*complex(0,1)',
                  order = {'NP':2})

GC_156 = Coupling(name = 'GC_156',
                  value = '2*Cdd3131*delta*complex(0,1)',
                  order = {'NP':2})

GC_157 = Coupling(name = 'GC_157',
                  value = '2*Cdd3232*delta*complex(0,1)',
                  order = {'NP':2})

GC_158 = Coupling(name = 'GC_158',
                  value = '2*Cdd3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_159 = Coupling(name = 'GC_159',
                  value = 'Ced*delta*complex(0,1)',
                  order = {'NP':2})

GC_160 = Coupling(name = 'GC_160',
                  value = '2*Cee*delta*complex(0,1)',
                  order = {'NP':2})

GC_161 = Coupling(name = 'GC_161',
                  value = '4*Cee*delta*complex(0,1)',
                  order = {'NP':2})

GC_162 = Coupling(name = 'GC_162',
                  value = 'Ceu*delta*complex(0,1)',
                  order = {'NP':2})

GC_163 = Coupling(name = 'GC_163',
                  value = '-6*CG*delta',
                  order = {'NP':2})

GC_164 = Coupling(name = 'GC_164',
                  value = 'Cld*delta*complex(0,1)',
                  order = {'NP':2})

GC_165 = Coupling(name = 'GC_165',
                  value = 'Cle*delta*complex(0,1)',
                  order = {'NP':2})

GC_166 = Coupling(name = 'GC_166',
                  value = 'Cledq*delta*complex(0,1)',
                  order = {'NP':2})

GC_167 = Coupling(name = 'GC_167',
                  value = '2*Cll1111*delta*complex(0,1)',
                  order = {'NP':2})

GC_168 = Coupling(name = 'GC_168',
                  value = 'Cll1122*delta*complex(0,1)',
                  order = {'NP':2})

GC_169 = Coupling(name = 'GC_169',
                  value = 'Cll1133*delta*complex(0,1)',
                  order = {'NP':2})

GC_170 = Coupling(name = 'GC_170',
                  value = '2*Cll2222*delta*complex(0,1)',
                  order = {'NP':2})

GC_171 = Coupling(name = 'GC_171',
                  value = 'Cll2233*delta*complex(0,1)',
                  order = {'NP':2})

GC_172 = Coupling(name = 'GC_172',
                  value = '2*Cll3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_173 = Coupling(name = 'GC_173',
                  value = 'Clu*delta*complex(0,1)',
                  order = {'NP':2})

GC_174 = Coupling(name = 'GC_174',
                  value = '90*CPhi*delta*complex(0,1)',
                  order = {'NP':2,'QED':6})

GC_175 = Coupling(name = 'GC_175',
                  value = '-(CPhiD*delta*complex(0,1))',
                  order = {'NP':2,'QED':4})

GC_176 = Coupling(name = 'GC_176',
                  value = '-3*CPhiDAl*delta*complex(0,1)',
                  order = {'NP':2,'QED':4})

GC_177 = Coupling(name = 'GC_177',
                  value = '4*CPhiG*delta*complex(0,1)',
                  order = {'NP':2,'QED':2})

GC_178 = Coupling(name = 'GC_178',
                  value = '4*CPhiW*delta*complex(0,1)',
                  order = {'NP':2,'QED':2})

GC_179 = Coupling(name = 'GC_179',
                  value = 'Cqe*delta*complex(0,1)',
                  order = {'NP':2})

GC_180 = Coupling(name = 'GC_180',
                  value = '2*Cuu1111*delta*complex(0,1)',
                  order = {'NP':2})

GC_181 = Coupling(name = 'GC_181',
                  value = 'Cuu1122*delta*complex(0,1)',
                  order = {'NP':2})

GC_182 = Coupling(name = 'GC_182',
                  value = 'Cuu1133*delta*complex(0,1)',
                  order = {'NP':2})

GC_183 = Coupling(name = 'GC_183',
                  value = '2*Cuu1212*delta*complex(0,1)',
                  order = {'NP':2})

GC_184 = Coupling(name = 'GC_184',
                  value = 'Cuu1221*delta*complex(0,1)',
                  order = {'NP':2})

GC_185 = Coupling(name = 'GC_185',
                  value = '2*Cuu1313*delta*complex(0,1)',
                  order = {'NP':2})

GC_186 = Coupling(name = 'GC_186',
                  value = 'Cuu1331*delta*complex(0,1)',
                  order = {'NP':2})

GC_187 = Coupling(name = 'GC_187',
                  value = '2*Cuu2121*delta*complex(0,1)',
                  order = {'NP':2})

GC_188 = Coupling(name = 'GC_188',
                  value = '2*Cuu2222*delta*complex(0,1)',
                  order = {'NP':2})

GC_189 = Coupling(name = 'GC_189',
                  value = 'Cuu2233*delta*complex(0,1)',
                  order = {'NP':2})

GC_190 = Coupling(name = 'GC_190',
                  value = '2*Cuu2323*delta*complex(0,1)',
                  order = {'NP':2})

GC_191 = Coupling(name = 'GC_191',
                  value = 'Cuu2332*delta*complex(0,1)',
                  order = {'NP':2})

GC_192 = Coupling(name = 'GC_192',
                  value = '2*Cuu3131*delta*complex(0,1)',
                  order = {'NP':2})

GC_193 = Coupling(name = 'GC_193',
                  value = '2*Cuu3232*delta*complex(0,1)',
                  order = {'NP':2})

GC_194 = Coupling(name = 'GC_194',
                  value = '2*Cuu3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_195 = Coupling(name = 'GC_195',
                  value = '6*CW*cwD6*delta*complex(0,1)',
                  order = {'NP':2})

GC_196 = Coupling(name = 'GC_196',
                  value = 'C1lq*delta*complex(0,1) - C3lq*delta*complex(0,1)',
                  order = {'NP':2})

GC_197 = Coupling(name = 'GC_197',
                  value = 'C1lq*delta*complex(0,1) + C3lq*delta*complex(0,1)',
                  order = {'NP':2})

GC_198 = Coupling(name = 'GC_198',
                  value = '2*C1qq1111*delta*complex(0,1) - 2*C3qq1111*delta*complex(0,1)',
                  order = {'NP':2})

GC_199 = Coupling(name = 'GC_199',
                  value = '2*C1qq1111*delta*complex(0,1) + 2*C3qq1111*delta*complex(0,1)',
                  order = {'NP':2})

GC_200 = Coupling(name = 'GC_200',
                  value = 'C1qq1122*delta*complex(0,1) - C3qq1122*delta*complex(0,1)',
                  order = {'NP':2})

GC_201 = Coupling(name = 'GC_201',
                  value = 'C1qq1122*delta*complex(0,1) + C3qq1122*delta*complex(0,1)',
                  order = {'NP':2})

GC_202 = Coupling(name = 'GC_202',
                  value = 'C1qq1133*delta*complex(0,1) - C3qq1133*delta*complex(0,1)',
                  order = {'NP':2})

GC_203 = Coupling(name = 'GC_203',
                  value = 'C1qq1133*delta*complex(0,1) + C3qq1133*delta*complex(0,1)',
                  order = {'NP':2})

GC_204 = Coupling(name = 'GC_204',
                  value = 'C1qq1221*delta*complex(0,1) - C3qq1221*delta*complex(0,1)',
                  order = {'NP':2})

GC_205 = Coupling(name = 'GC_205',
                  value = 'C1qq1221*delta*complex(0,1) + C3qq1221*delta*complex(0,1)',
                  order = {'NP':2})

GC_206 = Coupling(name = 'GC_206',
                  value = 'C1qq1331*delta*complex(0,1) - C3qq1331*delta*complex(0,1)',
                  order = {'NP':2})

GC_207 = Coupling(name = 'GC_207',
                  value = 'C1qq1331*delta*complex(0,1) + C3qq1331*delta*complex(0,1)',
                  order = {'NP':2})

GC_208 = Coupling(name = 'GC_208',
                  value = '2*C1qq2222*delta*complex(0,1) - 2*C3qq2222*delta*complex(0,1)',
                  order = {'NP':2})

GC_209 = Coupling(name = 'GC_209',
                  value = '2*C1qq2222*delta*complex(0,1) + 2*C3qq2222*delta*complex(0,1)',
                  order = {'NP':2})

GC_210 = Coupling(name = 'GC_210',
                  value = 'C1qq2233*delta*complex(0,1) - C3qq2233*delta*complex(0,1)',
                  order = {'NP':2})

GC_211 = Coupling(name = 'GC_211',
                  value = 'C1qq2233*delta*complex(0,1) + C3qq2233*delta*complex(0,1)',
                  order = {'NP':2})

GC_212 = Coupling(name = 'GC_212',
                  value = '2*C1qq3333*delta*complex(0,1) - 2*C3qq3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_213 = Coupling(name = 'GC_213',
                  value = '2*C1qq3333*delta*complex(0,1) + 2*C3qq3333*delta*complex(0,1)',
                  order = {'NP':2})

GC_214 = Coupling(name = 'GC_214',
                  value = 'Cll1221*delta*complex(0,1) + Cll2112*delta*complex(0,1)',
                  order = {'NP':2})

GC_215 = Coupling(name = 'GC_215',
                  value = 'Cll1122*delta*complex(0,1) + Cll1221*delta*complex(0,1) + Cll2112*delta*complex(0,1)',
                  order = {'NP':2})

GC_216 = Coupling(name = 'GC_216',
                  value = '(cwD6*complex(0,1)*g1D6)/6.',
                  order = {'QED':1})

GC_217 = Coupling(name = 'GC_217',
                  value = '-(cwD6*complex(0,1)*g1D6)/2.',
                  order = {'QED':1})

GC_218 = Coupling(name = 'GC_218',
                  value = '-gsD6',
                  order = {'QCD':1})

GC_219 = Coupling(name = 'GC_219',
                  value = 'complex(0,1)*gsD6',
                  order = {'QCD':1})

GC_220 = Coupling(name = 'GC_220',
                  value = '6*CG*delta*complex(0,1)*gsD6',
                  order = {'NP':2,'QCD':1})

GC_221 = Coupling(name = 'GC_221',
                  value = '4*CPhiG*delta*gsD6',
                  order = {'NP':2,'QCD':1,'QED':2})

GC_222 = Coupling(name = 'GC_222',
                  value = 'complex(0,1)*gsD6**2',
                  order = {'QCD':2})

GC_223 = Coupling(name = 'GC_223',
                  value = '-3*CG*delta*gsD6**2',
                  order = {'NP':2,'QCD':2})

GC_224 = Coupling(name = 'GC_224',
                  value = '3*CG*delta*gsD6**2',
                  order = {'NP':2,'QCD':2})

GC_225 = Coupling(name = 'GC_225',
                  value = '-4*CPhiG*delta*complex(0,1)*gsD6**2',
                  order = {'NP':2,'QCD':2,'QED':2})

GC_226 = Coupling(name = 'GC_226',
                  value = '-(CG*delta*complex(0,1)*gsD6**3)',
                  order = {'NP':2,'QCD':3})

GC_227 = Coupling(name = 'GC_227',
                  value = 'CG*delta*complex(0,1)*gsD6**3',
                  order = {'NP':2,'QCD':3})

GC_228 = Coupling(name = 'GC_228',
                  value = '(complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_229 = Coupling(name = 'GC_229',
                  value = '(CKMD61x1*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_230 = Coupling(name = 'GC_230',
                  value = '(CKMD61x2*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_231 = Coupling(name = 'GC_231',
                  value = '(CKMD61x3*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_232 = Coupling(name = 'GC_232',
                  value = '(CKMD62x1*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_233 = Coupling(name = 'GC_233',
                  value = '(CKMD62x2*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_234 = Coupling(name = 'GC_234',
                  value = '(CKMD62x3*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_235 = Coupling(name = 'GC_235',
                  value = '(CKMD63x1*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_236 = Coupling(name = 'GC_236',
                  value = '(CKMD63x2*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_237 = Coupling(name = 'GC_237',
                  value = '(CKMD63x3*complex(0,1)*gwD6)/cmath.sqrt(2)',
                  order = {'QED':1})

GC_238 = Coupling(name = 'GC_238',
                  value = '-(cwD6*complex(0,1)*gwD6)/2.',
                  order = {'QED':1})

GC_239 = Coupling(name = 'GC_239',
                  value = '(cwD6*complex(0,1)*gwD6)/2.',
                  order = {'QED':1})

GC_240 = Coupling(name = 'GC_240',
                  value = 'cwD6*complex(0,1)*gwD6',
                  order = {'QED':1})

GC_241 = Coupling(name = 'GC_241',
                  value = '-6*CW*delta*complex(0,1)*gwD6',
                  order = {'NP':2,'QED':1})

GC_242 = Coupling(name = 'GC_242',
                  value = '-4*CPhiW*cwD6*delta*complex(0,1)*gwD6',
                  order = {'NP':2,'QED':3})

GC_243 = Coupling(name = 'GC_243',
                  value = '2*CPhiWB*cwD6*delta*complex(0,1)*gwD6',
                  order = {'NP':2,'QED':3})

GC_244 = Coupling(name = 'GC_244',
                  value = '6*CW*cwD6**2*delta*complex(0,1)*gwD6',
                  order = {'NP':2,'QED':1})

GC_245 = Coupling(name = 'GC_245',
                  value = '(complex(0,1)*gwD6**2)/2.',
                  order = {'QED':2})

GC_246 = Coupling(name = 'GC_246',
                  value = '-(complex(0,1)*gwD6**2)',
                  order = {'QED':2})

GC_247 = Coupling(name = 'GC_247',
                  value = 'cwD6**2*complex(0,1)*gwD6**2',
                  order = {'QED':2})

GC_248 = Coupling(name = 'GC_248',
                  value = '4*CPhiW*delta*complex(0,1)*gwD6**2',
                  order = {'NP':2,'QED':4})

GC_249 = Coupling(name = 'GC_249',
                  value = '-6*CW*cwD6*delta*complex(0,1)*gwD6**2',
                  order = {'NP':2,'QED':2})

GC_250 = Coupling(name = 'GC_250',
                  value = '-4*CPhiW*cwD6**2*delta*complex(0,1)*gwD6**2',
                  order = {'NP':2,'QED':4})

GC_251 = Coupling(name = 'GC_251',
                  value = '-6*CW*cwD6**3*delta*complex(0,1)*gwD6**2',
                  order = {'NP':2,'QED':2})

GC_252 = Coupling(name = 'GC_252',
                  value = '24*CW*cwD6**2*delta*complex(0,1)*gwD6**3',
                  order = {'NP':2,'QED':3})

GC_253 = Coupling(name = 'GC_253',
                  value = '(cwD6*delta*ImCdB33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_254 = Coupling(name = 'GC_254',
                  value = '(delta*ImCdG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_255 = Coupling(name = 'GC_255',
                  value = '(delta*ImCdG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_256 = Coupling(name = 'GC_256',
                  value = '(delta*ImCdG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_257 = Coupling(name = 'GC_257',
                  value = '(delta*complex(0,1)*gsD6*ImCdG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_258 = Coupling(name = 'GC_258',
                  value = '(3*delta*ImCdPhi11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_259 = Coupling(name = 'GC_259',
                  value = '(3*delta*ImCdPhi22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_260 = Coupling(name = 'GC_260',
                  value = '(3*delta*ImCdPhi33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_261 = Coupling(name = 'GC_261',
                  value = '-(cwD6*delta*gwD6*ImCdW22)',
                  order = {'NP':2,'QED':2})

GC_262 = Coupling(name = 'GC_262',
                  value = '(3*delta*ImCePhi11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_263 = Coupling(name = 'GC_263',
                  value = '(3*delta*ImCePhi22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_264 = Coupling(name = 'GC_264',
                  value = '(3*delta*ImCePhi33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_265 = Coupling(name = 'GC_265',
                  value = '(3*delta*ImCuPhi11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_266 = Coupling(name = 'GC_266',
                  value = '(3*delta*ImCuPhi22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_267 = Coupling(name = 'GC_267',
                  value = '(3*delta*ImCuPhi33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_268 = Coupling(name = 'GC_268',
                  value = '-6*complex(0,1)*lam',
                  order = {'QED':2})

GC_269 = Coupling(name = 'GC_269',
                  value = 'delta*complex(0,1)*gwD6*ReC1Phil33*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_270 = Coupling(name = 'GC_270',
                  value = '-(delta*ImC1quqd1133) - delta*complex(0,1)*ReC1quqd1133',
                  order = {'NP':2})

GC_271 = Coupling(name = 'GC_271',
                  value = 'delta*ImC1quqd1133 - delta*complex(0,1)*ReC1quqd1133',
                  order = {'NP':2})

GC_272 = Coupling(name = 'GC_272',
                  value = '-(delta*ImC1quqd1133) + delta*complex(0,1)*ReC1quqd1133',
                  order = {'NP':2})

GC_273 = Coupling(name = 'GC_273',
                  value = 'delta*ImC1quqd1133 + delta*complex(0,1)*ReC1quqd1133',
                  order = {'NP':2})

GC_274 = Coupling(name = 'GC_274',
                  value = '-(delta*ImC1quqd1313) - delta*complex(0,1)*ReC1quqd1313',
                  order = {'NP':2})

GC_275 = Coupling(name = 'GC_275',
                  value = 'delta*ImC1quqd1313 - delta*complex(0,1)*ReC1quqd1313',
                  order = {'NP':2})

GC_276 = Coupling(name = 'GC_276',
                  value = '-(delta*ImC1quqd1313) + delta*complex(0,1)*ReC1quqd1313',
                  order = {'NP':2})

GC_277 = Coupling(name = 'GC_277',
                  value = 'delta*ImC1quqd1313 + delta*complex(0,1)*ReC1quqd1313',
                  order = {'NP':2})

GC_278 = Coupling(name = 'GC_278',
                  value = '-(delta*ImC1quqd1331) - delta*complex(0,1)*ReC1quqd1331',
                  order = {'NP':2})

GC_279 = Coupling(name = 'GC_279',
                  value = 'delta*ImC1quqd1331 - delta*complex(0,1)*ReC1quqd1331',
                  order = {'NP':2})

GC_280 = Coupling(name = 'GC_280',
                  value = '-(delta*ImC1quqd1331) + delta*complex(0,1)*ReC1quqd1331',
                  order = {'NP':2})

GC_281 = Coupling(name = 'GC_281',
                  value = 'delta*ImC1quqd1331 + delta*complex(0,1)*ReC1quqd1331',
                  order = {'NP':2})

GC_282 = Coupling(name = 'GC_282',
                  value = '-(delta*ImC1quqd3113) - delta*complex(0,1)*ReC1quqd3113',
                  order = {'NP':2})

GC_283 = Coupling(name = 'GC_283',
                  value = 'delta*ImC1quqd3113 - delta*complex(0,1)*ReC1quqd3113',
                  order = {'NP':2})

GC_284 = Coupling(name = 'GC_284',
                  value = '-(delta*ImC1quqd3113) + delta*complex(0,1)*ReC1quqd3113',
                  order = {'NP':2})

GC_285 = Coupling(name = 'GC_285',
                  value = 'delta*ImC1quqd3113 + delta*complex(0,1)*ReC1quqd3113',
                  order = {'NP':2})

GC_286 = Coupling(name = 'GC_286',
                  value = '-(delta*ImC1quqd3131) - delta*complex(0,1)*ReC1quqd3131',
                  order = {'NP':2})

GC_287 = Coupling(name = 'GC_287',
                  value = 'delta*ImC1quqd3131 - delta*complex(0,1)*ReC1quqd3131',
                  order = {'NP':2})

GC_288 = Coupling(name = 'GC_288',
                  value = '-(delta*ImC1quqd3131) + delta*complex(0,1)*ReC1quqd3131',
                  order = {'NP':2})

GC_289 = Coupling(name = 'GC_289',
                  value = 'delta*ImC1quqd3131 + delta*complex(0,1)*ReC1quqd3131',
                  order = {'NP':2})

GC_290 = Coupling(name = 'GC_290',
                  value = '-(delta*ImC1quqd3311) - delta*complex(0,1)*ReC1quqd3311',
                  order = {'NP':2})

GC_291 = Coupling(name = 'GC_291',
                  value = 'delta*ImC1quqd3311 - delta*complex(0,1)*ReC1quqd3311',
                  order = {'NP':2})

GC_292 = Coupling(name = 'GC_292',
                  value = '-(delta*ImC1quqd3311) + delta*complex(0,1)*ReC1quqd3311',
                  order = {'NP':2})

GC_293 = Coupling(name = 'GC_293',
                  value = 'delta*ImC1quqd3311 + delta*complex(0,1)*ReC1quqd3311',
                  order = {'NP':2})

GC_294 = Coupling(name = 'GC_294',
                  value = 'delta*complex(0,1)*gwD6*ReC3Phil11*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_295 = Coupling(name = 'GC_295',
                  value = 'delta*complex(0,1)*gwD6*ReC3Phil22*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_296 = Coupling(name = 'GC_296',
                  value = 'delta*complex(0,1)*gwD6*ReC3Phiq11*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_297 = Coupling(name = 'GC_297',
                  value = '-(delta*gwD6*ImC3Phiq12*cmath.sqrt(2)) + delta*complex(0,1)*gwD6*ReC3Phiq12*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_298 = Coupling(name = 'GC_298',
                  value = 'delta*gwD6*ImC3Phiq12*cmath.sqrt(2) + delta*complex(0,1)*gwD6*ReC3Phiq12*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_299 = Coupling(name = 'GC_299',
                  value = '-(delta*gwD6*ImC3Phiq13*cmath.sqrt(2)) + delta*complex(0,1)*gwD6*ReC3Phiq13*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_300 = Coupling(name = 'GC_300',
                  value = 'delta*gwD6*ImC3Phiq13*cmath.sqrt(2) + delta*complex(0,1)*gwD6*ReC3Phiq13*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_301 = Coupling(name = 'GC_301',
                  value = 'delta*complex(0,1)*gwD6*ReC3Phiq22*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_302 = Coupling(name = 'GC_302',
                  value = '-(delta*gwD6*ImC3Phiq23*cmath.sqrt(2)) + delta*complex(0,1)*gwD6*ReC3Phiq23*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_303 = Coupling(name = 'GC_303',
                  value = 'delta*gwD6*ImC3Phiq23*cmath.sqrt(2) + delta*complex(0,1)*gwD6*ReC3Phiq23*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_304 = Coupling(name = 'GC_304',
                  value = 'delta*complex(0,1)*gwD6*ReC3Phiq33*cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_305 = Coupling(name = 'GC_305',
                  value = '-(delta*ImC8quqd1133) - delta*complex(0,1)*ReC8quqd1133',
                  order = {'NP':2})

GC_306 = Coupling(name = 'GC_306',
                  value = 'delta*ImC8quqd1133 - delta*complex(0,1)*ReC8quqd1133',
                  order = {'NP':2})

GC_307 = Coupling(name = 'GC_307',
                  value = '-(delta*ImC8quqd1133) + delta*complex(0,1)*ReC8quqd1133',
                  order = {'NP':2})

GC_308 = Coupling(name = 'GC_308',
                  value = 'delta*ImC8quqd1133 + delta*complex(0,1)*ReC8quqd1133',
                  order = {'NP':2})

GC_309 = Coupling(name = 'GC_309',
                  value = '-(delta*ImC8quqd1313) - delta*complex(0,1)*ReC8quqd1313',
                  order = {'NP':2})

GC_310 = Coupling(name = 'GC_310',
                  value = 'delta*ImC8quqd1313 - delta*complex(0,1)*ReC8quqd1313',
                  order = {'NP':2})

GC_311 = Coupling(name = 'GC_311',
                  value = '-(delta*ImC8quqd1313) + delta*complex(0,1)*ReC8quqd1313',
                  order = {'NP':2})

GC_312 = Coupling(name = 'GC_312',
                  value = 'delta*ImC8quqd1313 + delta*complex(0,1)*ReC8quqd1313',
                  order = {'NP':2})

GC_313 = Coupling(name = 'GC_313',
                  value = '-(delta*ImC8quqd1331) - delta*complex(0,1)*ReC8quqd1331',
                  order = {'NP':2})

GC_314 = Coupling(name = 'GC_314',
                  value = 'delta*ImC8quqd1331 - delta*complex(0,1)*ReC8quqd1331',
                  order = {'NP':2})

GC_315 = Coupling(name = 'GC_315',
                  value = '-(delta*ImC8quqd1331) + delta*complex(0,1)*ReC8quqd1331',
                  order = {'NP':2})

GC_316 = Coupling(name = 'GC_316',
                  value = 'delta*ImC8quqd1331 + delta*complex(0,1)*ReC8quqd1331',
                  order = {'NP':2})

GC_317 = Coupling(name = 'GC_317',
                  value = '-(delta*ImC8quqd3113) - delta*complex(0,1)*ReC8quqd3113',
                  order = {'NP':2})

GC_318 = Coupling(name = 'GC_318',
                  value = 'delta*ImC8quqd3113 - delta*complex(0,1)*ReC8quqd3113',
                  order = {'NP':2})

GC_319 = Coupling(name = 'GC_319',
                  value = '-(delta*ImC8quqd3113) + delta*complex(0,1)*ReC8quqd3113',
                  order = {'NP':2})

GC_320 = Coupling(name = 'GC_320',
                  value = 'delta*ImC8quqd3113 + delta*complex(0,1)*ReC8quqd3113',
                  order = {'NP':2})

GC_321 = Coupling(name = 'GC_321',
                  value = '-(delta*ImC8quqd3131) - delta*complex(0,1)*ReC8quqd3131',
                  order = {'NP':2})

GC_322 = Coupling(name = 'GC_322',
                  value = 'delta*ImC8quqd3131 - delta*complex(0,1)*ReC8quqd3131',
                  order = {'NP':2})

GC_323 = Coupling(name = 'GC_323',
                  value = '-(delta*ImC8quqd3131) + delta*complex(0,1)*ReC8quqd3131',
                  order = {'NP':2})

GC_324 = Coupling(name = 'GC_324',
                  value = 'delta*ImC8quqd3131 + delta*complex(0,1)*ReC8quqd3131',
                  order = {'NP':2})

GC_325 = Coupling(name = 'GC_325',
                  value = '-(delta*ImC8quqd3311) - delta*complex(0,1)*ReC8quqd3311',
                  order = {'NP':2})

GC_326 = Coupling(name = 'GC_326',
                  value = 'delta*ImC8quqd3311 - delta*complex(0,1)*ReC8quqd3311',
                  order = {'NP':2})

GC_327 = Coupling(name = 'GC_327',
                  value = '-(delta*ImC8quqd3311) + delta*complex(0,1)*ReC8quqd3311',
                  order = {'NP':2})

GC_328 = Coupling(name = 'GC_328',
                  value = 'delta*ImC8quqd3311 + delta*complex(0,1)*ReC8quqd3311',
                  order = {'NP':2})

GC_329 = Coupling(name = 'GC_329',
                  value = '(cwD6*delta*complex(0,1)*ReCdB13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_330 = Coupling(name = 'GC_330',
                  value = '(delta*complex(0,1)*ReCdG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_331 = Coupling(name = 'GC_331',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG11)/cmath.sqrt(2)) - (delta*gsD6*ReCdG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_332 = Coupling(name = 'GC_332',
                  value = '(delta*complex(0,1)*gsD6*ImCdG11)/cmath.sqrt(2) - (delta*gsD6*ReCdG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_333 = Coupling(name = 'GC_333',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG11)/cmath.sqrt(2)) + (delta*gsD6*ReCdG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_334 = Coupling(name = 'GC_334',
                  value = '(delta*complex(0,1)*gsD6*ImCdG11)/cmath.sqrt(2) + (delta*gsD6*ReCdG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_335 = Coupling(name = 'GC_335',
                  value = '-((delta*ImCdG12)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_336 = Coupling(name = 'GC_336',
                  value = '(delta*ImCdG12)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_337 = Coupling(name = 'GC_337',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG12)/cmath.sqrt(2)) - (delta*gsD6*ReCdG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_338 = Coupling(name = 'GC_338',
                  value = '(delta*complex(0,1)*gsD6*ImCdG12)/cmath.sqrt(2) - (delta*gsD6*ReCdG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_339 = Coupling(name = 'GC_339',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG12)/cmath.sqrt(2)) + (delta*gsD6*ReCdG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_340 = Coupling(name = 'GC_340',
                  value = '(delta*complex(0,1)*gsD6*ImCdG12)/cmath.sqrt(2) + (delta*gsD6*ReCdG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_341 = Coupling(name = 'GC_341',
                  value = '-((delta*ImCdG13)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_342 = Coupling(name = 'GC_342',
                  value = '(delta*ImCdG13)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_343 = Coupling(name = 'GC_343',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG13)/cmath.sqrt(2)) - (delta*gsD6*ReCdG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_344 = Coupling(name = 'GC_344',
                  value = '(delta*complex(0,1)*gsD6*ImCdG13)/cmath.sqrt(2) - (delta*gsD6*ReCdG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_345 = Coupling(name = 'GC_345',
                  value = '(delta*complex(0,1)*gsD6*ImCdG13)/cmath.sqrt(2) + (delta*gsD6*ReCdG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_346 = Coupling(name = 'GC_346',
                  value = '-((delta*ImCdG21)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_347 = Coupling(name = 'GC_347',
                  value = '(delta*ImCdG21)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_348 = Coupling(name = 'GC_348',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG21)/cmath.sqrt(2)) - (delta*gsD6*ReCdG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_349 = Coupling(name = 'GC_349',
                  value = '(delta*complex(0,1)*gsD6*ImCdG21)/cmath.sqrt(2) - (delta*gsD6*ReCdG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_350 = Coupling(name = 'GC_350',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG21)/cmath.sqrt(2)) + (delta*gsD6*ReCdG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_351 = Coupling(name = 'GC_351',
                  value = '(delta*complex(0,1)*gsD6*ImCdG21)/cmath.sqrt(2) + (delta*gsD6*ReCdG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_352 = Coupling(name = 'GC_352',
                  value = '(delta*complex(0,1)*ReCdG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_353 = Coupling(name = 'GC_353',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG22)/cmath.sqrt(2)) - (delta*gsD6*ReCdG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_354 = Coupling(name = 'GC_354',
                  value = '(delta*complex(0,1)*gsD6*ImCdG22)/cmath.sqrt(2) - (delta*gsD6*ReCdG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_355 = Coupling(name = 'GC_355',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG22)/cmath.sqrt(2)) + (delta*gsD6*ReCdG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_356 = Coupling(name = 'GC_356',
                  value = '(delta*complex(0,1)*gsD6*ImCdG22)/cmath.sqrt(2) + (delta*gsD6*ReCdG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_357 = Coupling(name = 'GC_357',
                  value = '-((delta*ImCdG23)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_358 = Coupling(name = 'GC_358',
                  value = '(delta*ImCdG23)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_359 = Coupling(name = 'GC_359',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG23)/cmath.sqrt(2)) - (delta*gsD6*ReCdG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_360 = Coupling(name = 'GC_360',
                  value = '(delta*complex(0,1)*gsD6*ImCdG23)/cmath.sqrt(2) - (delta*gsD6*ReCdG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_361 = Coupling(name = 'GC_361',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG23)/cmath.sqrt(2)) + (delta*gsD6*ReCdG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_362 = Coupling(name = 'GC_362',
                  value = '(delta*complex(0,1)*gsD6*ImCdG23)/cmath.sqrt(2) + (delta*gsD6*ReCdG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_363 = Coupling(name = 'GC_363',
                  value = '-((delta*ImCdG31)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_364 = Coupling(name = 'GC_364',
                  value = '(delta*ImCdG31)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_365 = Coupling(name = 'GC_365',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG31)/cmath.sqrt(2)) - (delta*gsD6*ReCdG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_366 = Coupling(name = 'GC_366',
                  value = '(delta*complex(0,1)*gsD6*ImCdG31)/cmath.sqrt(2) - (delta*gsD6*ReCdG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_367 = Coupling(name = 'GC_367',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG31)/cmath.sqrt(2)) + (delta*gsD6*ReCdG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_368 = Coupling(name = 'GC_368',
                  value = '-((delta*ImCdG32)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_369 = Coupling(name = 'GC_369',
                  value = '(delta*ImCdG32)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_370 = Coupling(name = 'GC_370',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG32)/cmath.sqrt(2)) - (delta*gsD6*ReCdG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_371 = Coupling(name = 'GC_371',
                  value = '(delta*complex(0,1)*gsD6*ImCdG32)/cmath.sqrt(2) - (delta*gsD6*ReCdG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_372 = Coupling(name = 'GC_372',
                  value = '-((delta*complex(0,1)*gsD6*ImCdG32)/cmath.sqrt(2)) + (delta*gsD6*ReCdG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_373 = Coupling(name = 'GC_373',
                  value = '(delta*complex(0,1)*gsD6*ImCdG32)/cmath.sqrt(2) + (delta*gsD6*ReCdG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_374 = Coupling(name = 'GC_374',
                  value = '(delta*complex(0,1)*ReCdG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_375 = Coupling(name = 'GC_375',
                  value = '-((delta*gsD6*ReCdG33)/cmath.sqrt(2))',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_376 = Coupling(name = 'GC_376',
                  value = '(3*delta*complex(0,1)*ReCdPhi11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_377 = Coupling(name = 'GC_377',
                  value = '(-3*delta*ImCdPhi12)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_378 = Coupling(name = 'GC_378',
                  value = '(3*delta*ImCdPhi12)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_379 = Coupling(name = 'GC_379',
                  value = '(-3*delta*ImCdPhi13)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_380 = Coupling(name = 'GC_380',
                  value = '(3*delta*ImCdPhi13)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_381 = Coupling(name = 'GC_381',
                  value = '(-3*delta*ImCdPhi21)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_382 = Coupling(name = 'GC_382',
                  value = '(3*delta*ImCdPhi21)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_383 = Coupling(name = 'GC_383',
                  value = '(3*delta*complex(0,1)*ReCdPhi22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_384 = Coupling(name = 'GC_384',
                  value = '(-3*delta*ImCdPhi23)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_385 = Coupling(name = 'GC_385',
                  value = '(3*delta*ImCdPhi23)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_386 = Coupling(name = 'GC_386',
                  value = '(-3*delta*ImCdPhi31)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_387 = Coupling(name = 'GC_387',
                  value = '(3*delta*ImCdPhi31)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_388 = Coupling(name = 'GC_388',
                  value = '(-3*delta*ImCdPhi32)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_389 = Coupling(name = 'GC_389',
                  value = '(3*delta*ImCdPhi32)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_390 = Coupling(name = 'GC_390',
                  value = '(3*delta*complex(0,1)*ReCdPhi33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_391 = Coupling(name = 'GC_391',
                  value = '-(delta*ImCdW11) + delta*complex(0,1)*ReCdW11',
                  order = {'NP':2,'QED':1})

GC_392 = Coupling(name = 'GC_392',
                  value = 'delta*ImCdW11 + delta*complex(0,1)*ReCdW11',
                  order = {'NP':2,'QED':1})

GC_393 = Coupling(name = 'GC_393',
                  value = '-((delta*gwD6*ImCdW11)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_394 = Coupling(name = 'GC_394',
                  value = '(delta*gwD6*ImCdW11)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_395 = Coupling(name = 'GC_395',
                  value = '-((delta*gwD6*ImCdW11)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_396 = Coupling(name = 'GC_396',
                  value = '(delta*gwD6*ImCdW11)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_397 = Coupling(name = 'GC_397',
                  value = '-(cwD6*delta*gwD6*ImCdW11) - cwD6*delta*complex(0,1)*gwD6*ReCdW11',
                  order = {'NP':2,'QED':2})

GC_398 = Coupling(name = 'GC_398',
                  value = 'cwD6*delta*gwD6*ImCdW11 - cwD6*delta*complex(0,1)*gwD6*ReCdW11',
                  order = {'NP':2,'QED':2})

GC_399 = Coupling(name = 'GC_399',
                  value = '-(cwD6*delta*gwD6*ImCdW11) + cwD6*delta*complex(0,1)*gwD6*ReCdW11',
                  order = {'NP':2,'QED':2})

GC_400 = Coupling(name = 'GC_400',
                  value = 'cwD6*delta*gwD6*ImCdW11 + cwD6*delta*complex(0,1)*gwD6*ReCdW11',
                  order = {'NP':2,'QED':2})

GC_401 = Coupling(name = 'GC_401',
                  value = '-(delta*ImCdW12) + delta*complex(0,1)*ReCdW12',
                  order = {'NP':2,'QED':1})

GC_402 = Coupling(name = 'GC_402',
                  value = 'delta*ImCdW12 + delta*complex(0,1)*ReCdW12',
                  order = {'NP':2,'QED':1})

GC_403 = Coupling(name = 'GC_403',
                  value = '-((delta*gwD6*ImCdW12)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_404 = Coupling(name = 'GC_404',
                  value = '(delta*gwD6*ImCdW12)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_405 = Coupling(name = 'GC_405',
                  value = '-((delta*gwD6*ImCdW12)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_406 = Coupling(name = 'GC_406',
                  value = '(delta*gwD6*ImCdW12)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_407 = Coupling(name = 'GC_407',
                  value = '-(cwD6*delta*gwD6*ImCdW12) - cwD6*delta*complex(0,1)*gwD6*ReCdW12',
                  order = {'NP':2,'QED':2})

GC_408 = Coupling(name = 'GC_408',
                  value = 'cwD6*delta*gwD6*ImCdW12 - cwD6*delta*complex(0,1)*gwD6*ReCdW12',
                  order = {'NP':2,'QED':2})

GC_409 = Coupling(name = 'GC_409',
                  value = '-(cwD6*delta*gwD6*ImCdW12) + cwD6*delta*complex(0,1)*gwD6*ReCdW12',
                  order = {'NP':2,'QED':2})

GC_410 = Coupling(name = 'GC_410',
                  value = 'cwD6*delta*gwD6*ImCdW12 + cwD6*delta*complex(0,1)*gwD6*ReCdW12',
                  order = {'NP':2,'QED':2})

GC_411 = Coupling(name = 'GC_411',
                  value = '-(delta*ImCdW13) + delta*complex(0,1)*ReCdW13',
                  order = {'NP':2,'QED':1})

GC_412 = Coupling(name = 'GC_412',
                  value = 'delta*ImCdW13 + delta*complex(0,1)*ReCdW13',
                  order = {'NP':2,'QED':1})

GC_413 = Coupling(name = 'GC_413',
                  value = '-((delta*gwD6*ImCdW13)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_414 = Coupling(name = 'GC_414',
                  value = '(delta*gwD6*ImCdW13)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_415 = Coupling(name = 'GC_415',
                  value = '-((delta*gwD6*ImCdW13)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_416 = Coupling(name = 'GC_416',
                  value = '(delta*gwD6*ImCdW13)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_417 = Coupling(name = 'GC_417',
                  value = '-(cwD6*delta*gwD6*ImCdW13) - cwD6*delta*complex(0,1)*gwD6*ReCdW13',
                  order = {'NP':2,'QED':2})

GC_418 = Coupling(name = 'GC_418',
                  value = 'cwD6*delta*gwD6*ImCdW13 - cwD6*delta*complex(0,1)*gwD6*ReCdW13',
                  order = {'NP':2,'QED':2})

GC_419 = Coupling(name = 'GC_419',
                  value = '-(cwD6*delta*gwD6*ImCdW13) + cwD6*delta*complex(0,1)*gwD6*ReCdW13',
                  order = {'NP':2,'QED':2})

GC_420 = Coupling(name = 'GC_420',
                  value = 'cwD6*delta*gwD6*ImCdW13 + cwD6*delta*complex(0,1)*gwD6*ReCdW13',
                  order = {'NP':2,'QED':2})

GC_421 = Coupling(name = 'GC_421',
                  value = '-(delta*ImCdW21) + delta*complex(0,1)*ReCdW21',
                  order = {'NP':2,'QED':1})

GC_422 = Coupling(name = 'GC_422',
                  value = 'delta*ImCdW21 + delta*complex(0,1)*ReCdW21',
                  order = {'NP':2,'QED':1})

GC_423 = Coupling(name = 'GC_423',
                  value = '-((delta*gwD6*ImCdW21)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_424 = Coupling(name = 'GC_424',
                  value = '(delta*gwD6*ImCdW21)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_425 = Coupling(name = 'GC_425',
                  value = '-((delta*gwD6*ImCdW21)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_426 = Coupling(name = 'GC_426',
                  value = '(delta*gwD6*ImCdW21)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_427 = Coupling(name = 'GC_427',
                  value = '-(cwD6*delta*gwD6*ImCdW21) - cwD6*delta*complex(0,1)*gwD6*ReCdW21',
                  order = {'NP':2,'QED':2})

GC_428 = Coupling(name = 'GC_428',
                  value = 'cwD6*delta*gwD6*ImCdW21 - cwD6*delta*complex(0,1)*gwD6*ReCdW21',
                  order = {'NP':2,'QED':2})

GC_429 = Coupling(name = 'GC_429',
                  value = '-(cwD6*delta*gwD6*ImCdW21) + cwD6*delta*complex(0,1)*gwD6*ReCdW21',
                  order = {'NP':2,'QED':2})

GC_430 = Coupling(name = 'GC_430',
                  value = 'cwD6*delta*gwD6*ImCdW21 + cwD6*delta*complex(0,1)*gwD6*ReCdW21',
                  order = {'NP':2,'QED':2})

GC_431 = Coupling(name = 'GC_431',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReCdW22)',
                  order = {'NP':2,'QED':2})

GC_432 = Coupling(name = 'GC_432',
                  value = '-(delta*ImCdW22) + delta*complex(0,1)*ReCdW22',
                  order = {'NP':2,'QED':1})

GC_433 = Coupling(name = 'GC_433',
                  value = 'delta*ImCdW22 + delta*complex(0,1)*ReCdW22',
                  order = {'NP':2,'QED':1})

GC_434 = Coupling(name = 'GC_434',
                  value = '-((delta*gwD6*ImCdW22)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_435 = Coupling(name = 'GC_435',
                  value = '(delta*gwD6*ImCdW22)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_436 = Coupling(name = 'GC_436',
                  value = '-((delta*gwD6*ImCdW22)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_437 = Coupling(name = 'GC_437',
                  value = '(delta*gwD6*ImCdW22)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_438 = Coupling(name = 'GC_438',
                  value = 'cwD6*delta*gwD6*ImCdW22 - cwD6*delta*complex(0,1)*gwD6*ReCdW22',
                  order = {'NP':2,'QED':2})

GC_439 = Coupling(name = 'GC_439',
                  value = '-(cwD6*delta*gwD6*ImCdW22) + cwD6*delta*complex(0,1)*gwD6*ReCdW22',
                  order = {'NP':2,'QED':2})

GC_440 = Coupling(name = 'GC_440',
                  value = 'cwD6*delta*gwD6*ImCdW22 + cwD6*delta*complex(0,1)*gwD6*ReCdW22',
                  order = {'NP':2,'QED':2})

GC_441 = Coupling(name = 'GC_441',
                  value = '-(delta*ImCdW23) + delta*complex(0,1)*ReCdW23',
                  order = {'NP':2,'QED':1})

GC_442 = Coupling(name = 'GC_442',
                  value = 'delta*ImCdW23 + delta*complex(0,1)*ReCdW23',
                  order = {'NP':2,'QED':1})

GC_443 = Coupling(name = 'GC_443',
                  value = '-((delta*gwD6*ImCdW23)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_444 = Coupling(name = 'GC_444',
                  value = '(delta*gwD6*ImCdW23)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_445 = Coupling(name = 'GC_445',
                  value = '-((delta*gwD6*ImCdW23)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_446 = Coupling(name = 'GC_446',
                  value = '(delta*gwD6*ImCdW23)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_447 = Coupling(name = 'GC_447',
                  value = '-(cwD6*delta*gwD6*ImCdW23) - cwD6*delta*complex(0,1)*gwD6*ReCdW23',
                  order = {'NP':2,'QED':2})

GC_448 = Coupling(name = 'GC_448',
                  value = 'cwD6*delta*gwD6*ImCdW23 - cwD6*delta*complex(0,1)*gwD6*ReCdW23',
                  order = {'NP':2,'QED':2})

GC_449 = Coupling(name = 'GC_449',
                  value = '-(cwD6*delta*gwD6*ImCdW23) + cwD6*delta*complex(0,1)*gwD6*ReCdW23',
                  order = {'NP':2,'QED':2})

GC_450 = Coupling(name = 'GC_450',
                  value = 'cwD6*delta*gwD6*ImCdW23 + cwD6*delta*complex(0,1)*gwD6*ReCdW23',
                  order = {'NP':2,'QED':2})

GC_451 = Coupling(name = 'GC_451',
                  value = '-(delta*ImCdW31) + delta*complex(0,1)*ReCdW31',
                  order = {'NP':2,'QED':1})

GC_452 = Coupling(name = 'GC_452',
                  value = 'delta*ImCdW31 + delta*complex(0,1)*ReCdW31',
                  order = {'NP':2,'QED':1})

GC_453 = Coupling(name = 'GC_453',
                  value = '-((delta*gwD6*ImCdW31)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_454 = Coupling(name = 'GC_454',
                  value = '(delta*gwD6*ImCdW31)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_455 = Coupling(name = 'GC_455',
                  value = '-((delta*gwD6*ImCdW31)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_456 = Coupling(name = 'GC_456',
                  value = '(delta*gwD6*ImCdW31)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_457 = Coupling(name = 'GC_457',
                  value = '-(cwD6*delta*gwD6*ImCdW31) - cwD6*delta*complex(0,1)*gwD6*ReCdW31',
                  order = {'NP':2,'QED':2})

GC_458 = Coupling(name = 'GC_458',
                  value = 'cwD6*delta*gwD6*ImCdW31 - cwD6*delta*complex(0,1)*gwD6*ReCdW31',
                  order = {'NP':2,'QED':2})

GC_459 = Coupling(name = 'GC_459',
                  value = '-(cwD6*delta*gwD6*ImCdW31) + cwD6*delta*complex(0,1)*gwD6*ReCdW31',
                  order = {'NP':2,'QED':2})

GC_460 = Coupling(name = 'GC_460',
                  value = 'cwD6*delta*gwD6*ImCdW31 + cwD6*delta*complex(0,1)*gwD6*ReCdW31',
                  order = {'NP':2,'QED':2})

GC_461 = Coupling(name = 'GC_461',
                  value = '-(delta*ImCdW32) + delta*complex(0,1)*ReCdW32',
                  order = {'NP':2,'QED':1})

GC_462 = Coupling(name = 'GC_462',
                  value = 'delta*ImCdW32 + delta*complex(0,1)*ReCdW32',
                  order = {'NP':2,'QED':1})

GC_463 = Coupling(name = 'GC_463',
                  value = '-((delta*gwD6*ImCdW32)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_464 = Coupling(name = 'GC_464',
                  value = '(delta*gwD6*ImCdW32)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_465 = Coupling(name = 'GC_465',
                  value = '-((delta*gwD6*ImCdW32)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_466 = Coupling(name = 'GC_466',
                  value = '(delta*gwD6*ImCdW32)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_467 = Coupling(name = 'GC_467',
                  value = '-(cwD6*delta*gwD6*ImCdW32) - cwD6*delta*complex(0,1)*gwD6*ReCdW32',
                  order = {'NP':2,'QED':2})

GC_468 = Coupling(name = 'GC_468',
                  value = 'cwD6*delta*gwD6*ImCdW32 - cwD6*delta*complex(0,1)*gwD6*ReCdW32',
                  order = {'NP':2,'QED':2})

GC_469 = Coupling(name = 'GC_469',
                  value = '-(cwD6*delta*gwD6*ImCdW32) + cwD6*delta*complex(0,1)*gwD6*ReCdW32',
                  order = {'NP':2,'QED':2})

GC_470 = Coupling(name = 'GC_470',
                  value = 'cwD6*delta*gwD6*ImCdW32 + cwD6*delta*complex(0,1)*gwD6*ReCdW32',
                  order = {'NP':2,'QED':2})

GC_471 = Coupling(name = 'GC_471',
                  value = '-(delta*ImCdW33) + delta*complex(0,1)*ReCdW33',
                  order = {'NP':2,'QED':1})

GC_472 = Coupling(name = 'GC_472',
                  value = 'delta*ImCdW33 + delta*complex(0,1)*ReCdW33',
                  order = {'NP':2,'QED':1})

GC_473 = Coupling(name = 'GC_473',
                  value = '-((delta*gwD6*ImCdW33)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_474 = Coupling(name = 'GC_474',
                  value = '(delta*gwD6*ImCdW33)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_475 = Coupling(name = 'GC_475',
                  value = '-((delta*gwD6*ImCdW33)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_476 = Coupling(name = 'GC_476',
                  value = '(delta*gwD6*ImCdW33)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_477 = Coupling(name = 'GC_477',
                  value = '-(cwD6*delta*gwD6*ImCdW33) - cwD6*delta*complex(0,1)*gwD6*ReCdW33',
                  order = {'NP':2,'QED':2})

GC_478 = Coupling(name = 'GC_478',
                  value = 'cwD6*delta*gwD6*ImCdW33 - cwD6*delta*complex(0,1)*gwD6*ReCdW33',
                  order = {'NP':2,'QED':2})

GC_479 = Coupling(name = 'GC_479',
                  value = '-(cwD6*delta*gwD6*ImCdW33) + cwD6*delta*complex(0,1)*gwD6*ReCdW33',
                  order = {'NP':2,'QED':2})

GC_480 = Coupling(name = 'GC_480',
                  value = 'cwD6*delta*gwD6*ImCdW33 + cwD6*delta*complex(0,1)*gwD6*ReCdW33',
                  order = {'NP':2,'QED':2})

GC_481 = Coupling(name = 'GC_481',
                  value = '(3*delta*complex(0,1)*ReCePhi11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_482 = Coupling(name = 'GC_482',
                  value = '(-3*delta*ImCePhi12)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_483 = Coupling(name = 'GC_483',
                  value = '(3*delta*ImCePhi12)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_484 = Coupling(name = 'GC_484',
                  value = '(-3*delta*ImCePhi13)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_485 = Coupling(name = 'GC_485',
                  value = '(3*delta*ImCePhi13)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_486 = Coupling(name = 'GC_486',
                  value = '(-3*delta*ImCePhi21)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_487 = Coupling(name = 'GC_487',
                  value = '(3*delta*ImCePhi21)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_488 = Coupling(name = 'GC_488',
                  value = '(3*delta*complex(0,1)*ReCePhi22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_489 = Coupling(name = 'GC_489',
                  value = '(-3*delta*ImCePhi23)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_490 = Coupling(name = 'GC_490',
                  value = '(3*delta*ImCePhi23)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_491 = Coupling(name = 'GC_491',
                  value = '(-3*delta*ImCePhi31)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_492 = Coupling(name = 'GC_492',
                  value = '(3*delta*ImCePhi31)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_493 = Coupling(name = 'GC_493',
                  value = '(-3*delta*ImCePhi32)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_494 = Coupling(name = 'GC_494',
                  value = '(3*delta*ImCePhi32)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_495 = Coupling(name = 'GC_495',
                  value = '(3*delta*complex(0,1)*ReCePhi33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_496 = Coupling(name = 'GC_496',
                  value = 'delta*ImCeW11 - delta*complex(0,1)*ReCeW11',
                  order = {'NP':2,'QED':1})

GC_497 = Coupling(name = 'GC_497',
                  value = '-(delta*ImCeW11) + delta*complex(0,1)*ReCeW11',
                  order = {'NP':2,'QED':1})

GC_498 = Coupling(name = 'GC_498',
                  value = 'delta*ImCeW11 + delta*complex(0,1)*ReCeW11',
                  order = {'NP':2,'QED':1})

GC_499 = Coupling(name = 'GC_499',
                  value = '-((delta*gwD6*ImCeW11)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_500 = Coupling(name = 'GC_500',
                  value = '(delta*gwD6*ImCeW11)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_501 = Coupling(name = 'GC_501',
                  value = '-((delta*gwD6*ImCeW11)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_502 = Coupling(name = 'GC_502',
                  value = '(delta*gwD6*ImCeW11)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_503 = Coupling(name = 'GC_503',
                  value = '-(cwD6*delta*gwD6*ImCeW11) - cwD6*delta*complex(0,1)*gwD6*ReCeW11',
                  order = {'NP':2,'QED':2})

GC_504 = Coupling(name = 'GC_504',
                  value = 'cwD6*delta*gwD6*ImCeW11 - cwD6*delta*complex(0,1)*gwD6*ReCeW11',
                  order = {'NP':2,'QED':2})

GC_505 = Coupling(name = 'GC_505',
                  value = '-(cwD6*delta*gwD6*ImCeW11) + cwD6*delta*complex(0,1)*gwD6*ReCeW11',
                  order = {'NP':2,'QED':2})

GC_506 = Coupling(name = 'GC_506',
                  value = 'cwD6*delta*gwD6*ImCeW11 + cwD6*delta*complex(0,1)*gwD6*ReCeW11',
                  order = {'NP':2,'QED':2})

GC_507 = Coupling(name = 'GC_507',
                  value = 'delta*ImCeW12 - delta*complex(0,1)*ReCeW12',
                  order = {'NP':2,'QED':1})

GC_508 = Coupling(name = 'GC_508',
                  value = '-(delta*ImCeW12) + delta*complex(0,1)*ReCeW12',
                  order = {'NP':2,'QED':1})

GC_509 = Coupling(name = 'GC_509',
                  value = 'delta*ImCeW12 + delta*complex(0,1)*ReCeW12',
                  order = {'NP':2,'QED':1})

GC_510 = Coupling(name = 'GC_510',
                  value = '-((delta*gwD6*ImCeW12)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_511 = Coupling(name = 'GC_511',
                  value = '(delta*gwD6*ImCeW12)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_512 = Coupling(name = 'GC_512',
                  value = '-((delta*gwD6*ImCeW12)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_513 = Coupling(name = 'GC_513',
                  value = '(delta*gwD6*ImCeW12)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_514 = Coupling(name = 'GC_514',
                  value = '-(cwD6*delta*gwD6*ImCeW12) - cwD6*delta*complex(0,1)*gwD6*ReCeW12',
                  order = {'NP':2,'QED':2})

GC_515 = Coupling(name = 'GC_515',
                  value = 'cwD6*delta*gwD6*ImCeW12 - cwD6*delta*complex(0,1)*gwD6*ReCeW12',
                  order = {'NP':2,'QED':2})

GC_516 = Coupling(name = 'GC_516',
                  value = '-(cwD6*delta*gwD6*ImCeW12) + cwD6*delta*complex(0,1)*gwD6*ReCeW12',
                  order = {'NP':2,'QED':2})

GC_517 = Coupling(name = 'GC_517',
                  value = 'cwD6*delta*gwD6*ImCeW12 + cwD6*delta*complex(0,1)*gwD6*ReCeW12',
                  order = {'NP':2,'QED':2})

GC_518 = Coupling(name = 'GC_518',
                  value = 'delta*ImCeW13 - delta*complex(0,1)*ReCeW13',
                  order = {'NP':2,'QED':1})

GC_519 = Coupling(name = 'GC_519',
                  value = '-(delta*ImCeW13) + delta*complex(0,1)*ReCeW13',
                  order = {'NP':2,'QED':1})

GC_520 = Coupling(name = 'GC_520',
                  value = 'delta*ImCeW13 + delta*complex(0,1)*ReCeW13',
                  order = {'NP':2,'QED':1})

GC_521 = Coupling(name = 'GC_521',
                  value = '-((delta*gwD6*ImCeW13)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_522 = Coupling(name = 'GC_522',
                  value = '(delta*gwD6*ImCeW13)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_523 = Coupling(name = 'GC_523',
                  value = '-((delta*gwD6*ImCeW13)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_524 = Coupling(name = 'GC_524',
                  value = '(delta*gwD6*ImCeW13)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_525 = Coupling(name = 'GC_525',
                  value = '-(cwD6*delta*gwD6*ImCeW13) - cwD6*delta*complex(0,1)*gwD6*ReCeW13',
                  order = {'NP':2,'QED':2})

GC_526 = Coupling(name = 'GC_526',
                  value = 'cwD6*delta*gwD6*ImCeW13 - cwD6*delta*complex(0,1)*gwD6*ReCeW13',
                  order = {'NP':2,'QED':2})

GC_527 = Coupling(name = 'GC_527',
                  value = '-(cwD6*delta*gwD6*ImCeW13) + cwD6*delta*complex(0,1)*gwD6*ReCeW13',
                  order = {'NP':2,'QED':2})

GC_528 = Coupling(name = 'GC_528',
                  value = 'cwD6*delta*gwD6*ImCeW13 + cwD6*delta*complex(0,1)*gwD6*ReCeW13',
                  order = {'NP':2,'QED':2})

GC_529 = Coupling(name = 'GC_529',
                  value = 'delta*ImCeW21 - delta*complex(0,1)*ReCeW21',
                  order = {'NP':2,'QED':1})

GC_530 = Coupling(name = 'GC_530',
                  value = '-(delta*ImCeW21) + delta*complex(0,1)*ReCeW21',
                  order = {'NP':2,'QED':1})

GC_531 = Coupling(name = 'GC_531',
                  value = 'delta*ImCeW21 + delta*complex(0,1)*ReCeW21',
                  order = {'NP':2,'QED':1})

GC_532 = Coupling(name = 'GC_532',
                  value = '-((delta*gwD6*ImCeW21)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_533 = Coupling(name = 'GC_533',
                  value = '(delta*gwD6*ImCeW21)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_534 = Coupling(name = 'GC_534',
                  value = '-((delta*gwD6*ImCeW21)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_535 = Coupling(name = 'GC_535',
                  value = '(delta*gwD6*ImCeW21)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_536 = Coupling(name = 'GC_536',
                  value = '-(cwD6*delta*gwD6*ImCeW21) - cwD6*delta*complex(0,1)*gwD6*ReCeW21',
                  order = {'NP':2,'QED':2})

GC_537 = Coupling(name = 'GC_537',
                  value = 'cwD6*delta*gwD6*ImCeW21 - cwD6*delta*complex(0,1)*gwD6*ReCeW21',
                  order = {'NP':2,'QED':2})

GC_538 = Coupling(name = 'GC_538',
                  value = '-(cwD6*delta*gwD6*ImCeW21) + cwD6*delta*complex(0,1)*gwD6*ReCeW21',
                  order = {'NP':2,'QED':2})

GC_539 = Coupling(name = 'GC_539',
                  value = 'cwD6*delta*gwD6*ImCeW21 + cwD6*delta*complex(0,1)*gwD6*ReCeW21',
                  order = {'NP':2,'QED':2})

GC_540 = Coupling(name = 'GC_540',
                  value = 'delta*ImCeW22 - delta*complex(0,1)*ReCeW22',
                  order = {'NP':2,'QED':1})

GC_541 = Coupling(name = 'GC_541',
                  value = '-(delta*ImCeW22) + delta*complex(0,1)*ReCeW22',
                  order = {'NP':2,'QED':1})

GC_542 = Coupling(name = 'GC_542',
                  value = 'delta*ImCeW22 + delta*complex(0,1)*ReCeW22',
                  order = {'NP':2,'QED':1})

GC_543 = Coupling(name = 'GC_543',
                  value = '-((delta*gwD6*ImCeW22)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_544 = Coupling(name = 'GC_544',
                  value = '(delta*gwD6*ImCeW22)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_545 = Coupling(name = 'GC_545',
                  value = '-((delta*gwD6*ImCeW22)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_546 = Coupling(name = 'GC_546',
                  value = '(delta*gwD6*ImCeW22)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_547 = Coupling(name = 'GC_547',
                  value = '-(cwD6*delta*gwD6*ImCeW22) - cwD6*delta*complex(0,1)*gwD6*ReCeW22',
                  order = {'NP':2,'QED':2})

GC_548 = Coupling(name = 'GC_548',
                  value = 'cwD6*delta*gwD6*ImCeW22 - cwD6*delta*complex(0,1)*gwD6*ReCeW22',
                  order = {'NP':2,'QED':2})

GC_549 = Coupling(name = 'GC_549',
                  value = '-(cwD6*delta*gwD6*ImCeW22) + cwD6*delta*complex(0,1)*gwD6*ReCeW22',
                  order = {'NP':2,'QED':2})

GC_550 = Coupling(name = 'GC_550',
                  value = 'cwD6*delta*gwD6*ImCeW22 + cwD6*delta*complex(0,1)*gwD6*ReCeW22',
                  order = {'NP':2,'QED':2})

GC_551 = Coupling(name = 'GC_551',
                  value = 'delta*ImCeW23 - delta*complex(0,1)*ReCeW23',
                  order = {'NP':2,'QED':1})

GC_552 = Coupling(name = 'GC_552',
                  value = '-(delta*ImCeW23) + delta*complex(0,1)*ReCeW23',
                  order = {'NP':2,'QED':1})

GC_553 = Coupling(name = 'GC_553',
                  value = 'delta*ImCeW23 + delta*complex(0,1)*ReCeW23',
                  order = {'NP':2,'QED':1})

GC_554 = Coupling(name = 'GC_554',
                  value = '-((delta*gwD6*ImCeW23)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_555 = Coupling(name = 'GC_555',
                  value = '(delta*gwD6*ImCeW23)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_556 = Coupling(name = 'GC_556',
                  value = '-((delta*gwD6*ImCeW23)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_557 = Coupling(name = 'GC_557',
                  value = '(delta*gwD6*ImCeW23)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_558 = Coupling(name = 'GC_558',
                  value = '-(cwD6*delta*gwD6*ImCeW23) - cwD6*delta*complex(0,1)*gwD6*ReCeW23',
                  order = {'NP':2,'QED':2})

GC_559 = Coupling(name = 'GC_559',
                  value = 'cwD6*delta*gwD6*ImCeW23 - cwD6*delta*complex(0,1)*gwD6*ReCeW23',
                  order = {'NP':2,'QED':2})

GC_560 = Coupling(name = 'GC_560',
                  value = '-(cwD6*delta*gwD6*ImCeW23) + cwD6*delta*complex(0,1)*gwD6*ReCeW23',
                  order = {'NP':2,'QED':2})

GC_561 = Coupling(name = 'GC_561',
                  value = 'cwD6*delta*gwD6*ImCeW23 + cwD6*delta*complex(0,1)*gwD6*ReCeW23',
                  order = {'NP':2,'QED':2})

GC_562 = Coupling(name = 'GC_562',
                  value = 'delta*ImCeW31 - delta*complex(0,1)*ReCeW31',
                  order = {'NP':2,'QED':1})

GC_563 = Coupling(name = 'GC_563',
                  value = '-(delta*ImCeW31) + delta*complex(0,1)*ReCeW31',
                  order = {'NP':2,'QED':1})

GC_564 = Coupling(name = 'GC_564',
                  value = 'delta*ImCeW31 + delta*complex(0,1)*ReCeW31',
                  order = {'NP':2,'QED':1})

GC_565 = Coupling(name = 'GC_565',
                  value = '-((delta*gwD6*ImCeW31)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_566 = Coupling(name = 'GC_566',
                  value = '(delta*gwD6*ImCeW31)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_567 = Coupling(name = 'GC_567',
                  value = '-((delta*gwD6*ImCeW31)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_568 = Coupling(name = 'GC_568',
                  value = '(delta*gwD6*ImCeW31)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_569 = Coupling(name = 'GC_569',
                  value = '-(cwD6*delta*gwD6*ImCeW31) - cwD6*delta*complex(0,1)*gwD6*ReCeW31',
                  order = {'NP':2,'QED':2})

GC_570 = Coupling(name = 'GC_570',
                  value = 'cwD6*delta*gwD6*ImCeW31 - cwD6*delta*complex(0,1)*gwD6*ReCeW31',
                  order = {'NP':2,'QED':2})

GC_571 = Coupling(name = 'GC_571',
                  value = '-(cwD6*delta*gwD6*ImCeW31) + cwD6*delta*complex(0,1)*gwD6*ReCeW31',
                  order = {'NP':2,'QED':2})

GC_572 = Coupling(name = 'GC_572',
                  value = 'cwD6*delta*gwD6*ImCeW31 + cwD6*delta*complex(0,1)*gwD6*ReCeW31',
                  order = {'NP':2,'QED':2})

GC_573 = Coupling(name = 'GC_573',
                  value = 'delta*ImCeW32 - delta*complex(0,1)*ReCeW32',
                  order = {'NP':2,'QED':1})

GC_574 = Coupling(name = 'GC_574',
                  value = '-(delta*ImCeW32) + delta*complex(0,1)*ReCeW32',
                  order = {'NP':2,'QED':1})

GC_575 = Coupling(name = 'GC_575',
                  value = 'delta*ImCeW32 + delta*complex(0,1)*ReCeW32',
                  order = {'NP':2,'QED':1})

GC_576 = Coupling(name = 'GC_576',
                  value = '-((delta*gwD6*ImCeW32)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_577 = Coupling(name = 'GC_577',
                  value = '(delta*gwD6*ImCeW32)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_578 = Coupling(name = 'GC_578',
                  value = '-((delta*gwD6*ImCeW32)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_579 = Coupling(name = 'GC_579',
                  value = '(delta*gwD6*ImCeW32)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_580 = Coupling(name = 'GC_580',
                  value = '-(cwD6*delta*gwD6*ImCeW32) - cwD6*delta*complex(0,1)*gwD6*ReCeW32',
                  order = {'NP':2,'QED':2})

GC_581 = Coupling(name = 'GC_581',
                  value = 'cwD6*delta*gwD6*ImCeW32 - cwD6*delta*complex(0,1)*gwD6*ReCeW32',
                  order = {'NP':2,'QED':2})

GC_582 = Coupling(name = 'GC_582',
                  value = '-(cwD6*delta*gwD6*ImCeW32) + cwD6*delta*complex(0,1)*gwD6*ReCeW32',
                  order = {'NP':2,'QED':2})

GC_583 = Coupling(name = 'GC_583',
                  value = 'cwD6*delta*gwD6*ImCeW32 + cwD6*delta*complex(0,1)*gwD6*ReCeW32',
                  order = {'NP':2,'QED':2})

GC_584 = Coupling(name = 'GC_584',
                  value = 'delta*ImCeW33 - delta*complex(0,1)*ReCeW33',
                  order = {'NP':2,'QED':1})

GC_585 = Coupling(name = 'GC_585',
                  value = '-(delta*ImCeW33) + delta*complex(0,1)*ReCeW33',
                  order = {'NP':2,'QED':1})

GC_586 = Coupling(name = 'GC_586',
                  value = 'delta*ImCeW33 + delta*complex(0,1)*ReCeW33',
                  order = {'NP':2,'QED':1})

GC_587 = Coupling(name = 'GC_587',
                  value = '-((delta*gwD6*ImCeW33)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_588 = Coupling(name = 'GC_588',
                  value = '(delta*gwD6*ImCeW33)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_589 = Coupling(name = 'GC_589',
                  value = '-((delta*gwD6*ImCeW33)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_590 = Coupling(name = 'GC_590',
                  value = '(delta*gwD6*ImCeW33)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_591 = Coupling(name = 'GC_591',
                  value = '-(cwD6*delta*gwD6*ImCeW33) - cwD6*delta*complex(0,1)*gwD6*ReCeW33',
                  order = {'NP':2,'QED':2})

GC_592 = Coupling(name = 'GC_592',
                  value = 'cwD6*delta*gwD6*ImCeW33 - cwD6*delta*complex(0,1)*gwD6*ReCeW33',
                  order = {'NP':2,'QED':2})

GC_593 = Coupling(name = 'GC_593',
                  value = '-(cwD6*delta*gwD6*ImCeW33) + cwD6*delta*complex(0,1)*gwD6*ReCeW33',
                  order = {'NP':2,'QED':2})

GC_594 = Coupling(name = 'GC_594',
                  value = 'cwD6*delta*gwD6*ImCeW33 + cwD6*delta*complex(0,1)*gwD6*ReCeW33',
                  order = {'NP':2,'QED':2})

GC_595 = Coupling(name = 'GC_595',
                  value = '-((delta*gwD6*ImCPhiud11)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_596 = Coupling(name = 'GC_596',
                  value = '(delta*gwD6*ImCPhiud11)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_597 = Coupling(name = 'GC_597',
                  value = '-((delta*gwD6*ImCPhiud12)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_598 = Coupling(name = 'GC_598',
                  value = '(delta*gwD6*ImCPhiud12)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_599 = Coupling(name = 'GC_599',
                  value = '-((delta*gwD6*ImCPhiud13)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_600 = Coupling(name = 'GC_600',
                  value = '(delta*gwD6*ImCPhiud13)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_601 = Coupling(name = 'GC_601',
                  value = '-((delta*gwD6*ImCPhiud21)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_602 = Coupling(name = 'GC_602',
                  value = '(delta*gwD6*ImCPhiud21)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_603 = Coupling(name = 'GC_603',
                  value = '-((delta*gwD6*ImCPhiud22)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_604 = Coupling(name = 'GC_604',
                  value = '(delta*gwD6*ImCPhiud22)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_605 = Coupling(name = 'GC_605',
                  value = '-((delta*gwD6*ImCPhiud23)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_606 = Coupling(name = 'GC_606',
                  value = '(delta*gwD6*ImCPhiud23)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_607 = Coupling(name = 'GC_607',
                  value = '-((delta*gwD6*ImCPhiud31)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_608 = Coupling(name = 'GC_608',
                  value = '(delta*gwD6*ImCPhiud31)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_609 = Coupling(name = 'GC_609',
                  value = '-((delta*gwD6*ImCPhiud32)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_610 = Coupling(name = 'GC_610',
                  value = '(delta*gwD6*ImCPhiud32)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_611 = Coupling(name = 'GC_611',
                  value = '-((delta*gwD6*ImCPhiud33)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_612 = Coupling(name = 'GC_612',
                  value = '(delta*gwD6*ImCPhiud33)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_613 = Coupling(name = 'GC_613',
                  value = '-((delta*ImCuG11)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_614 = Coupling(name = 'GC_614',
                  value = '(delta*ImCuG11)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_615 = Coupling(name = 'GC_615',
                  value = '-((delta*ImCuG11)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_616 = Coupling(name = 'GC_616',
                  value = '(delta*ImCuG11)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_617 = Coupling(name = 'GC_617',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG11)/cmath.sqrt(2)) - (delta*gsD6*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_618 = Coupling(name = 'GC_618',
                  value = '(delta*complex(0,1)*gsD6*ImCuG11)/cmath.sqrt(2) - (delta*gsD6*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_619 = Coupling(name = 'GC_619',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG11)/cmath.sqrt(2)) + (delta*gsD6*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_620 = Coupling(name = 'GC_620',
                  value = '(delta*complex(0,1)*gsD6*ImCuG11)/cmath.sqrt(2) + (delta*gsD6*ReCuG11)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_621 = Coupling(name = 'GC_621',
                  value = '-((delta*ImCuG12)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_622 = Coupling(name = 'GC_622',
                  value = '(delta*ImCuG12)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_623 = Coupling(name = 'GC_623',
                  value = '-((delta*ImCuG12)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_624 = Coupling(name = 'GC_624',
                  value = '(delta*ImCuG12)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_625 = Coupling(name = 'GC_625',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG12)/cmath.sqrt(2)) - (delta*gsD6*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_626 = Coupling(name = 'GC_626',
                  value = '(delta*complex(0,1)*gsD6*ImCuG12)/cmath.sqrt(2) - (delta*gsD6*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_627 = Coupling(name = 'GC_627',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG12)/cmath.sqrt(2)) + (delta*gsD6*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_628 = Coupling(name = 'GC_628',
                  value = '(delta*complex(0,1)*gsD6*ImCuG12)/cmath.sqrt(2) + (delta*gsD6*ReCuG12)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_629 = Coupling(name = 'GC_629',
                  value = '-((delta*ImCuG13)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_630 = Coupling(name = 'GC_630',
                  value = '(delta*ImCuG13)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_631 = Coupling(name = 'GC_631',
                  value = '-((delta*ImCuG13)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_632 = Coupling(name = 'GC_632',
                  value = '(delta*ImCuG13)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_633 = Coupling(name = 'GC_633',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG13)/cmath.sqrt(2)) - (delta*gsD6*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_634 = Coupling(name = 'GC_634',
                  value = '(delta*complex(0,1)*gsD6*ImCuG13)/cmath.sqrt(2) - (delta*gsD6*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_635 = Coupling(name = 'GC_635',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG13)/cmath.sqrt(2)) + (delta*gsD6*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_636 = Coupling(name = 'GC_636',
                  value = '(delta*complex(0,1)*gsD6*ImCuG13)/cmath.sqrt(2) + (delta*gsD6*ReCuG13)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_637 = Coupling(name = 'GC_637',
                  value = '-((delta*ImCuG21)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_638 = Coupling(name = 'GC_638',
                  value = '(delta*ImCuG21)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_639 = Coupling(name = 'GC_639',
                  value = '-((delta*ImCuG21)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_640 = Coupling(name = 'GC_640',
                  value = '(delta*ImCuG21)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_641 = Coupling(name = 'GC_641',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG21)/cmath.sqrt(2)) - (delta*gsD6*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_642 = Coupling(name = 'GC_642',
                  value = '(delta*complex(0,1)*gsD6*ImCuG21)/cmath.sqrt(2) - (delta*gsD6*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_643 = Coupling(name = 'GC_643',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG21)/cmath.sqrt(2)) + (delta*gsD6*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_644 = Coupling(name = 'GC_644',
                  value = '(delta*complex(0,1)*gsD6*ImCuG21)/cmath.sqrt(2) + (delta*gsD6*ReCuG21)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_645 = Coupling(name = 'GC_645',
                  value = '-((delta*ImCuG22)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_646 = Coupling(name = 'GC_646',
                  value = '(delta*ImCuG22)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_647 = Coupling(name = 'GC_647',
                  value = '-((delta*ImCuG22)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_648 = Coupling(name = 'GC_648',
                  value = '(delta*ImCuG22)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_649 = Coupling(name = 'GC_649',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG22)/cmath.sqrt(2)) - (delta*gsD6*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_650 = Coupling(name = 'GC_650',
                  value = '(delta*complex(0,1)*gsD6*ImCuG22)/cmath.sqrt(2) - (delta*gsD6*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_651 = Coupling(name = 'GC_651',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG22)/cmath.sqrt(2)) + (delta*gsD6*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_652 = Coupling(name = 'GC_652',
                  value = '(delta*complex(0,1)*gsD6*ImCuG22)/cmath.sqrt(2) + (delta*gsD6*ReCuG22)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_653 = Coupling(name = 'GC_653',
                  value = '-((delta*ImCuG23)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_654 = Coupling(name = 'GC_654',
                  value = '(delta*ImCuG23)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_655 = Coupling(name = 'GC_655',
                  value = '-((delta*ImCuG23)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_656 = Coupling(name = 'GC_656',
                  value = '(delta*ImCuG23)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_657 = Coupling(name = 'GC_657',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG23)/cmath.sqrt(2)) - (delta*gsD6*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_658 = Coupling(name = 'GC_658',
                  value = '(delta*complex(0,1)*gsD6*ImCuG23)/cmath.sqrt(2) - (delta*gsD6*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_659 = Coupling(name = 'GC_659',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG23)/cmath.sqrt(2)) + (delta*gsD6*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_660 = Coupling(name = 'GC_660',
                  value = '(delta*complex(0,1)*gsD6*ImCuG23)/cmath.sqrt(2) + (delta*gsD6*ReCuG23)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_661 = Coupling(name = 'GC_661',
                  value = '-((delta*ImCuG31)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_662 = Coupling(name = 'GC_662',
                  value = '(delta*ImCuG31)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_663 = Coupling(name = 'GC_663',
                  value = '-((delta*ImCuG31)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_664 = Coupling(name = 'GC_664',
                  value = '(delta*ImCuG31)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_665 = Coupling(name = 'GC_665',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG31)/cmath.sqrt(2)) - (delta*gsD6*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_666 = Coupling(name = 'GC_666',
                  value = '(delta*complex(0,1)*gsD6*ImCuG31)/cmath.sqrt(2) - (delta*gsD6*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_667 = Coupling(name = 'GC_667',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG31)/cmath.sqrt(2)) + (delta*gsD6*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_668 = Coupling(name = 'GC_668',
                  value = '(delta*complex(0,1)*gsD6*ImCuG31)/cmath.sqrt(2) + (delta*gsD6*ReCuG31)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_669 = Coupling(name = 'GC_669',
                  value = '-((delta*ImCuG32)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_670 = Coupling(name = 'GC_670',
                  value = '(delta*ImCuG32)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_671 = Coupling(name = 'GC_671',
                  value = '-((delta*ImCuG32)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_672 = Coupling(name = 'GC_672',
                  value = '(delta*ImCuG32)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_673 = Coupling(name = 'GC_673',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG32)/cmath.sqrt(2)) - (delta*gsD6*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_674 = Coupling(name = 'GC_674',
                  value = '(delta*complex(0,1)*gsD6*ImCuG32)/cmath.sqrt(2) - (delta*gsD6*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_675 = Coupling(name = 'GC_675',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG32)/cmath.sqrt(2)) + (delta*gsD6*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_676 = Coupling(name = 'GC_676',
                  value = '(delta*complex(0,1)*gsD6*ImCuG32)/cmath.sqrt(2) + (delta*gsD6*ReCuG32)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_677 = Coupling(name = 'GC_677',
                  value = '-((delta*ImCuG33)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_678 = Coupling(name = 'GC_678',
                  value = '(delta*ImCuG33)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_679 = Coupling(name = 'GC_679',
                  value = '-((delta*ImCuG33)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_680 = Coupling(name = 'GC_680',
                  value = '(delta*ImCuG33)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_681 = Coupling(name = 'GC_681',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG33)/cmath.sqrt(2)) - (delta*gsD6*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_682 = Coupling(name = 'GC_682',
                  value = '(delta*complex(0,1)*gsD6*ImCuG33)/cmath.sqrt(2) - (delta*gsD6*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_683 = Coupling(name = 'GC_683',
                  value = '-((delta*complex(0,1)*gsD6*ImCuG33)/cmath.sqrt(2)) + (delta*gsD6*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_684 = Coupling(name = 'GC_684',
                  value = '(delta*complex(0,1)*gsD6*ImCuG33)/cmath.sqrt(2) + (delta*gsD6*ReCuG33)/cmath.sqrt(2)',
                  order = {'NP':2,'QCD':1,'QED':1})

GC_685 = Coupling(name = 'GC_685',
                  value = '(3*delta*complex(0,1)*ReCuPhi11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_686 = Coupling(name = 'GC_686',
                  value = '(-3*delta*ImCuPhi12)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_687 = Coupling(name = 'GC_687',
                  value = '(3*delta*ImCuPhi12)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_688 = Coupling(name = 'GC_688',
                  value = '(-3*delta*ImCuPhi13)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_689 = Coupling(name = 'GC_689',
                  value = '(3*delta*ImCuPhi13)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_690 = Coupling(name = 'GC_690',
                  value = '(-3*delta*ImCuPhi21)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_691 = Coupling(name = 'GC_691',
                  value = '(3*delta*ImCuPhi21)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_692 = Coupling(name = 'GC_692',
                  value = '(3*delta*complex(0,1)*ReCuPhi22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_693 = Coupling(name = 'GC_693',
                  value = '(-3*delta*ImCuPhi23)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_694 = Coupling(name = 'GC_694',
                  value = '(3*delta*ImCuPhi23)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_695 = Coupling(name = 'GC_695',
                  value = '(-3*delta*ImCuPhi31)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_696 = Coupling(name = 'GC_696',
                  value = '(3*delta*ImCuPhi31)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_697 = Coupling(name = 'GC_697',
                  value = '(-3*delta*ImCuPhi32)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_698 = Coupling(name = 'GC_698',
                  value = '(3*delta*ImCuPhi32)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_699 = Coupling(name = 'GC_699',
                  value = '(3*delta*complex(0,1)*ReCuPhi33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':3})

GC_700 = Coupling(name = 'GC_700',
                  value = '-(delta*ImCuW11) + delta*complex(0,1)*ReCuW11',
                  order = {'NP':2,'QED':1})

GC_701 = Coupling(name = 'GC_701',
                  value = 'delta*ImCuW11 + delta*complex(0,1)*ReCuW11',
                  order = {'NP':2,'QED':1})

GC_702 = Coupling(name = 'GC_702',
                  value = '-((delta*gwD6*ImCuW11)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_703 = Coupling(name = 'GC_703',
                  value = '(delta*gwD6*ImCuW11)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_704 = Coupling(name = 'GC_704',
                  value = '-((delta*gwD6*ImCuW11)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_705 = Coupling(name = 'GC_705',
                  value = '(delta*gwD6*ImCuW11)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW11)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_706 = Coupling(name = 'GC_706',
                  value = '-(cwD6*delta*gwD6*ImCuW11) - cwD6*delta*complex(0,1)*gwD6*ReCuW11',
                  order = {'NP':2,'QED':2})

GC_707 = Coupling(name = 'GC_707',
                  value = 'cwD6*delta*gwD6*ImCuW11 - cwD6*delta*complex(0,1)*gwD6*ReCuW11',
                  order = {'NP':2,'QED':2})

GC_708 = Coupling(name = 'GC_708',
                  value = '-(cwD6*delta*gwD6*ImCuW11) + cwD6*delta*complex(0,1)*gwD6*ReCuW11',
                  order = {'NP':2,'QED':2})

GC_709 = Coupling(name = 'GC_709',
                  value = 'cwD6*delta*gwD6*ImCuW11 + cwD6*delta*complex(0,1)*gwD6*ReCuW11',
                  order = {'NP':2,'QED':2})

GC_710 = Coupling(name = 'GC_710',
                  value = '-(delta*ImCuW12) + delta*complex(0,1)*ReCuW12',
                  order = {'NP':2,'QED':1})

GC_711 = Coupling(name = 'GC_711',
                  value = 'delta*ImCuW12 + delta*complex(0,1)*ReCuW12',
                  order = {'NP':2,'QED':1})

GC_712 = Coupling(name = 'GC_712',
                  value = '-((delta*gwD6*ImCuW12)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_713 = Coupling(name = 'GC_713',
                  value = '(delta*gwD6*ImCuW12)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_714 = Coupling(name = 'GC_714',
                  value = '-((delta*gwD6*ImCuW12)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_715 = Coupling(name = 'GC_715',
                  value = '(delta*gwD6*ImCuW12)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW12)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_716 = Coupling(name = 'GC_716',
                  value = '-(cwD6*delta*gwD6*ImCuW12) - cwD6*delta*complex(0,1)*gwD6*ReCuW12',
                  order = {'NP':2,'QED':2})

GC_717 = Coupling(name = 'GC_717',
                  value = 'cwD6*delta*gwD6*ImCuW12 - cwD6*delta*complex(0,1)*gwD6*ReCuW12',
                  order = {'NP':2,'QED':2})

GC_718 = Coupling(name = 'GC_718',
                  value = '-(cwD6*delta*gwD6*ImCuW12) + cwD6*delta*complex(0,1)*gwD6*ReCuW12',
                  order = {'NP':2,'QED':2})

GC_719 = Coupling(name = 'GC_719',
                  value = 'cwD6*delta*gwD6*ImCuW12 + cwD6*delta*complex(0,1)*gwD6*ReCuW12',
                  order = {'NP':2,'QED':2})

GC_720 = Coupling(name = 'GC_720',
                  value = '-(delta*ImCuW13) + delta*complex(0,1)*ReCuW13',
                  order = {'NP':2,'QED':1})

GC_721 = Coupling(name = 'GC_721',
                  value = 'delta*ImCuW13 + delta*complex(0,1)*ReCuW13',
                  order = {'NP':2,'QED':1})

GC_722 = Coupling(name = 'GC_722',
                  value = '-((delta*gwD6*ImCuW13)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_723 = Coupling(name = 'GC_723',
                  value = '(delta*gwD6*ImCuW13)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_724 = Coupling(name = 'GC_724',
                  value = '-((delta*gwD6*ImCuW13)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_725 = Coupling(name = 'GC_725',
                  value = '(delta*gwD6*ImCuW13)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW13)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_726 = Coupling(name = 'GC_726',
                  value = '-(cwD6*delta*gwD6*ImCuW13) - cwD6*delta*complex(0,1)*gwD6*ReCuW13',
                  order = {'NP':2,'QED':2})

GC_727 = Coupling(name = 'GC_727',
                  value = 'cwD6*delta*gwD6*ImCuW13 - cwD6*delta*complex(0,1)*gwD6*ReCuW13',
                  order = {'NP':2,'QED':2})

GC_728 = Coupling(name = 'GC_728',
                  value = '-(cwD6*delta*gwD6*ImCuW13) + cwD6*delta*complex(0,1)*gwD6*ReCuW13',
                  order = {'NP':2,'QED':2})

GC_729 = Coupling(name = 'GC_729',
                  value = 'cwD6*delta*gwD6*ImCuW13 + cwD6*delta*complex(0,1)*gwD6*ReCuW13',
                  order = {'NP':2,'QED':2})

GC_730 = Coupling(name = 'GC_730',
                  value = '-(delta*ImCuW21) + delta*complex(0,1)*ReCuW21',
                  order = {'NP':2,'QED':1})

GC_731 = Coupling(name = 'GC_731',
                  value = 'delta*ImCuW21 + delta*complex(0,1)*ReCuW21',
                  order = {'NP':2,'QED':1})

GC_732 = Coupling(name = 'GC_732',
                  value = '-((delta*gwD6*ImCuW21)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_733 = Coupling(name = 'GC_733',
                  value = '(delta*gwD6*ImCuW21)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_734 = Coupling(name = 'GC_734',
                  value = '-((delta*gwD6*ImCuW21)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_735 = Coupling(name = 'GC_735',
                  value = '(delta*gwD6*ImCuW21)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW21)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_736 = Coupling(name = 'GC_736',
                  value = '-(cwD6*delta*gwD6*ImCuW21) - cwD6*delta*complex(0,1)*gwD6*ReCuW21',
                  order = {'NP':2,'QED':2})

GC_737 = Coupling(name = 'GC_737',
                  value = 'cwD6*delta*gwD6*ImCuW21 - cwD6*delta*complex(0,1)*gwD6*ReCuW21',
                  order = {'NP':2,'QED':2})

GC_738 = Coupling(name = 'GC_738',
                  value = '-(cwD6*delta*gwD6*ImCuW21) + cwD6*delta*complex(0,1)*gwD6*ReCuW21',
                  order = {'NP':2,'QED':2})

GC_739 = Coupling(name = 'GC_739',
                  value = 'cwD6*delta*gwD6*ImCuW21 + cwD6*delta*complex(0,1)*gwD6*ReCuW21',
                  order = {'NP':2,'QED':2})

GC_740 = Coupling(name = 'GC_740',
                  value = '-(delta*ImCuW22) + delta*complex(0,1)*ReCuW22',
                  order = {'NP':2,'QED':1})

GC_741 = Coupling(name = 'GC_741',
                  value = 'delta*ImCuW22 + delta*complex(0,1)*ReCuW22',
                  order = {'NP':2,'QED':1})

GC_742 = Coupling(name = 'GC_742',
                  value = '-((delta*gwD6*ImCuW22)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_743 = Coupling(name = 'GC_743',
                  value = '(delta*gwD6*ImCuW22)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_744 = Coupling(name = 'GC_744',
                  value = '-((delta*gwD6*ImCuW22)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_745 = Coupling(name = 'GC_745',
                  value = '(delta*gwD6*ImCuW22)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW22)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_746 = Coupling(name = 'GC_746',
                  value = '-(cwD6*delta*gwD6*ImCuW22) - cwD6*delta*complex(0,1)*gwD6*ReCuW22',
                  order = {'NP':2,'QED':2})

GC_747 = Coupling(name = 'GC_747',
                  value = 'cwD6*delta*gwD6*ImCuW22 - cwD6*delta*complex(0,1)*gwD6*ReCuW22',
                  order = {'NP':2,'QED':2})

GC_748 = Coupling(name = 'GC_748',
                  value = '-(cwD6*delta*gwD6*ImCuW22) + cwD6*delta*complex(0,1)*gwD6*ReCuW22',
                  order = {'NP':2,'QED':2})

GC_749 = Coupling(name = 'GC_749',
                  value = 'cwD6*delta*gwD6*ImCuW22 + cwD6*delta*complex(0,1)*gwD6*ReCuW22',
                  order = {'NP':2,'QED':2})

GC_750 = Coupling(name = 'GC_750',
                  value = '-(delta*ImCuW23) + delta*complex(0,1)*ReCuW23',
                  order = {'NP':2,'QED':1})

GC_751 = Coupling(name = 'GC_751',
                  value = 'delta*ImCuW23 + delta*complex(0,1)*ReCuW23',
                  order = {'NP':2,'QED':1})

GC_752 = Coupling(name = 'GC_752',
                  value = '-((delta*gwD6*ImCuW23)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_753 = Coupling(name = 'GC_753',
                  value = '(delta*gwD6*ImCuW23)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_754 = Coupling(name = 'GC_754',
                  value = '-((delta*gwD6*ImCuW23)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_755 = Coupling(name = 'GC_755',
                  value = '(delta*gwD6*ImCuW23)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW23)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_756 = Coupling(name = 'GC_756',
                  value = '-(cwD6*delta*gwD6*ImCuW23) - cwD6*delta*complex(0,1)*gwD6*ReCuW23',
                  order = {'NP':2,'QED':2})

GC_757 = Coupling(name = 'GC_757',
                  value = 'cwD6*delta*gwD6*ImCuW23 - cwD6*delta*complex(0,1)*gwD6*ReCuW23',
                  order = {'NP':2,'QED':2})

GC_758 = Coupling(name = 'GC_758',
                  value = '-(cwD6*delta*gwD6*ImCuW23) + cwD6*delta*complex(0,1)*gwD6*ReCuW23',
                  order = {'NP':2,'QED':2})

GC_759 = Coupling(name = 'GC_759',
                  value = 'cwD6*delta*gwD6*ImCuW23 + cwD6*delta*complex(0,1)*gwD6*ReCuW23',
                  order = {'NP':2,'QED':2})

GC_760 = Coupling(name = 'GC_760',
                  value = '-(delta*ImCuW31) + delta*complex(0,1)*ReCuW31',
                  order = {'NP':2,'QED':1})

GC_761 = Coupling(name = 'GC_761',
                  value = 'delta*ImCuW31 + delta*complex(0,1)*ReCuW31',
                  order = {'NP':2,'QED':1})

GC_762 = Coupling(name = 'GC_762',
                  value = '-((delta*gwD6*ImCuW31)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_763 = Coupling(name = 'GC_763',
                  value = '(delta*gwD6*ImCuW31)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_764 = Coupling(name = 'GC_764',
                  value = '-((delta*gwD6*ImCuW31)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_765 = Coupling(name = 'GC_765',
                  value = '(delta*gwD6*ImCuW31)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW31)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_766 = Coupling(name = 'GC_766',
                  value = '-(cwD6*delta*gwD6*ImCuW31) - cwD6*delta*complex(0,1)*gwD6*ReCuW31',
                  order = {'NP':2,'QED':2})

GC_767 = Coupling(name = 'GC_767',
                  value = 'cwD6*delta*gwD6*ImCuW31 - cwD6*delta*complex(0,1)*gwD6*ReCuW31',
                  order = {'NP':2,'QED':2})

GC_768 = Coupling(name = 'GC_768',
                  value = '-(cwD6*delta*gwD6*ImCuW31) + cwD6*delta*complex(0,1)*gwD6*ReCuW31',
                  order = {'NP':2,'QED':2})

GC_769 = Coupling(name = 'GC_769',
                  value = 'cwD6*delta*gwD6*ImCuW31 + cwD6*delta*complex(0,1)*gwD6*ReCuW31',
                  order = {'NP':2,'QED':2})

GC_770 = Coupling(name = 'GC_770',
                  value = '-(delta*ImCuW32) + delta*complex(0,1)*ReCuW32',
                  order = {'NP':2,'QED':1})

GC_771 = Coupling(name = 'GC_771',
                  value = 'delta*ImCuW32 + delta*complex(0,1)*ReCuW32',
                  order = {'NP':2,'QED':1})

GC_772 = Coupling(name = 'GC_772',
                  value = '-((delta*gwD6*ImCuW32)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_773 = Coupling(name = 'GC_773',
                  value = '(delta*gwD6*ImCuW32)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_774 = Coupling(name = 'GC_774',
                  value = '-((delta*gwD6*ImCuW32)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_775 = Coupling(name = 'GC_775',
                  value = '(delta*gwD6*ImCuW32)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW32)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_776 = Coupling(name = 'GC_776',
                  value = '-(cwD6*delta*gwD6*ImCuW32) - cwD6*delta*complex(0,1)*gwD6*ReCuW32',
                  order = {'NP':2,'QED':2})

GC_777 = Coupling(name = 'GC_777',
                  value = 'cwD6*delta*gwD6*ImCuW32 - cwD6*delta*complex(0,1)*gwD6*ReCuW32',
                  order = {'NP':2,'QED':2})

GC_778 = Coupling(name = 'GC_778',
                  value = '-(cwD6*delta*gwD6*ImCuW32) + cwD6*delta*complex(0,1)*gwD6*ReCuW32',
                  order = {'NP':2,'QED':2})

GC_779 = Coupling(name = 'GC_779',
                  value = 'cwD6*delta*gwD6*ImCuW32 + cwD6*delta*complex(0,1)*gwD6*ReCuW32',
                  order = {'NP':2,'QED':2})

GC_780 = Coupling(name = 'GC_780',
                  value = '-(delta*ImCuW33) + delta*complex(0,1)*ReCuW33',
                  order = {'NP':2,'QED':1})

GC_781 = Coupling(name = 'GC_781',
                  value = 'delta*ImCuW33 + delta*complex(0,1)*ReCuW33',
                  order = {'NP':2,'QED':1})

GC_782 = Coupling(name = 'GC_782',
                  value = '-((delta*gwD6*ImCuW33)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_783 = Coupling(name = 'GC_783',
                  value = '(delta*gwD6*ImCuW33)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_784 = Coupling(name = 'GC_784',
                  value = '-((delta*gwD6*ImCuW33)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_785 = Coupling(name = 'GC_785',
                  value = '(delta*gwD6*ImCuW33)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW33)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':2})

GC_786 = Coupling(name = 'GC_786',
                  value = '-(cwD6*delta*gwD6*ImCuW33) - cwD6*delta*complex(0,1)*gwD6*ReCuW33',
                  order = {'NP':2,'QED':2})

GC_787 = Coupling(name = 'GC_787',
                  value = 'cwD6*delta*gwD6*ImCuW33 - cwD6*delta*complex(0,1)*gwD6*ReCuW33',
                  order = {'NP':2,'QED':2})

GC_788 = Coupling(name = 'GC_788',
                  value = '-(cwD6*delta*gwD6*ImCuW33) + cwD6*delta*complex(0,1)*gwD6*ReCuW33',
                  order = {'NP':2,'QED':2})

GC_789 = Coupling(name = 'GC_789',
                  value = 'cwD6*delta*gwD6*ImCuW33 + cwD6*delta*complex(0,1)*gwD6*ReCuW33',
                  order = {'NP':2,'QED':2})

GC_790 = Coupling(name = 'GC_790',
                  value = '6*CW*delta*complex(0,1)*swD6',
                  order = {'NP':2})

GC_791 = Coupling(name = 'GC_791',
                  value = '-(complex(0,1)*g1D6*swD6)/6.',
                  order = {'QED':1})

GC_792 = Coupling(name = 'GC_792',
                  value = '(complex(0,1)*g1D6*swD6)/2.',
                  order = {'QED':1})

GC_793 = Coupling(name = 'GC_793',
                  value = '-(complex(0,1)*gwD6*swD6)/2.',
                  order = {'QED':1})

GC_794 = Coupling(name = 'GC_794',
                  value = '(complex(0,1)*gwD6*swD6)/2.',
                  order = {'QED':1})

GC_795 = Coupling(name = 'GC_795',
                  value = 'complex(0,1)*gwD6*swD6',
                  order = {'QED':1})

GC_796 = Coupling(name = 'GC_796',
                  value = '-4*CPhiW*delta*complex(0,1)*gwD6*swD6',
                  order = {'NP':2,'QED':3})

GC_797 = Coupling(name = 'GC_797',
                  value = '-2*CPhiWB*delta*complex(0,1)*gwD6*swD6',
                  order = {'NP':2,'QED':3})

GC_798 = Coupling(name = 'GC_798',
                  value = '-6*CW*cwD6*delta*complex(0,1)*gwD6*swD6',
                  order = {'NP':2,'QED':1})

GC_799 = Coupling(name = 'GC_799',
                  value = '-2*cwD6*complex(0,1)*gwD6**2*swD6',
                  order = {'QED':2})

GC_800 = Coupling(name = 'GC_800',
                  value = '-6*CW*delta*complex(0,1)*gwD6**2*swD6',
                  order = {'NP':2,'QED':2})

GC_801 = Coupling(name = 'GC_801',
                  value = '8*CPhiW*cwD6*delta*complex(0,1)*gwD6**2*swD6',
                  order = {'NP':2,'QED':4})

GC_802 = Coupling(name = 'GC_802',
                  value = '-6*CW*cwD6**2*delta*complex(0,1)*gwD6**2*swD6',
                  order = {'NP':2,'QED':2})

GC_803 = Coupling(name = 'GC_803',
                  value = '24*CW*cwD6*delta*complex(0,1)*gwD6**3*swD6',
                  order = {'NP':2,'QED':3})

GC_804 = Coupling(name = 'GC_804',
                  value = '-((delta*ImCdW33*swD6)/cmath.sqrt(2))',
                  order = {'NP':2,'QED':1})

GC_805 = Coupling(name = 'GC_805',
                  value = 'delta*gwD6*ImCeW32*swD6',
                  order = {'NP':2,'QED':2})

GC_806 = Coupling(name = 'GC_806',
                  value = 'delta*complex(0,1)*gwD6*ReCeW32*swD6',
                  order = {'NP':2,'QED':2})

GC_807 = Coupling(name = 'GC_807',
                  value = '6*CW*delta*complex(0,1)*gwD6*swD6**2',
                  order = {'NP':2,'QED':1})

GC_808 = Coupling(name = 'GC_808',
                  value = 'complex(0,1)*gwD6**2*swD6**2',
                  order = {'QED':2})

GC_809 = Coupling(name = 'GC_809',
                  value = '-4*CPhiW*delta*complex(0,1)*gwD6**2*swD6**2',
                  order = {'NP':2,'QED':4})

GC_810 = Coupling(name = 'GC_810',
                  value = '-6*CW*cwD6*delta*complex(0,1)*gwD6**2*swD6**2',
                  order = {'NP':2,'QED':2})

GC_811 = Coupling(name = 'GC_811',
                  value = '24*CW*delta*complex(0,1)*gwD6**3*swD6**2',
                  order = {'NP':2,'QED':3})

GC_812 = Coupling(name = 'GC_812',
                  value = '-12*CW*delta*complex(0,1)*gwD6**2*swD6**3',
                  order = {'NP':2,'QED':2})

GC_813 = Coupling(name = 'GC_813',
                  value = '(cwD6*complex(0,1)*gwD6)/2. + (complex(0,1)*g1D6*swD6)/2.',
                  order = {'QED':1})

GC_814 = Coupling(name = 'GC_814',
                  value = '-(cwD6*complex(0,1)*g1D6)/2. + (complex(0,1)*gwD6*swD6)/2.',
                  order = {'QED':1})

GC_815 = Coupling(name = 'GC_815',
                  value = '-((cwD6*delta*ImCdW11)/cmath.sqrt(2)) - (delta*ImCdB11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_816 = Coupling(name = 'GC_816',
                  value = '-((cwD6*delta*ImCdW22)/cmath.sqrt(2)) - (delta*ImCdB22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_817 = Coupling(name = 'GC_817',
                  value = '-((cwD6*delta*ImCdW33)/cmath.sqrt(2)) - (delta*ImCdB33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_818 = Coupling(name = 'GC_818',
                  value = '(cwD6*delta*ImCdB11)/cmath.sqrt(2) - (delta*ImCdW11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_819 = Coupling(name = 'GC_819',
                  value = '(cwD6*delta*ImCdB22)/cmath.sqrt(2) - (delta*ImCdW22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_820 = Coupling(name = 'GC_820',
                  value = '-((cwD6*delta*ImCeW11)/cmath.sqrt(2)) - (delta*ImCeB11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_821 = Coupling(name = 'GC_821',
                  value = '-((cwD6*delta*ImCeW22)/cmath.sqrt(2)) - (delta*ImCeB22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_822 = Coupling(name = 'GC_822',
                  value = '-((cwD6*delta*ImCeW33)/cmath.sqrt(2)) - (delta*ImCeB33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_823 = Coupling(name = 'GC_823',
                  value = '(cwD6*delta*ImCeB11)/cmath.sqrt(2) - (delta*ImCeW11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_824 = Coupling(name = 'GC_824',
                  value = '(cwD6*delta*ImCeB22)/cmath.sqrt(2) - (delta*ImCeW22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_825 = Coupling(name = 'GC_825',
                  value = '(cwD6*delta*ImCeB33)/cmath.sqrt(2) - (delta*ImCeW33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_826 = Coupling(name = 'GC_826',
                  value = '(cwD6*delta*ImCuW11)/cmath.sqrt(2) - (delta*ImCuB11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_827 = Coupling(name = 'GC_827',
                  value = '(cwD6*delta*ImCuW22)/cmath.sqrt(2) - (delta*ImCuB22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_828 = Coupling(name = 'GC_828',
                  value = '(cwD6*delta*ImCuW33)/cmath.sqrt(2) - (delta*ImCuB33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_829 = Coupling(name = 'GC_829',
                  value = '(cwD6*delta*ImCuB11)/cmath.sqrt(2) + (delta*ImCuW11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_830 = Coupling(name = 'GC_830',
                  value = '(cwD6*delta*ImCuB22)/cmath.sqrt(2) + (delta*ImCuW22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_831 = Coupling(name = 'GC_831',
                  value = '(cwD6*delta*ImCuB33)/cmath.sqrt(2) + (delta*ImCuW33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_832 = Coupling(name = 'GC_832',
                  value = '-2*cwD6*delta*complex(0,1)*gwD6*ReC1Phil33 - 2*delta*complex(0,1)*g1D6*ReC1Phil33*swD6',
                  order = {'NP':2,'QED':3})

GC_833 = Coupling(name = 'GC_833',
                  value = '2*cwD6*delta*complex(0,1)*g1D6*ReC1Phil33 - 2*delta*complex(0,1)*gwD6*ReC1Phil33*swD6',
                  order = {'NP':2,'QED':3})

GC_834 = Coupling(name = 'GC_834',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil11) - cwD6*delta*complex(0,1)*gwD6*ReC3Phil11 - delta*complex(0,1)*g1D6*ReC1Phil11*swD6 - delta*complex(0,1)*g1D6*ReC3Phil11*swD6',
                  order = {'NP':2,'QED':3})

GC_835 = Coupling(name = 'GC_835',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil11) + cwD6*delta*complex(0,1)*gwD6*ReC3Phil11 - delta*complex(0,1)*g1D6*ReC1Phil11*swD6 + delta*complex(0,1)*g1D6*ReC3Phil11*swD6',
                  order = {'NP':2,'QED':3})

GC_836 = Coupling(name = 'GC_836',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil11 + cwD6*delta*complex(0,1)*g1D6*ReC3Phil11 - delta*complex(0,1)*gwD6*ReC1Phil11*swD6 - delta*complex(0,1)*gwD6*ReC3Phil11*swD6',
                  order = {'NP':2,'QED':3})

GC_837 = Coupling(name = 'GC_837',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil11 - cwD6*delta*complex(0,1)*g1D6*ReC3Phil11 - delta*complex(0,1)*gwD6*ReC1Phil11*swD6 + delta*complex(0,1)*gwD6*ReC3Phil11*swD6',
                  order = {'NP':2,'QED':3})

GC_838 = Coupling(name = 'GC_838',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil22) - cwD6*delta*complex(0,1)*gwD6*ReC3Phil22 - delta*complex(0,1)*g1D6*ReC1Phil22*swD6 - delta*complex(0,1)*g1D6*ReC3Phil22*swD6',
                  order = {'NP':2,'QED':3})

GC_839 = Coupling(name = 'GC_839',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil22) + cwD6*delta*complex(0,1)*gwD6*ReC3Phil22 - delta*complex(0,1)*g1D6*ReC1Phil22*swD6 + delta*complex(0,1)*g1D6*ReC3Phil22*swD6',
                  order = {'NP':2,'QED':3})

GC_840 = Coupling(name = 'GC_840',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil22 + cwD6*delta*complex(0,1)*g1D6*ReC3Phil22 - delta*complex(0,1)*gwD6*ReC1Phil22*swD6 - delta*complex(0,1)*gwD6*ReC3Phil22*swD6',
                  order = {'NP':2,'QED':3})

GC_841 = Coupling(name = 'GC_841',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil22 - cwD6*delta*complex(0,1)*g1D6*ReC3Phil22 - delta*complex(0,1)*gwD6*ReC1Phil22*swD6 + delta*complex(0,1)*gwD6*ReC3Phil22*swD6',
                  order = {'NP':2,'QED':3})

GC_842 = Coupling(name = 'GC_842',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq11) - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq11 - delta*complex(0,1)*g1D6*ReC1Phiq11*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq11*swD6',
                  order = {'NP':2,'QED':3})

GC_843 = Coupling(name = 'GC_843',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq11) + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq11 - delta*complex(0,1)*g1D6*ReC1Phiq11*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq11*swD6',
                  order = {'NP':2,'QED':3})

GC_844 = Coupling(name = 'GC_844',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq11 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq11 - delta*complex(0,1)*gwD6*ReC1Phiq11*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq11*swD6',
                  order = {'NP':2,'QED':3})

GC_845 = Coupling(name = 'GC_845',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq11 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq11 - delta*complex(0,1)*gwD6*ReC1Phiq11*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq11*swD6',
                  order = {'NP':2,'QED':3})

GC_846 = Coupling(name = 'GC_846',
                  value = '-(cwD6*delta*gwD6*ImC1Phiq12) - cwD6*delta*gwD6*ImC3Phiq12 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12 - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12 - delta*g1D6*ImC1Phiq12*swD6 - delta*g1D6*ImC3Phiq12*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_847 = Coupling(name = 'GC_847',
                  value = 'cwD6*delta*gwD6*ImC1Phiq12 + cwD6*delta*gwD6*ImC3Phiq12 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12 - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12 + delta*g1D6*ImC1Phiq12*swD6 + delta*g1D6*ImC3Phiq12*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_848 = Coupling(name = 'GC_848',
                  value = 'cwD6*delta*gwD6*ImC1Phiq12 - cwD6*delta*gwD6*ImC3Phiq12 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12 + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12 + delta*g1D6*ImC1Phiq12*swD6 - delta*g1D6*ImC3Phiq12*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_849 = Coupling(name = 'GC_849',
                  value = '-(cwD6*delta*gwD6*ImC1Phiq12) + cwD6*delta*gwD6*ImC3Phiq12 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12 + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12 - delta*g1D6*ImC1Phiq12*swD6 + delta*g1D6*ImC3Phiq12*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_850 = Coupling(name = 'GC_850',
                  value = 'cwD6*delta*g1D6*ImC1Phiq12 + cwD6*delta*g1D6*ImC3Phiq12 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12 - delta*gwD6*ImC1Phiq12*swD6 - delta*gwD6*ImC3Phiq12*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_851 = Coupling(name = 'GC_851',
                  value = '-(cwD6*delta*g1D6*ImC1Phiq12) - cwD6*delta*g1D6*ImC3Phiq12 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12 + delta*gwD6*ImC1Phiq12*swD6 + delta*gwD6*ImC3Phiq12*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_852 = Coupling(name = 'GC_852',
                  value = '-(cwD6*delta*g1D6*ImC1Phiq12) + cwD6*delta*g1D6*ImC3Phiq12 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12 + delta*gwD6*ImC1Phiq12*swD6 - delta*gwD6*ImC3Phiq12*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_853 = Coupling(name = 'GC_853',
                  value = 'cwD6*delta*g1D6*ImC1Phiq12 - cwD6*delta*g1D6*ImC3Phiq12 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12 - delta*gwD6*ImC1Phiq12*swD6 + delta*gwD6*ImC3Phiq12*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq12*swD6',
                  order = {'NP':2,'QED':3})

GC_854 = Coupling(name = 'GC_854',
                  value = '-(cwD6*delta*gwD6*ImC1Phiq13) - cwD6*delta*gwD6*ImC3Phiq13 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13 - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13 - delta*g1D6*ImC1Phiq13*swD6 - delta*g1D6*ImC3Phiq13*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_855 = Coupling(name = 'GC_855',
                  value = 'cwD6*delta*gwD6*ImC1Phiq13 + cwD6*delta*gwD6*ImC3Phiq13 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13 - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13 + delta*g1D6*ImC1Phiq13*swD6 + delta*g1D6*ImC3Phiq13*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_856 = Coupling(name = 'GC_856',
                  value = 'cwD6*delta*gwD6*ImC1Phiq13 - cwD6*delta*gwD6*ImC3Phiq13 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13 + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13 + delta*g1D6*ImC1Phiq13*swD6 - delta*g1D6*ImC3Phiq13*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_857 = Coupling(name = 'GC_857',
                  value = '-(cwD6*delta*gwD6*ImC1Phiq13) + cwD6*delta*gwD6*ImC3Phiq13 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13 + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13 - delta*g1D6*ImC1Phiq13*swD6 + delta*g1D6*ImC3Phiq13*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_858 = Coupling(name = 'GC_858',
                  value = 'cwD6*delta*g1D6*ImC1Phiq13 + cwD6*delta*g1D6*ImC3Phiq13 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13 - delta*gwD6*ImC1Phiq13*swD6 - delta*gwD6*ImC3Phiq13*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_859 = Coupling(name = 'GC_859',
                  value = '-(cwD6*delta*g1D6*ImC1Phiq13) - cwD6*delta*g1D6*ImC3Phiq13 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13 + delta*gwD6*ImC1Phiq13*swD6 + delta*gwD6*ImC3Phiq13*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_860 = Coupling(name = 'GC_860',
                  value = '-(cwD6*delta*g1D6*ImC1Phiq13) + cwD6*delta*g1D6*ImC3Phiq13 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13 + delta*gwD6*ImC1Phiq13*swD6 - delta*gwD6*ImC3Phiq13*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_861 = Coupling(name = 'GC_861',
                  value = 'cwD6*delta*g1D6*ImC1Phiq13 - cwD6*delta*g1D6*ImC3Phiq13 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13 - delta*gwD6*ImC1Phiq13*swD6 + delta*gwD6*ImC3Phiq13*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq13*swD6',
                  order = {'NP':2,'QED':3})

GC_862 = Coupling(name = 'GC_862',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq22) - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq22 - delta*complex(0,1)*g1D6*ReC1Phiq22*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq22*swD6',
                  order = {'NP':2,'QED':3})

GC_863 = Coupling(name = 'GC_863',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq22) + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq22 - delta*complex(0,1)*g1D6*ReC1Phiq22*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq22*swD6',
                  order = {'NP':2,'QED':3})

GC_864 = Coupling(name = 'GC_864',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq22 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq22 - delta*complex(0,1)*gwD6*ReC1Phiq22*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq22*swD6',
                  order = {'NP':2,'QED':3})

GC_865 = Coupling(name = 'GC_865',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq22 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq22 - delta*complex(0,1)*gwD6*ReC1Phiq22*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq22*swD6',
                  order = {'NP':2,'QED':3})

GC_866 = Coupling(name = 'GC_866',
                  value = '-(cwD6*delta*gwD6*ImC1Phiq23) - cwD6*delta*gwD6*ImC3Phiq23 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23 - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23 - delta*g1D6*ImC1Phiq23*swD6 - delta*g1D6*ImC3Phiq23*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_867 = Coupling(name = 'GC_867',
                  value = 'cwD6*delta*gwD6*ImC1Phiq23 + cwD6*delta*gwD6*ImC3Phiq23 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23 - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23 + delta*g1D6*ImC1Phiq23*swD6 + delta*g1D6*ImC3Phiq23*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_868 = Coupling(name = 'GC_868',
                  value = 'cwD6*delta*gwD6*ImC1Phiq23 - cwD6*delta*gwD6*ImC3Phiq23 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23 + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23 + delta*g1D6*ImC1Phiq23*swD6 - delta*g1D6*ImC3Phiq23*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_869 = Coupling(name = 'GC_869',
                  value = '-(cwD6*delta*gwD6*ImC1Phiq23) + cwD6*delta*gwD6*ImC3Phiq23 - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23 + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23 - delta*g1D6*ImC1Phiq23*swD6 + delta*g1D6*ImC3Phiq23*swD6 - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_870 = Coupling(name = 'GC_870',
                  value = 'cwD6*delta*g1D6*ImC1Phiq23 + cwD6*delta*g1D6*ImC3Phiq23 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23 - delta*gwD6*ImC1Phiq23*swD6 - delta*gwD6*ImC3Phiq23*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_871 = Coupling(name = 'GC_871',
                  value = '-(cwD6*delta*g1D6*ImC1Phiq23) - cwD6*delta*g1D6*ImC3Phiq23 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23 + delta*gwD6*ImC1Phiq23*swD6 + delta*gwD6*ImC3Phiq23*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_872 = Coupling(name = 'GC_872',
                  value = '-(cwD6*delta*g1D6*ImC1Phiq23) + cwD6*delta*g1D6*ImC3Phiq23 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23 + delta*gwD6*ImC1Phiq23*swD6 - delta*gwD6*ImC3Phiq23*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_873 = Coupling(name = 'GC_873',
                  value = 'cwD6*delta*g1D6*ImC1Phiq23 - cwD6*delta*g1D6*ImC3Phiq23 + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23 - delta*gwD6*ImC1Phiq23*swD6 + delta*gwD6*ImC3Phiq23*swD6 - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq23*swD6',
                  order = {'NP':2,'QED':3})

GC_874 = Coupling(name = 'GC_874',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq33) - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq33 - delta*complex(0,1)*g1D6*ReC1Phiq33*swD6 - delta*complex(0,1)*g1D6*ReC3Phiq33*swD6',
                  order = {'NP':2,'QED':3})

GC_875 = Coupling(name = 'GC_875',
                  value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq33) + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq33 - delta*complex(0,1)*g1D6*ReC1Phiq33*swD6 + delta*complex(0,1)*g1D6*ReC3Phiq33*swD6',
                  order = {'NP':2,'QED':3})

GC_876 = Coupling(name = 'GC_876',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq33 + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq33 - delta*complex(0,1)*gwD6*ReC1Phiq33*swD6 - delta*complex(0,1)*gwD6*ReC3Phiq33*swD6',
                  order = {'NP':2,'QED':3})

GC_877 = Coupling(name = 'GC_877',
                  value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq33 - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq33 - delta*complex(0,1)*gwD6*ReC1Phiq33*swD6 + delta*complex(0,1)*gwD6*ReC3Phiq33*swD6',
                  order = {'NP':2,'QED':3})

GC_878 = Coupling(name = 'GC_878',
                  value = '-((cwD6*delta*complex(0,1)*ReCdW11)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCdB11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_879 = Coupling(name = 'GC_879',
                  value = '-((cwD6*delta*ImCdW12)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW12)/cmath.sqrt(2) - (delta*ImCdB12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_880 = Coupling(name = 'GC_880',
                  value = '(cwD6*delta*ImCdW12)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW12)/cmath.sqrt(2) + (delta*ImCdB12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_881 = Coupling(name = 'GC_881',
                  value = '-((cwD6*delta*ImCdW13)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW13)/cmath.sqrt(2) - (delta*ImCdB13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_882 = Coupling(name = 'GC_882',
                  value = '(cwD6*delta*ImCdW13)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW13)/cmath.sqrt(2) + (delta*ImCdB13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_883 = Coupling(name = 'GC_883',
                  value = '-((cwD6*delta*ImCdW21)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW21)/cmath.sqrt(2) - (delta*ImCdB21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_884 = Coupling(name = 'GC_884',
                  value = '(cwD6*delta*ImCdW21)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW21)/cmath.sqrt(2) + (delta*ImCdB21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_885 = Coupling(name = 'GC_885',
                  value = '-((cwD6*delta*complex(0,1)*ReCdW22)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCdB22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_886 = Coupling(name = 'GC_886',
                  value = '-((cwD6*delta*ImCdW23)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW23)/cmath.sqrt(2) - (delta*ImCdB23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_887 = Coupling(name = 'GC_887',
                  value = '(cwD6*delta*ImCdW23)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW23)/cmath.sqrt(2) + (delta*ImCdB23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_888 = Coupling(name = 'GC_888',
                  value = '-((cwD6*delta*ImCdW31)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW31)/cmath.sqrt(2) - (delta*ImCdB31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_889 = Coupling(name = 'GC_889',
                  value = '(cwD6*delta*ImCdW31)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW31)/cmath.sqrt(2) + (delta*ImCdB31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_890 = Coupling(name = 'GC_890',
                  value = '-((cwD6*delta*ImCdW32)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW32)/cmath.sqrt(2) - (delta*ImCdB32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB32*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_891 = Coupling(name = 'GC_891',
                  value = '(cwD6*delta*ImCdW32)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW32)/cmath.sqrt(2) + (delta*ImCdB32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB32*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_892 = Coupling(name = 'GC_892',
                  value = '-((cwD6*delta*complex(0,1)*ReCdW33)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCdB33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_893 = Coupling(name = 'GC_893',
                  value = '(cwD6*delta*complex(0,1)*ReCdB11)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_894 = Coupling(name = 'GC_894',
                  value = '-(delta*gwD6*ImCdW11*swD6) - delta*complex(0,1)*gwD6*ReCdW11*swD6',
                  order = {'NP':2,'QED':2})

GC_895 = Coupling(name = 'GC_895',
                  value = 'delta*gwD6*ImCdW11*swD6 - delta*complex(0,1)*gwD6*ReCdW11*swD6',
                  order = {'NP':2,'QED':2})

GC_896 = Coupling(name = 'GC_896',
                  value = '-(delta*gwD6*ImCdW11*swD6) + delta*complex(0,1)*gwD6*ReCdW11*swD6',
                  order = {'NP':2,'QED':2})

GC_897 = Coupling(name = 'GC_897',
                  value = 'delta*gwD6*ImCdW11*swD6 + delta*complex(0,1)*gwD6*ReCdW11*swD6',
                  order = {'NP':2,'QED':2})

GC_898 = Coupling(name = 'GC_898',
                  value = '(cwD6*delta*ImCdB12)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB12)/cmath.sqrt(2) - (delta*ImCdW12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_899 = Coupling(name = 'GC_899',
                  value = '-((cwD6*delta*ImCdB12)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB12)/cmath.sqrt(2) + (delta*ImCdW12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_900 = Coupling(name = 'GC_900',
                  value = '-(delta*gwD6*ImCdW12*swD6) - delta*complex(0,1)*gwD6*ReCdW12*swD6',
                  order = {'NP':2,'QED':2})

GC_901 = Coupling(name = 'GC_901',
                  value = 'delta*gwD6*ImCdW12*swD6 - delta*complex(0,1)*gwD6*ReCdW12*swD6',
                  order = {'NP':2,'QED':2})

GC_902 = Coupling(name = 'GC_902',
                  value = '-(delta*gwD6*ImCdW12*swD6) + delta*complex(0,1)*gwD6*ReCdW12*swD6',
                  order = {'NP':2,'QED':2})

GC_903 = Coupling(name = 'GC_903',
                  value = 'delta*gwD6*ImCdW12*swD6 + delta*complex(0,1)*gwD6*ReCdW12*swD6',
                  order = {'NP':2,'QED':2})

GC_904 = Coupling(name = 'GC_904',
                  value = '(cwD6*delta*ImCdB13)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB13)/cmath.sqrt(2) - (delta*ImCdW13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_905 = Coupling(name = 'GC_905',
                  value = '-((cwD6*delta*ImCdB13)/cmath.sqrt(2)) + (delta*ImCdW13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_906 = Coupling(name = 'GC_906',
                  value = '-(delta*gwD6*ImCdW13*swD6) - delta*complex(0,1)*gwD6*ReCdW13*swD6',
                  order = {'NP':2,'QED':2})

GC_907 = Coupling(name = 'GC_907',
                  value = 'delta*gwD6*ImCdW13*swD6 - delta*complex(0,1)*gwD6*ReCdW13*swD6',
                  order = {'NP':2,'QED':2})

GC_908 = Coupling(name = 'GC_908',
                  value = '-(delta*gwD6*ImCdW13*swD6) + delta*complex(0,1)*gwD6*ReCdW13*swD6',
                  order = {'NP':2,'QED':2})

GC_909 = Coupling(name = 'GC_909',
                  value = 'delta*gwD6*ImCdW13*swD6 + delta*complex(0,1)*gwD6*ReCdW13*swD6',
                  order = {'NP':2,'QED':2})

GC_910 = Coupling(name = 'GC_910',
                  value = '(cwD6*delta*ImCdB21)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB21)/cmath.sqrt(2) - (delta*ImCdW21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_911 = Coupling(name = 'GC_911',
                  value = '-((cwD6*delta*ImCdB21)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB21)/cmath.sqrt(2) + (delta*ImCdW21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_912 = Coupling(name = 'GC_912',
                  value = '-(delta*gwD6*ImCdW21*swD6) - delta*complex(0,1)*gwD6*ReCdW21*swD6',
                  order = {'NP':2,'QED':2})

GC_913 = Coupling(name = 'GC_913',
                  value = 'delta*gwD6*ImCdW21*swD6 - delta*complex(0,1)*gwD6*ReCdW21*swD6',
                  order = {'NP':2,'QED':2})

GC_914 = Coupling(name = 'GC_914',
                  value = '-(delta*gwD6*ImCdW21*swD6) + delta*complex(0,1)*gwD6*ReCdW21*swD6',
                  order = {'NP':2,'QED':2})

GC_915 = Coupling(name = 'GC_915',
                  value = 'delta*gwD6*ImCdW21*swD6 + delta*complex(0,1)*gwD6*ReCdW21*swD6',
                  order = {'NP':2,'QED':2})

GC_916 = Coupling(name = 'GC_916',
                  value = '(cwD6*delta*complex(0,1)*ReCdB22)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_917 = Coupling(name = 'GC_917',
                  value = '-(delta*gwD6*ImCdW22*swD6) - delta*complex(0,1)*gwD6*ReCdW22*swD6',
                  order = {'NP':2,'QED':2})

GC_918 = Coupling(name = 'GC_918',
                  value = 'delta*gwD6*ImCdW22*swD6 - delta*complex(0,1)*gwD6*ReCdW22*swD6',
                  order = {'NP':2,'QED':2})

GC_919 = Coupling(name = 'GC_919',
                  value = '-(delta*gwD6*ImCdW22*swD6) + delta*complex(0,1)*gwD6*ReCdW22*swD6',
                  order = {'NP':2,'QED':2})

GC_920 = Coupling(name = 'GC_920',
                  value = 'delta*gwD6*ImCdW22*swD6 + delta*complex(0,1)*gwD6*ReCdW22*swD6',
                  order = {'NP':2,'QED':2})

GC_921 = Coupling(name = 'GC_921',
                  value = '(cwD6*delta*ImCdB23)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB23)/cmath.sqrt(2) - (delta*ImCdW23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_922 = Coupling(name = 'GC_922',
                  value = '-((cwD6*delta*ImCdB23)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB23)/cmath.sqrt(2) + (delta*ImCdW23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_923 = Coupling(name = 'GC_923',
                  value = '-(delta*gwD6*ImCdW23*swD6) - delta*complex(0,1)*gwD6*ReCdW23*swD6',
                  order = {'NP':2,'QED':2})

GC_924 = Coupling(name = 'GC_924',
                  value = 'delta*gwD6*ImCdW23*swD6 - delta*complex(0,1)*gwD6*ReCdW23*swD6',
                  order = {'NP':2,'QED':2})

GC_925 = Coupling(name = 'GC_925',
                  value = '-(delta*gwD6*ImCdW23*swD6) + delta*complex(0,1)*gwD6*ReCdW23*swD6',
                  order = {'NP':2,'QED':2})

GC_926 = Coupling(name = 'GC_926',
                  value = 'delta*gwD6*ImCdW23*swD6 + delta*complex(0,1)*gwD6*ReCdW23*swD6',
                  order = {'NP':2,'QED':2})

GC_927 = Coupling(name = 'GC_927',
                  value = '(cwD6*delta*ImCdB31)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB31)/cmath.sqrt(2) - (delta*ImCdW31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_928 = Coupling(name = 'GC_928',
                  value = '-((cwD6*delta*ImCdB31)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB31)/cmath.sqrt(2) + (delta*ImCdW31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_929 = Coupling(name = 'GC_929',
                  value = '-(delta*gwD6*ImCdW31*swD6) - delta*complex(0,1)*gwD6*ReCdW31*swD6',
                  order = {'NP':2,'QED':2})

GC_930 = Coupling(name = 'GC_930',
                  value = 'delta*gwD6*ImCdW31*swD6 - delta*complex(0,1)*gwD6*ReCdW31*swD6',
                  order = {'NP':2,'QED':2})

GC_931 = Coupling(name = 'GC_931',
                  value = '-(delta*gwD6*ImCdW31*swD6) + delta*complex(0,1)*gwD6*ReCdW31*swD6',
                  order = {'NP':2,'QED':2})

GC_932 = Coupling(name = 'GC_932',
                  value = 'delta*gwD6*ImCdW31*swD6 + delta*complex(0,1)*gwD6*ReCdW31*swD6',
                  order = {'NP':2,'QED':2})

GC_933 = Coupling(name = 'GC_933',
                  value = '(cwD6*delta*ImCdB32)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB32)/cmath.sqrt(2) - (delta*ImCdW32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW32*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_934 = Coupling(name = 'GC_934',
                  value = '-((cwD6*delta*ImCdB32)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB32)/cmath.sqrt(2) + (delta*ImCdW32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW32*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_935 = Coupling(name = 'GC_935',
                  value = '-(delta*gwD6*ImCdW32*swD6) - delta*complex(0,1)*gwD6*ReCdW32*swD6',
                  order = {'NP':2,'QED':2})

GC_936 = Coupling(name = 'GC_936',
                  value = 'delta*gwD6*ImCdW32*swD6 - delta*complex(0,1)*gwD6*ReCdW32*swD6',
                  order = {'NP':2,'QED':2})

GC_937 = Coupling(name = 'GC_937',
                  value = '-(delta*gwD6*ImCdW32*swD6) + delta*complex(0,1)*gwD6*ReCdW32*swD6',
                  order = {'NP':2,'QED':2})

GC_938 = Coupling(name = 'GC_938',
                  value = 'delta*gwD6*ImCdW32*swD6 + delta*complex(0,1)*gwD6*ReCdW32*swD6',
                  order = {'NP':2,'QED':2})

GC_939 = Coupling(name = 'GC_939',
                  value = '(cwD6*delta*complex(0,1)*ReCdB33)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_940 = Coupling(name = 'GC_940',
                  value = '-(delta*gwD6*ImCdW33*swD6) - delta*complex(0,1)*gwD6*ReCdW33*swD6',
                  order = {'NP':2,'QED':2})

GC_941 = Coupling(name = 'GC_941',
                  value = 'delta*gwD6*ImCdW33*swD6 - delta*complex(0,1)*gwD6*ReCdW33*swD6',
                  order = {'NP':2,'QED':2})

GC_942 = Coupling(name = 'GC_942',
                  value = '-(delta*gwD6*ImCdW33*swD6) + delta*complex(0,1)*gwD6*ReCdW33*swD6',
                  order = {'NP':2,'QED':2})

GC_943 = Coupling(name = 'GC_943',
                  value = 'delta*gwD6*ImCdW33*swD6 + delta*complex(0,1)*gwD6*ReCdW33*swD6',
                  order = {'NP':2,'QED':2})

GC_944 = Coupling(name = 'GC_944',
                  value = '-((cwD6*delta*complex(0,1)*ReCeW11)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCeB11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_945 = Coupling(name = 'GC_945',
                  value = '-((cwD6*delta*ImCeW12)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW12)/cmath.sqrt(2) - (delta*ImCeB12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_946 = Coupling(name = 'GC_946',
                  value = '(cwD6*delta*ImCeW12)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW12)/cmath.sqrt(2) + (delta*ImCeB12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_947 = Coupling(name = 'GC_947',
                  value = '-((cwD6*delta*ImCeW13)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW13)/cmath.sqrt(2) - (delta*ImCeB13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_948 = Coupling(name = 'GC_948',
                  value = '(cwD6*delta*ImCeW13)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW13)/cmath.sqrt(2) + (delta*ImCeB13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_949 = Coupling(name = 'GC_949',
                  value = '-((cwD6*delta*ImCeW21)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW21)/cmath.sqrt(2) - (delta*ImCeB21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_950 = Coupling(name = 'GC_950',
                  value = '(cwD6*delta*ImCeW21)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW21)/cmath.sqrt(2) + (delta*ImCeB21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_951 = Coupling(name = 'GC_951',
                  value = '-((cwD6*delta*complex(0,1)*ReCeW22)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCeB22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_952 = Coupling(name = 'GC_952',
                  value = '-((cwD6*delta*ImCeW23)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW23)/cmath.sqrt(2) - (delta*ImCeB23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_953 = Coupling(name = 'GC_953',
                  value = '(cwD6*delta*ImCeW23)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW23)/cmath.sqrt(2) + (delta*ImCeB23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_954 = Coupling(name = 'GC_954',
                  value = '-((cwD6*delta*ImCeW31)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW31)/cmath.sqrt(2) - (delta*ImCeB31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_955 = Coupling(name = 'GC_955',
                  value = '(cwD6*delta*ImCeW31)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW31)/cmath.sqrt(2) + (delta*ImCeB31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_956 = Coupling(name = 'GC_956',
                  value = '-((cwD6*delta*ImCeW32)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW32)/cmath.sqrt(2) - (delta*ImCeB32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB32*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_957 = Coupling(name = 'GC_957',
                  value = '(cwD6*delta*ImCeW32)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW32)/cmath.sqrt(2) + (delta*ImCeB32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB32*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_958 = Coupling(name = 'GC_958',
                  value = '-((cwD6*delta*complex(0,1)*ReCeW33)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCeB33*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_959 = Coupling(name = 'GC_959',
                  value = '(cwD6*delta*complex(0,1)*ReCeB11)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW11*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_960 = Coupling(name = 'GC_960',
                  value = '-(delta*gwD6*ImCeW11*swD6) - delta*complex(0,1)*gwD6*ReCeW11*swD6',
                  order = {'NP':2,'QED':2})

GC_961 = Coupling(name = 'GC_961',
                  value = 'delta*gwD6*ImCeW11*swD6 - delta*complex(0,1)*gwD6*ReCeW11*swD6',
                  order = {'NP':2,'QED':2})

GC_962 = Coupling(name = 'GC_962',
                  value = '-(delta*gwD6*ImCeW11*swD6) + delta*complex(0,1)*gwD6*ReCeW11*swD6',
                  order = {'NP':2,'QED':2})

GC_963 = Coupling(name = 'GC_963',
                  value = 'delta*gwD6*ImCeW11*swD6 + delta*complex(0,1)*gwD6*ReCeW11*swD6',
                  order = {'NP':2,'QED':2})

GC_964 = Coupling(name = 'GC_964',
                  value = '(cwD6*delta*ImCeB12)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB12)/cmath.sqrt(2) - (delta*ImCeW12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_965 = Coupling(name = 'GC_965',
                  value = '-((cwD6*delta*ImCeB12)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB12)/cmath.sqrt(2) + (delta*ImCeW12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW12*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_966 = Coupling(name = 'GC_966',
                  value = '-(delta*gwD6*ImCeW12*swD6) - delta*complex(0,1)*gwD6*ReCeW12*swD6',
                  order = {'NP':2,'QED':2})

GC_967 = Coupling(name = 'GC_967',
                  value = 'delta*gwD6*ImCeW12*swD6 - delta*complex(0,1)*gwD6*ReCeW12*swD6',
                  order = {'NP':2,'QED':2})

GC_968 = Coupling(name = 'GC_968',
                  value = '-(delta*gwD6*ImCeW12*swD6) + delta*complex(0,1)*gwD6*ReCeW12*swD6',
                  order = {'NP':2,'QED':2})

GC_969 = Coupling(name = 'GC_969',
                  value = 'delta*gwD6*ImCeW12*swD6 + delta*complex(0,1)*gwD6*ReCeW12*swD6',
                  order = {'NP':2,'QED':2})

GC_970 = Coupling(name = 'GC_970',
                  value = '(cwD6*delta*ImCeB13)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB13)/cmath.sqrt(2) - (delta*ImCeW13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_971 = Coupling(name = 'GC_971',
                  value = '-((cwD6*delta*ImCeB13)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB13)/cmath.sqrt(2) + (delta*ImCeW13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW13*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_972 = Coupling(name = 'GC_972',
                  value = '-(delta*gwD6*ImCeW13*swD6) - delta*complex(0,1)*gwD6*ReCeW13*swD6',
                  order = {'NP':2,'QED':2})

GC_973 = Coupling(name = 'GC_973',
                  value = 'delta*gwD6*ImCeW13*swD6 - delta*complex(0,1)*gwD6*ReCeW13*swD6',
                  order = {'NP':2,'QED':2})

GC_974 = Coupling(name = 'GC_974',
                  value = '-(delta*gwD6*ImCeW13*swD6) + delta*complex(0,1)*gwD6*ReCeW13*swD6',
                  order = {'NP':2,'QED':2})

GC_975 = Coupling(name = 'GC_975',
                  value = 'delta*gwD6*ImCeW13*swD6 + delta*complex(0,1)*gwD6*ReCeW13*swD6',
                  order = {'NP':2,'QED':2})

GC_976 = Coupling(name = 'GC_976',
                  value = '(cwD6*delta*ImCeB21)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB21)/cmath.sqrt(2) - (delta*ImCeW21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_977 = Coupling(name = 'GC_977',
                  value = '-((cwD6*delta*ImCeB21)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB21)/cmath.sqrt(2) + (delta*ImCeW21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW21*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_978 = Coupling(name = 'GC_978',
                  value = '-(delta*gwD6*ImCeW21*swD6) - delta*complex(0,1)*gwD6*ReCeW21*swD6',
                  order = {'NP':2,'QED':2})

GC_979 = Coupling(name = 'GC_979',
                  value = 'delta*gwD6*ImCeW21*swD6 - delta*complex(0,1)*gwD6*ReCeW21*swD6',
                  order = {'NP':2,'QED':2})

GC_980 = Coupling(name = 'GC_980',
                  value = '-(delta*gwD6*ImCeW21*swD6) + delta*complex(0,1)*gwD6*ReCeW21*swD6',
                  order = {'NP':2,'QED':2})

GC_981 = Coupling(name = 'GC_981',
                  value = 'delta*gwD6*ImCeW21*swD6 + delta*complex(0,1)*gwD6*ReCeW21*swD6',
                  order = {'NP':2,'QED':2})

GC_982 = Coupling(name = 'GC_982',
                  value = '(cwD6*delta*complex(0,1)*ReCeB22)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW22*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_983 = Coupling(name = 'GC_983',
                  value = '-(delta*gwD6*ImCeW22*swD6) - delta*complex(0,1)*gwD6*ReCeW22*swD6',
                  order = {'NP':2,'QED':2})

GC_984 = Coupling(name = 'GC_984',
                  value = 'delta*gwD6*ImCeW22*swD6 - delta*complex(0,1)*gwD6*ReCeW22*swD6',
                  order = {'NP':2,'QED':2})

GC_985 = Coupling(name = 'GC_985',
                  value = '-(delta*gwD6*ImCeW22*swD6) + delta*complex(0,1)*gwD6*ReCeW22*swD6',
                  order = {'NP':2,'QED':2})

GC_986 = Coupling(name = 'GC_986',
                  value = 'delta*gwD6*ImCeW22*swD6 + delta*complex(0,1)*gwD6*ReCeW22*swD6',
                  order = {'NP':2,'QED':2})

GC_987 = Coupling(name = 'GC_987',
                  value = '(cwD6*delta*ImCeB23)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB23)/cmath.sqrt(2) - (delta*ImCeW23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_988 = Coupling(name = 'GC_988',
                  value = '-((cwD6*delta*ImCeB23)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB23)/cmath.sqrt(2) + (delta*ImCeW23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW23*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_989 = Coupling(name = 'GC_989',
                  value = '-(delta*gwD6*ImCeW23*swD6) - delta*complex(0,1)*gwD6*ReCeW23*swD6',
                  order = {'NP':2,'QED':2})

GC_990 = Coupling(name = 'GC_990',
                  value = 'delta*gwD6*ImCeW23*swD6 - delta*complex(0,1)*gwD6*ReCeW23*swD6',
                  order = {'NP':2,'QED':2})

GC_991 = Coupling(name = 'GC_991',
                  value = '-(delta*gwD6*ImCeW23*swD6) + delta*complex(0,1)*gwD6*ReCeW23*swD6',
                  order = {'NP':2,'QED':2})

GC_992 = Coupling(name = 'GC_992',
                  value = 'delta*gwD6*ImCeW23*swD6 + delta*complex(0,1)*gwD6*ReCeW23*swD6',
                  order = {'NP':2,'QED':2})

GC_993 = Coupling(name = 'GC_993',
                  value = '(cwD6*delta*ImCeB31)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB31)/cmath.sqrt(2) - (delta*ImCeW31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_994 = Coupling(name = 'GC_994',
                  value = '-((cwD6*delta*ImCeB31)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB31)/cmath.sqrt(2) + (delta*ImCeW31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW31*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_995 = Coupling(name = 'GC_995',
                  value = '-(delta*gwD6*ImCeW31*swD6) - delta*complex(0,1)*gwD6*ReCeW31*swD6',
                  order = {'NP':2,'QED':2})

GC_996 = Coupling(name = 'GC_996',
                  value = 'delta*gwD6*ImCeW31*swD6 - delta*complex(0,1)*gwD6*ReCeW31*swD6',
                  order = {'NP':2,'QED':2})

GC_997 = Coupling(name = 'GC_997',
                  value = '-(delta*gwD6*ImCeW31*swD6) + delta*complex(0,1)*gwD6*ReCeW31*swD6',
                  order = {'NP':2,'QED':2})

GC_998 = Coupling(name = 'GC_998',
                  value = 'delta*gwD6*ImCeW31*swD6 + delta*complex(0,1)*gwD6*ReCeW31*swD6',
                  order = {'NP':2,'QED':2})

GC_999 = Coupling(name = 'GC_999',
                  value = '(cwD6*delta*ImCeB32)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB32)/cmath.sqrt(2) - (delta*ImCeW32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW32*swD6)/cmath.sqrt(2)',
                  order = {'NP':2,'QED':1})

GC_1000 = Coupling(name = 'GC_1000',
                   value = '-((cwD6*delta*ImCeB32)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB32)/cmath.sqrt(2) + (delta*ImCeW32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW32*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1001 = Coupling(name = 'GC_1001',
                   value = '-(delta*gwD6*ImCeW32*swD6) - delta*complex(0,1)*gwD6*ReCeW32*swD6',
                   order = {'NP':2,'QED':2})

GC_1002 = Coupling(name = 'GC_1002',
                   value = 'delta*gwD6*ImCeW32*swD6 - delta*complex(0,1)*gwD6*ReCeW32*swD6',
                   order = {'NP':2,'QED':2})

GC_1003 = Coupling(name = 'GC_1003',
                   value = '-(delta*gwD6*ImCeW32*swD6) + delta*complex(0,1)*gwD6*ReCeW32*swD6',
                   order = {'NP':2,'QED':2})

GC_1004 = Coupling(name = 'GC_1004',
                   value = '(cwD6*delta*complex(0,1)*ReCeB33)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW33*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1005 = Coupling(name = 'GC_1005',
                   value = '-(delta*gwD6*ImCeW33*swD6) - delta*complex(0,1)*gwD6*ReCeW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1006 = Coupling(name = 'GC_1006',
                   value = 'delta*gwD6*ImCeW33*swD6 - delta*complex(0,1)*gwD6*ReCeW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1007 = Coupling(name = 'GC_1007',
                   value = '-(delta*gwD6*ImCeW33*swD6) + delta*complex(0,1)*gwD6*ReCeW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1008 = Coupling(name = 'GC_1008',
                   value = 'delta*gwD6*ImCeW33*swD6 + delta*complex(0,1)*gwD6*ReCeW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1009 = Coupling(name = 'GC_1009',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid11) - delta*complex(0,1)*g1D6*ReCPhid11*swD6',
                   order = {'NP':2,'QED':3})

GC_1010 = Coupling(name = 'GC_1010',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhid11 - delta*complex(0,1)*gwD6*ReCPhid11*swD6',
                   order = {'NP':2,'QED':3})

GC_1011 = Coupling(name = 'GC_1011',
                   value = '-(cwD6*delta*gwD6*ImCPhid12) - cwD6*delta*complex(0,1)*gwD6*ReCPhid12 - delta*g1D6*ImCPhid12*swD6 - delta*complex(0,1)*g1D6*ReCPhid12*swD6',
                   order = {'NP':2,'QED':3})

GC_1012 = Coupling(name = 'GC_1012',
                   value = 'cwD6*delta*gwD6*ImCPhid12 - cwD6*delta*complex(0,1)*gwD6*ReCPhid12 + delta*g1D6*ImCPhid12*swD6 - delta*complex(0,1)*g1D6*ReCPhid12*swD6',
                   order = {'NP':2,'QED':3})

GC_1013 = Coupling(name = 'GC_1013',
                   value = 'cwD6*delta*g1D6*ImCPhid12 + cwD6*delta*complex(0,1)*g1D6*ReCPhid12 - delta*gwD6*ImCPhid12*swD6 - delta*complex(0,1)*gwD6*ReCPhid12*swD6',
                   order = {'NP':2,'QED':3})

GC_1014 = Coupling(name = 'GC_1014',
                   value = '-(cwD6*delta*g1D6*ImCPhid12) + cwD6*delta*complex(0,1)*g1D6*ReCPhid12 + delta*gwD6*ImCPhid12*swD6 - delta*complex(0,1)*gwD6*ReCPhid12*swD6',
                   order = {'NP':2,'QED':3})

GC_1015 = Coupling(name = 'GC_1015',
                   value = '-(cwD6*delta*gwD6*ImCPhid13) - cwD6*delta*complex(0,1)*gwD6*ReCPhid13 - delta*g1D6*ImCPhid13*swD6 - delta*complex(0,1)*g1D6*ReCPhid13*swD6',
                   order = {'NP':2,'QED':3})

GC_1016 = Coupling(name = 'GC_1016',
                   value = 'cwD6*delta*gwD6*ImCPhid13 - cwD6*delta*complex(0,1)*gwD6*ReCPhid13 + delta*g1D6*ImCPhid13*swD6 - delta*complex(0,1)*g1D6*ReCPhid13*swD6',
                   order = {'NP':2,'QED':3})

GC_1017 = Coupling(name = 'GC_1017',
                   value = 'cwD6*delta*g1D6*ImCPhid13 + cwD6*delta*complex(0,1)*g1D6*ReCPhid13 - delta*gwD6*ImCPhid13*swD6 - delta*complex(0,1)*gwD6*ReCPhid13*swD6',
                   order = {'NP':2,'QED':3})

GC_1018 = Coupling(name = 'GC_1018',
                   value = '-(cwD6*delta*g1D6*ImCPhid13) + cwD6*delta*complex(0,1)*g1D6*ReCPhid13 + delta*gwD6*ImCPhid13*swD6 - delta*complex(0,1)*gwD6*ReCPhid13*swD6',
                   order = {'NP':2,'QED':3})

GC_1019 = Coupling(name = 'GC_1019',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid22) - delta*complex(0,1)*g1D6*ReCPhid22*swD6',
                   order = {'NP':2,'QED':3})

GC_1020 = Coupling(name = 'GC_1020',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhid22 - delta*complex(0,1)*gwD6*ReCPhid22*swD6',
                   order = {'NP':2,'QED':3})

GC_1021 = Coupling(name = 'GC_1021',
                   value = '-(cwD6*delta*gwD6*ImCPhid23) - cwD6*delta*complex(0,1)*gwD6*ReCPhid23 - delta*g1D6*ImCPhid23*swD6 - delta*complex(0,1)*g1D6*ReCPhid23*swD6',
                   order = {'NP':2,'QED':3})

GC_1022 = Coupling(name = 'GC_1022',
                   value = 'cwD6*delta*gwD6*ImCPhid23 - cwD6*delta*complex(0,1)*gwD6*ReCPhid23 + delta*g1D6*ImCPhid23*swD6 - delta*complex(0,1)*g1D6*ReCPhid23*swD6',
                   order = {'NP':2,'QED':3})

GC_1023 = Coupling(name = 'GC_1023',
                   value = 'cwD6*delta*g1D6*ImCPhid23 + cwD6*delta*complex(0,1)*g1D6*ReCPhid23 - delta*gwD6*ImCPhid23*swD6 - delta*complex(0,1)*gwD6*ReCPhid23*swD6',
                   order = {'NP':2,'QED':3})

GC_1024 = Coupling(name = 'GC_1024',
                   value = '-(cwD6*delta*g1D6*ImCPhid23) + cwD6*delta*complex(0,1)*g1D6*ReCPhid23 + delta*gwD6*ImCPhid23*swD6 - delta*complex(0,1)*gwD6*ReCPhid23*swD6',
                   order = {'NP':2,'QED':3})

GC_1025 = Coupling(name = 'GC_1025',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid33) - delta*complex(0,1)*g1D6*ReCPhid33*swD6',
                   order = {'NP':2,'QED':3})

GC_1026 = Coupling(name = 'GC_1026',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhid33 - delta*complex(0,1)*gwD6*ReCPhid33*swD6',
                   order = {'NP':2,'QED':3})

GC_1027 = Coupling(name = 'GC_1027',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie11) - delta*complex(0,1)*g1D6*ReCPhie11*swD6',
                   order = {'NP':2,'QED':3})

GC_1028 = Coupling(name = 'GC_1028',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhie11 - delta*complex(0,1)*gwD6*ReCPhie11*swD6',
                   order = {'NP':2,'QED':3})

GC_1029 = Coupling(name = 'GC_1029',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie22) - delta*complex(0,1)*g1D6*ReCPhie22*swD6',
                   order = {'NP':2,'QED':3})

GC_1030 = Coupling(name = 'GC_1030',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhie22 - delta*complex(0,1)*gwD6*ReCPhie22*swD6',
                   order = {'NP':2,'QED':3})

GC_1031 = Coupling(name = 'GC_1031',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie33) - delta*complex(0,1)*g1D6*ReCPhie33*swD6',
                   order = {'NP':2,'QED':3})

GC_1032 = Coupling(name = 'GC_1032',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhie33 - delta*complex(0,1)*gwD6*ReCPhie33*swD6',
                   order = {'NP':2,'QED':3})

GC_1033 = Coupling(name = 'GC_1033',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu11) - delta*complex(0,1)*g1D6*ReCPhiu11*swD6',
                   order = {'NP':2,'QED':3})

GC_1034 = Coupling(name = 'GC_1034',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhiu11 - delta*complex(0,1)*gwD6*ReCPhiu11*swD6',
                   order = {'NP':2,'QED':3})

GC_1035 = Coupling(name = 'GC_1035',
                   value = '-(cwD6*delta*gwD6*ImCPhiu12) - cwD6*delta*complex(0,1)*gwD6*ReCPhiu12 - delta*g1D6*ImCPhiu12*swD6 - delta*complex(0,1)*g1D6*ReCPhiu12*swD6',
                   order = {'NP':2,'QED':3})

GC_1036 = Coupling(name = 'GC_1036',
                   value = 'cwD6*delta*gwD6*ImCPhiu12 - cwD6*delta*complex(0,1)*gwD6*ReCPhiu12 + delta*g1D6*ImCPhiu12*swD6 - delta*complex(0,1)*g1D6*ReCPhiu12*swD6',
                   order = {'NP':2,'QED':3})

GC_1037 = Coupling(name = 'GC_1037',
                   value = 'cwD6*delta*g1D6*ImCPhiu12 + cwD6*delta*complex(0,1)*g1D6*ReCPhiu12 - delta*gwD6*ImCPhiu12*swD6 - delta*complex(0,1)*gwD6*ReCPhiu12*swD6',
                   order = {'NP':2,'QED':3})

GC_1038 = Coupling(name = 'GC_1038',
                   value = '-(cwD6*delta*g1D6*ImCPhiu12) + cwD6*delta*complex(0,1)*g1D6*ReCPhiu12 + delta*gwD6*ImCPhiu12*swD6 - delta*complex(0,1)*gwD6*ReCPhiu12*swD6',
                   order = {'NP':2,'QED':3})

GC_1039 = Coupling(name = 'GC_1039',
                   value = '-(cwD6*delta*gwD6*ImCPhiu13) - cwD6*delta*complex(0,1)*gwD6*ReCPhiu13 - delta*g1D6*ImCPhiu13*swD6 - delta*complex(0,1)*g1D6*ReCPhiu13*swD6',
                   order = {'NP':2,'QED':3})

GC_1040 = Coupling(name = 'GC_1040',
                   value = 'cwD6*delta*gwD6*ImCPhiu13 - cwD6*delta*complex(0,1)*gwD6*ReCPhiu13 + delta*g1D6*ImCPhiu13*swD6 - delta*complex(0,1)*g1D6*ReCPhiu13*swD6',
                   order = {'NP':2,'QED':3})

GC_1041 = Coupling(name = 'GC_1041',
                   value = 'cwD6*delta*g1D6*ImCPhiu13 + cwD6*delta*complex(0,1)*g1D6*ReCPhiu13 - delta*gwD6*ImCPhiu13*swD6 - delta*complex(0,1)*gwD6*ReCPhiu13*swD6',
                   order = {'NP':2,'QED':3})

GC_1042 = Coupling(name = 'GC_1042',
                   value = '-(cwD6*delta*g1D6*ImCPhiu13) + cwD6*delta*complex(0,1)*g1D6*ReCPhiu13 + delta*gwD6*ImCPhiu13*swD6 - delta*complex(0,1)*gwD6*ReCPhiu13*swD6',
                   order = {'NP':2,'QED':3})

GC_1043 = Coupling(name = 'GC_1043',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu22) - delta*complex(0,1)*g1D6*ReCPhiu22*swD6',
                   order = {'NP':2,'QED':3})

GC_1044 = Coupling(name = 'GC_1044',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhiu22 - delta*complex(0,1)*gwD6*ReCPhiu22*swD6',
                   order = {'NP':2,'QED':3})

GC_1045 = Coupling(name = 'GC_1045',
                   value = '-(cwD6*delta*gwD6*ImCPhiu23) - cwD6*delta*complex(0,1)*gwD6*ReCPhiu23 - delta*g1D6*ImCPhiu23*swD6 - delta*complex(0,1)*g1D6*ReCPhiu23*swD6',
                   order = {'NP':2,'QED':3})

GC_1046 = Coupling(name = 'GC_1046',
                   value = 'cwD6*delta*gwD6*ImCPhiu23 - cwD6*delta*complex(0,1)*gwD6*ReCPhiu23 + delta*g1D6*ImCPhiu23*swD6 - delta*complex(0,1)*g1D6*ReCPhiu23*swD6',
                   order = {'NP':2,'QED':3})

GC_1047 = Coupling(name = 'GC_1047',
                   value = 'cwD6*delta*g1D6*ImCPhiu23 + cwD6*delta*complex(0,1)*g1D6*ReCPhiu23 - delta*gwD6*ImCPhiu23*swD6 - delta*complex(0,1)*gwD6*ReCPhiu23*swD6',
                   order = {'NP':2,'QED':3})

GC_1048 = Coupling(name = 'GC_1048',
                   value = '-(cwD6*delta*g1D6*ImCPhiu23) + cwD6*delta*complex(0,1)*g1D6*ReCPhiu23 + delta*gwD6*ImCPhiu23*swD6 - delta*complex(0,1)*gwD6*ReCPhiu23*swD6',
                   order = {'NP':2,'QED':3})

GC_1049 = Coupling(name = 'GC_1049',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu33) - delta*complex(0,1)*g1D6*ReCPhiu33*swD6',
                   order = {'NP':2,'QED':3})

GC_1050 = Coupling(name = 'GC_1050',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhiu33 - delta*complex(0,1)*gwD6*ReCPhiu33*swD6',
                   order = {'NP':2,'QED':3})

GC_1051 = Coupling(name = 'GC_1051',
                   value = '(cwD6*delta*complex(0,1)*ReCuW11)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB11*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1052 = Coupling(name = 'GC_1052',
                   value = '(cwD6*delta*ImCuW12)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW12)/cmath.sqrt(2) - (delta*ImCuB12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB12*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1053 = Coupling(name = 'GC_1053',
                   value = '-((cwD6*delta*ImCuW12)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW12)/cmath.sqrt(2) + (delta*ImCuB12*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB12*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1054 = Coupling(name = 'GC_1054',
                   value = '(cwD6*delta*ImCuW13)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW13)/cmath.sqrt(2) - (delta*ImCuB13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB13*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1055 = Coupling(name = 'GC_1055',
                   value = '-((cwD6*delta*ImCuW13)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW13)/cmath.sqrt(2) + (delta*ImCuB13*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB13*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1056 = Coupling(name = 'GC_1056',
                   value = '(cwD6*delta*ImCuW21)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW21)/cmath.sqrt(2) - (delta*ImCuB21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB21*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1057 = Coupling(name = 'GC_1057',
                   value = '-((cwD6*delta*ImCuW21)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW21)/cmath.sqrt(2) + (delta*ImCuB21*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB21*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1058 = Coupling(name = 'GC_1058',
                   value = '(cwD6*delta*complex(0,1)*ReCuW22)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB22*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1059 = Coupling(name = 'GC_1059',
                   value = '(cwD6*delta*ImCuW23)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW23)/cmath.sqrt(2) - (delta*ImCuB23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB23*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1060 = Coupling(name = 'GC_1060',
                   value = '-((cwD6*delta*ImCuW23)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW23)/cmath.sqrt(2) + (delta*ImCuB23*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB23*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1061 = Coupling(name = 'GC_1061',
                   value = '(cwD6*delta*ImCuW31)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW31)/cmath.sqrt(2) - (delta*ImCuB31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB31*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1062 = Coupling(name = 'GC_1062',
                   value = '-((cwD6*delta*ImCuW31)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW31)/cmath.sqrt(2) + (delta*ImCuB31*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB31*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1063 = Coupling(name = 'GC_1063',
                   value = '(cwD6*delta*ImCuW32)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW32)/cmath.sqrt(2) - (delta*ImCuB32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB32*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1064 = Coupling(name = 'GC_1064',
                   value = '-((cwD6*delta*ImCuW32)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW32)/cmath.sqrt(2) + (delta*ImCuB32*swD6)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB32*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1065 = Coupling(name = 'GC_1065',
                   value = '(cwD6*delta*complex(0,1)*ReCuW33)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB33*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1066 = Coupling(name = 'GC_1066',
                   value = '(cwD6*delta*complex(0,1)*ReCuB11)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW11*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1067 = Coupling(name = 'GC_1067',
                   value = '-(delta*gwD6*ImCuW11*swD6) - delta*complex(0,1)*gwD6*ReCuW11*swD6',
                   order = {'NP':2,'QED':2})

GC_1068 = Coupling(name = 'GC_1068',
                   value = 'delta*gwD6*ImCuW11*swD6 - delta*complex(0,1)*gwD6*ReCuW11*swD6',
                   order = {'NP':2,'QED':2})

GC_1069 = Coupling(name = 'GC_1069',
                   value = '-(delta*gwD6*ImCuW11*swD6) + delta*complex(0,1)*gwD6*ReCuW11*swD6',
                   order = {'NP':2,'QED':2})

GC_1070 = Coupling(name = 'GC_1070',
                   value = 'delta*gwD6*ImCuW11*swD6 + delta*complex(0,1)*gwD6*ReCuW11*swD6',
                   order = {'NP':2,'QED':2})

GC_1071 = Coupling(name = 'GC_1071',
                   value = '-((cwD6*delta*ImCuB12)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB12)/cmath.sqrt(2) - (delta*ImCuW12*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW12*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1072 = Coupling(name = 'GC_1072',
                   value = '(cwD6*delta*ImCuB12)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB12)/cmath.sqrt(2) + (delta*ImCuW12*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW12*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1073 = Coupling(name = 'GC_1073',
                   value = '-(delta*gwD6*ImCuW12*swD6) - delta*complex(0,1)*gwD6*ReCuW12*swD6',
                   order = {'NP':2,'QED':2})

GC_1074 = Coupling(name = 'GC_1074',
                   value = 'delta*gwD6*ImCuW12*swD6 - delta*complex(0,1)*gwD6*ReCuW12*swD6',
                   order = {'NP':2,'QED':2})

GC_1075 = Coupling(name = 'GC_1075',
                   value = '-(delta*gwD6*ImCuW12*swD6) + delta*complex(0,1)*gwD6*ReCuW12*swD6',
                   order = {'NP':2,'QED':2})

GC_1076 = Coupling(name = 'GC_1076',
                   value = 'delta*gwD6*ImCuW12*swD6 + delta*complex(0,1)*gwD6*ReCuW12*swD6',
                   order = {'NP':2,'QED':2})

GC_1077 = Coupling(name = 'GC_1077',
                   value = '-((cwD6*delta*ImCuB13)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB13)/cmath.sqrt(2) - (delta*ImCuW13*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW13*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1078 = Coupling(name = 'GC_1078',
                   value = '(cwD6*delta*ImCuB13)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB13)/cmath.sqrt(2) + (delta*ImCuW13*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW13*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1079 = Coupling(name = 'GC_1079',
                   value = '-(delta*gwD6*ImCuW13*swD6) - delta*complex(0,1)*gwD6*ReCuW13*swD6',
                   order = {'NP':2,'QED':2})

GC_1080 = Coupling(name = 'GC_1080',
                   value = 'delta*gwD6*ImCuW13*swD6 - delta*complex(0,1)*gwD6*ReCuW13*swD6',
                   order = {'NP':2,'QED':2})

GC_1081 = Coupling(name = 'GC_1081',
                   value = '-(delta*gwD6*ImCuW13*swD6) + delta*complex(0,1)*gwD6*ReCuW13*swD6',
                   order = {'NP':2,'QED':2})

GC_1082 = Coupling(name = 'GC_1082',
                   value = 'delta*gwD6*ImCuW13*swD6 + delta*complex(0,1)*gwD6*ReCuW13*swD6',
                   order = {'NP':2,'QED':2})

GC_1083 = Coupling(name = 'GC_1083',
                   value = '-((cwD6*delta*ImCuB21)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB21)/cmath.sqrt(2) - (delta*ImCuW21*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW21*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1084 = Coupling(name = 'GC_1084',
                   value = '(cwD6*delta*ImCuB21)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB21)/cmath.sqrt(2) + (delta*ImCuW21*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW21*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1085 = Coupling(name = 'GC_1085',
                   value = '-(delta*gwD6*ImCuW21*swD6) - delta*complex(0,1)*gwD6*ReCuW21*swD6',
                   order = {'NP':2,'QED':2})

GC_1086 = Coupling(name = 'GC_1086',
                   value = 'delta*gwD6*ImCuW21*swD6 - delta*complex(0,1)*gwD6*ReCuW21*swD6',
                   order = {'NP':2,'QED':2})

GC_1087 = Coupling(name = 'GC_1087',
                   value = '-(delta*gwD6*ImCuW21*swD6) + delta*complex(0,1)*gwD6*ReCuW21*swD6',
                   order = {'NP':2,'QED':2})

GC_1088 = Coupling(name = 'GC_1088',
                   value = 'delta*gwD6*ImCuW21*swD6 + delta*complex(0,1)*gwD6*ReCuW21*swD6',
                   order = {'NP':2,'QED':2})

GC_1089 = Coupling(name = 'GC_1089',
                   value = '(cwD6*delta*complex(0,1)*ReCuB22)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW22*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1090 = Coupling(name = 'GC_1090',
                   value = '-(delta*gwD6*ImCuW22*swD6) - delta*complex(0,1)*gwD6*ReCuW22*swD6',
                   order = {'NP':2,'QED':2})

GC_1091 = Coupling(name = 'GC_1091',
                   value = 'delta*gwD6*ImCuW22*swD6 - delta*complex(0,1)*gwD6*ReCuW22*swD6',
                   order = {'NP':2,'QED':2})

GC_1092 = Coupling(name = 'GC_1092',
                   value = '-(delta*gwD6*ImCuW22*swD6) + delta*complex(0,1)*gwD6*ReCuW22*swD6',
                   order = {'NP':2,'QED':2})

GC_1093 = Coupling(name = 'GC_1093',
                   value = 'delta*gwD6*ImCuW22*swD6 + delta*complex(0,1)*gwD6*ReCuW22*swD6',
                   order = {'NP':2,'QED':2})

GC_1094 = Coupling(name = 'GC_1094',
                   value = '-((cwD6*delta*ImCuB23)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB23)/cmath.sqrt(2) - (delta*ImCuW23*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW23*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1095 = Coupling(name = 'GC_1095',
                   value = '(cwD6*delta*ImCuB23)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB23)/cmath.sqrt(2) + (delta*ImCuW23*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW23*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1096 = Coupling(name = 'GC_1096',
                   value = '-(delta*gwD6*ImCuW23*swD6) - delta*complex(0,1)*gwD6*ReCuW23*swD6',
                   order = {'NP':2,'QED':2})

GC_1097 = Coupling(name = 'GC_1097',
                   value = 'delta*gwD6*ImCuW23*swD6 - delta*complex(0,1)*gwD6*ReCuW23*swD6',
                   order = {'NP':2,'QED':2})

GC_1098 = Coupling(name = 'GC_1098',
                   value = '-(delta*gwD6*ImCuW23*swD6) + delta*complex(0,1)*gwD6*ReCuW23*swD6',
                   order = {'NP':2,'QED':2})

GC_1099 = Coupling(name = 'GC_1099',
                   value = 'delta*gwD6*ImCuW23*swD6 + delta*complex(0,1)*gwD6*ReCuW23*swD6',
                   order = {'NP':2,'QED':2})

GC_1100 = Coupling(name = 'GC_1100',
                   value = '-((cwD6*delta*ImCuB31)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB31)/cmath.sqrt(2) - (delta*ImCuW31*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW31*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1101 = Coupling(name = 'GC_1101',
                   value = '(cwD6*delta*ImCuB31)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB31)/cmath.sqrt(2) + (delta*ImCuW31*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW31*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1102 = Coupling(name = 'GC_1102',
                   value = '-(delta*gwD6*ImCuW31*swD6) - delta*complex(0,1)*gwD6*ReCuW31*swD6',
                   order = {'NP':2,'QED':2})

GC_1103 = Coupling(name = 'GC_1103',
                   value = 'delta*gwD6*ImCuW31*swD6 - delta*complex(0,1)*gwD6*ReCuW31*swD6',
                   order = {'NP':2,'QED':2})

GC_1104 = Coupling(name = 'GC_1104',
                   value = '-(delta*gwD6*ImCuW31*swD6) + delta*complex(0,1)*gwD6*ReCuW31*swD6',
                   order = {'NP':2,'QED':2})

GC_1105 = Coupling(name = 'GC_1105',
                   value = 'delta*gwD6*ImCuW31*swD6 + delta*complex(0,1)*gwD6*ReCuW31*swD6',
                   order = {'NP':2,'QED':2})

GC_1106 = Coupling(name = 'GC_1106',
                   value = '-((cwD6*delta*ImCuB32)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB32)/cmath.sqrt(2) - (delta*ImCuW32*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW32*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1107 = Coupling(name = 'GC_1107',
                   value = '(cwD6*delta*ImCuB32)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB32)/cmath.sqrt(2) + (delta*ImCuW32*swD6)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW32*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1108 = Coupling(name = 'GC_1108',
                   value = '-(delta*gwD6*ImCuW32*swD6) - delta*complex(0,1)*gwD6*ReCuW32*swD6',
                   order = {'NP':2,'QED':2})

GC_1109 = Coupling(name = 'GC_1109',
                   value = 'delta*gwD6*ImCuW32*swD6 - delta*complex(0,1)*gwD6*ReCuW32*swD6',
                   order = {'NP':2,'QED':2})

GC_1110 = Coupling(name = 'GC_1110',
                   value = '-(delta*gwD6*ImCuW32*swD6) + delta*complex(0,1)*gwD6*ReCuW32*swD6',
                   order = {'NP':2,'QED':2})

GC_1111 = Coupling(name = 'GC_1111',
                   value = 'delta*gwD6*ImCuW32*swD6 + delta*complex(0,1)*gwD6*ReCuW32*swD6',
                   order = {'NP':2,'QED':2})

GC_1112 = Coupling(name = 'GC_1112',
                   value = '(cwD6*delta*complex(0,1)*ReCuB33)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW33*swD6)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1113 = Coupling(name = 'GC_1113',
                   value = '-(delta*gwD6*ImCuW33*swD6) - delta*complex(0,1)*gwD6*ReCuW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1114 = Coupling(name = 'GC_1114',
                   value = 'delta*gwD6*ImCuW33*swD6 - delta*complex(0,1)*gwD6*ReCuW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1115 = Coupling(name = 'GC_1115',
                   value = '-(delta*gwD6*ImCuW33*swD6) + delta*complex(0,1)*gwD6*ReCuW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1116 = Coupling(name = 'GC_1116',
                   value = 'delta*gwD6*ImCuW33*swD6 + delta*complex(0,1)*gwD6*ReCuW33*swD6',
                   order = {'NP':2,'QED':2})

GC_1117 = Coupling(name = 'GC_1117',
                   value = '4*CPhiW*cwD6**2*delta*complex(0,1) + 4*CPhiWB*cwD6*delta*complex(0,1)*swD6 + 4*CPhiB*delta*complex(0,1)*swD6**2',
                   order = {'NP':2,'QED':2})

GC_1118 = Coupling(name = 'GC_1118',
                   value = '4*CPhiB*cwD6**2*delta*complex(0,1) - 4*CPhiWB*cwD6*delta*complex(0,1)*swD6 + 4*CPhiW*delta*complex(0,1)*swD6**2',
                   order = {'NP':2,'QED':2})

GC_1119 = Coupling(name = 'GC_1119',
                   value = '-2*CPhiWB*cwD6**2*delta*complex(0,1) - 4*CPhiB*cwD6*delta*complex(0,1)*swD6 + 4*CPhiW*cwD6*delta*complex(0,1)*swD6 + 2*CPhiWB*delta*complex(0,1)*swD6**2',
                   order = {'NP':2,'QED':2})

GC_1120 = Coupling(name = 'GC_1120',
                   value = '(cwD6**2*complex(0,1)*gwD6**2)/2. + cwD6*complex(0,1)*g1D6*gwD6*swD6 + (complex(0,1)*g1D6**2*swD6**2)/2.',
                   order = {'QED':2})

GC_1121 = Coupling(name = 'GC_1121',
                   value = '3*CPhiD*cwD6**2*delta*complex(0,1)*gwD6**2 + 6*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6 + 3*CPhiD*delta*complex(0,1)*g1D6**2*swD6**2',
                   order = {'NP':2,'QED':6})

GC_1122 = Coupling(name = 'GC_1122',
                   value = '-(cwD6**2*complex(0,1)*g1D6*gwD6)/2. - (cwD6*complex(0,1)*g1D6**2*swD6)/2. + (cwD6*complex(0,1)*gwD6**2*swD6)/2. + (complex(0,1)*g1D6*gwD6*swD6**2)/2.',
                   order = {'QED':2})

GC_1123 = Coupling(name = 'GC_1123',
                   value = '-3*CPhiD*cwD6**2*delta*complex(0,1)*g1D6*gwD6 - 3*CPhiD*cwD6*delta*complex(0,1)*g1D6**2*swD6 + 3*CPhiD*cwD6*delta*complex(0,1)*gwD6**2*swD6 + 3*CPhiD*delta*complex(0,1)*g1D6*gwD6*swD6**2',
                   order = {'NP':2,'QED':6})

GC_1124 = Coupling(name = 'GC_1124',
                   value = '(cwD6**2*complex(0,1)*g1D6**2)/2. - cwD6*complex(0,1)*g1D6*gwD6*swD6 + (complex(0,1)*gwD6**2*swD6**2)/2.',
                   order = {'QED':2})

GC_1125 = Coupling(name = 'GC_1125',
                   value = '3*CPhiD*cwD6**2*delta*complex(0,1)*g1D6**2 - 6*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6 + 3*CPhiD*delta*complex(0,1)*gwD6**2*swD6**2',
                   order = {'NP':2,'QED':6})

GC_1126 = Coupling(name = 'GC_1126',
                   value = '90*CPhi*delta*complex(0,1)*vevT',
                   order = {'NP':2,'QED':5})

GC_1127 = Coupling(name = 'GC_1127',
                   value = '-(CPhiD*delta*complex(0,1)*vevT)',
                   order = {'NP':2,'QED':3})

GC_1128 = Coupling(name = 'GC_1128',
                   value = '-3*CPhiDAl*delta*complex(0,1)*vevT',
                   order = {'NP':2,'QED':3})

GC_1129 = Coupling(name = 'GC_1129',
                   value = '4*CPhiG*delta*complex(0,1)*vevT',
                   order = {'NP':2,'QED':1})

GC_1130 = Coupling(name = 'GC_1130',
                   value = '4*CPhiW*delta*complex(0,1)*vevT',
                   order = {'NP':2,'QED':1})

GC_1131 = Coupling(name = 'GC_1131',
                   value = '4*CPhiG*delta*gsD6*vevT',
                   order = {'NP':2,'QCD':1,'QED':1})

GC_1132 = Coupling(name = 'GC_1132',
                   value = '-4*CPhiG*delta*complex(0,1)*gsD6**2*vevT',
                   order = {'NP':2,'QCD':2,'QED':1})

GC_1133 = Coupling(name = 'GC_1133',
                   value = '-4*CPhiW*cwD6*delta*complex(0,1)*gwD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1134 = Coupling(name = 'GC_1134',
                   value = '2*CPhiWB*cwD6*delta*complex(0,1)*gwD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1135 = Coupling(name = 'GC_1135',
                   value = '(complex(0,1)*gwD6**2*vevT)/2.',
                   order = {'QED':1})

GC_1136 = Coupling(name = 'GC_1136',
                   value = '4*CPhiW*delta*complex(0,1)*gwD6**2*vevT',
                   order = {'NP':2,'QED':3})

GC_1137 = Coupling(name = 'GC_1137',
                   value = '-4*CPhiW*cwD6**2*delta*complex(0,1)*gwD6**2*vevT',
                   order = {'NP':2,'QED':3})

GC_1138 = Coupling(name = 'GC_1138',
                   value = '(delta*ImCdG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1139 = Coupling(name = 'GC_1139',
                   value = '(delta*complex(0,1)*gsD6*ImCdG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1140 = Coupling(name = 'GC_1140',
                   value = '(delta*ImCdG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1141 = Coupling(name = 'GC_1141',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG31*vevT)/cmath.sqrt(2))',
                   order = {'NP':2,'QCD':1})

GC_1142 = Coupling(name = 'GC_1142',
                   value = '(delta*ImCdG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1143 = Coupling(name = 'GC_1143',
                   value = '(delta*complex(0,1)*gsD6*ImCdG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1144 = Coupling(name = 'GC_1144',
                   value = '(3*delta*ImCdPhi11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1145 = Coupling(name = 'GC_1145',
                   value = '(3*delta*ImCdPhi22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1146 = Coupling(name = 'GC_1146',
                   value = '(3*delta*ImCdPhi33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1147 = Coupling(name = 'GC_1147',
                   value = '-((cwD6*delta*ImCdW22*vevT)/cmath.sqrt(2))',
                   order = {'NP':2})

GC_1148 = Coupling(name = 'GC_1148',
                   value = '(3*delta*ImCePhi11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1149 = Coupling(name = 'GC_1149',
                   value = '(3*delta*ImCePhi22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1150 = Coupling(name = 'GC_1150',
                   value = '(3*delta*ImCePhi33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1151 = Coupling(name = 'GC_1151',
                   value = '-(cwD6*delta*gwD6*ImCeW11*vevT)',
                   order = {'NP':2,'QED':1})

GC_1152 = Coupling(name = 'GC_1152',
                   value = '(delta*ImCuG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1153 = Coupling(name = 'GC_1153',
                   value = '(delta*ImCuG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1154 = Coupling(name = 'GC_1154',
                   value = '(delta*ImCuG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1155 = Coupling(name = 'GC_1155',
                   value = '(3*delta*ImCuPhi11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1156 = Coupling(name = 'GC_1156',
                   value = '(3*delta*ImCuPhi22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1157 = Coupling(name = 'GC_1157',
                   value = '(3*delta*ImCuPhi33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1158 = Coupling(name = 'GC_1158',
                   value = '-6*complex(0,1)*lam*vevT',
                   order = {'QED':1})

GC_1159 = Coupling(name = 'GC_1159',
                   value = 'delta*complex(0,1)*gwD6*ReC1Phil33*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1160 = Coupling(name = 'GC_1160',
                   value = 'delta*complex(0,1)*gwD6*ReC3Phil11*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1161 = Coupling(name = 'GC_1161',
                   value = 'delta*complex(0,1)*gwD6*ReC3Phil22*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1162 = Coupling(name = 'GC_1162',
                   value = 'delta*complex(0,1)*gwD6*ReC3Phiq11*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1163 = Coupling(name = 'GC_1163',
                   value = 'delta*complex(0,1)*gwD6*ReC3Phiq22*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1164 = Coupling(name = 'GC_1164',
                   value = 'delta*complex(0,1)*gwD6*ReC3Phiq33*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1165 = Coupling(name = 'GC_1165',
                   value = '(delta*complex(0,1)*ReCdG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1166 = Coupling(name = 'GC_1166',
                   value = '-((delta*gsD6*ReCdG11*vevT)/cmath.sqrt(2))',
                   order = {'NP':2,'QCD':1})

GC_1167 = Coupling(name = 'GC_1167',
                   value = '(delta*complex(0,1)*ReCdG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1168 = Coupling(name = 'GC_1168',
                   value = '-((delta*gsD6*ReCdG31*vevT)/cmath.sqrt(2))',
                   order = {'NP':2,'QCD':1})

GC_1169 = Coupling(name = 'GC_1169',
                   value = '(delta*complex(0,1)*ReCdG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1170 = Coupling(name = 'GC_1170',
                   value = '-((delta*gsD6*ReCdG33*vevT)/cmath.sqrt(2))',
                   order = {'NP':2,'QCD':1})

GC_1171 = Coupling(name = 'GC_1171',
                   value = '(3*delta*complex(0,1)*ReCdPhi11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1172 = Coupling(name = 'GC_1172',
                   value = '(3*delta*complex(0,1)*ReCdPhi22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1173 = Coupling(name = 'GC_1173',
                   value = '(3*delta*complex(0,1)*ReCdPhi33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1174 = Coupling(name = 'GC_1174',
                   value = '(3*delta*complex(0,1)*ReCePhi11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1175 = Coupling(name = 'GC_1175',
                   value = '(3*delta*complex(0,1)*ReCePhi22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1176 = Coupling(name = 'GC_1176',
                   value = '(3*delta*complex(0,1)*ReCePhi33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1177 = Coupling(name = 'GC_1177',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCeW11*vevT)',
                   order = {'NP':2,'QED':1})

GC_1178 = Coupling(name = 'GC_1178',
                   value = '(delta*complex(0,1)*ReCuG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1179 = Coupling(name = 'GC_1179',
                   value = '(delta*complex(0,1)*ReCuG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1180 = Coupling(name = 'GC_1180',
                   value = '(delta*complex(0,1)*ReCuG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1181 = Coupling(name = 'GC_1181',
                   value = '(3*delta*complex(0,1)*ReCuPhi11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1182 = Coupling(name = 'GC_1182',
                   value = '(3*delta*complex(0,1)*ReCuPhi22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1183 = Coupling(name = 'GC_1183',
                   value = '(3*delta*complex(0,1)*ReCuPhi33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1184 = Coupling(name = 'GC_1184',
                   value = '-4*CPhiW*delta*complex(0,1)*gwD6*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1185 = Coupling(name = 'GC_1185',
                   value = '-2*CPhiWB*delta*complex(0,1)*gwD6*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1186 = Coupling(name = 'GC_1186',
                   value = '8*CPhiW*cwD6*delta*complex(0,1)*gwD6**2*swD6*vevT',
                   order = {'NP':2,'QED':3})

GC_1187 = Coupling(name = 'GC_1187',
                   value = '(delta*ImCdB22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1188 = Coupling(name = 'GC_1188',
                   value = '-4*CPhiW*delta*complex(0,1)*gwD6**2*swD6**2*vevT',
                   order = {'NP':2,'QED':3})

GC_1189 = Coupling(name = 'GC_1189',
                   value = '-(CPhiWB*cwD6*delta*complex(0,1)*g1D6*vevT**2)/6.',
                   order = {'NP':2,'QED':1})

GC_1190 = Coupling(name = 'GC_1190',
                   value = '(CPhiWB*cwD6*delta*complex(0,1)*g1D6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_1191 = Coupling(name = 'GC_1191',
                   value = '-(CPhiG*delta*complex(0,1)*gsD6*vevT**2)',
                   order = {'NP':2,'QCD':1})

GC_1192 = Coupling(name = 'GC_1192',
                   value = 'CPhiWB*cwD6*delta*complex(0,1)*gwD6*vevT**2',
                   order = {'NP':2,'QED':1})

GC_1193 = Coupling(name = 'GC_1193',
                   value = '(delta*complex(0,1)*gwD6*ReC1Phil33*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1194 = Coupling(name = 'GC_1194',
                   value = '(delta*complex(0,1)*gwD6*ReC3Phil11*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1195 = Coupling(name = 'GC_1195',
                   value = '(delta*complex(0,1)*gwD6*ReC3Phil22*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1196 = Coupling(name = 'GC_1196',
                   value = '(delta*complex(0,1)*gwD6*ReC3Phiq11*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1197 = Coupling(name = 'GC_1197',
                   value = '(delta*complex(0,1)*gwD6*ReC3Phiq22*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1198 = Coupling(name = 'GC_1198',
                   value = '(delta*complex(0,1)*gwD6*ReC3Phiq33*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1199 = Coupling(name = 'GC_1199',
                   value = '-(CPhiWB*delta*complex(0,1)*g1D6*swD6*vevT**2)/6.',
                   order = {'NP':2,'QED':1})

GC_1200 = Coupling(name = 'GC_1200',
                   value = '(CPhiWB*delta*complex(0,1)*g1D6*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_1201 = Coupling(name = 'GC_1201',
                   value = '-(CPhiWB*delta*complex(0,1)*gwD6*swD6*vevT**2)',
                   order = {'NP':2,'QED':1})

GC_1202 = Coupling(name = 'GC_1202',
                   value = '-(delta*gwD6*ImC3Phiq12*vevT*cmath.sqrt(2)) + delta*complex(0,1)*gwD6*ReC3Phiq12*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1203 = Coupling(name = 'GC_1203',
                   value = 'delta*gwD6*ImC3Phiq12*vevT*cmath.sqrt(2) + delta*complex(0,1)*gwD6*ReC3Phiq12*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1204 = Coupling(name = 'GC_1204',
                   value = '-(delta*gwD6*ImC3Phiq13*vevT*cmath.sqrt(2)) + delta*complex(0,1)*gwD6*ReC3Phiq13*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1205 = Coupling(name = 'GC_1205',
                   value = 'delta*gwD6*ImC3Phiq13*vevT*cmath.sqrt(2) + delta*complex(0,1)*gwD6*ReC3Phiq13*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1206 = Coupling(name = 'GC_1206',
                   value = '-(delta*gwD6*ImC3Phiq23*vevT*cmath.sqrt(2)) + delta*complex(0,1)*gwD6*ReC3Phiq23*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1207 = Coupling(name = 'GC_1207',
                   value = 'delta*gwD6*ImC3Phiq23*vevT*cmath.sqrt(2) + delta*complex(0,1)*gwD6*ReC3Phiq23*vevT*cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1208 = Coupling(name = 'GC_1208',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG11*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCdG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1209 = Coupling(name = 'GC_1209',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG11*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1210 = Coupling(name = 'GC_1210',
                   value = '(delta*complex(0,1)*gsD6*ImCdG11*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1211 = Coupling(name = 'GC_1211',
                   value = '-((delta*ImCdG12*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1212 = Coupling(name = 'GC_1212',
                   value = '(delta*ImCdG12*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1213 = Coupling(name = 'GC_1213',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG12*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCdG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1214 = Coupling(name = 'GC_1214',
                   value = '(delta*complex(0,1)*gsD6*ImCdG12*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCdG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1215 = Coupling(name = 'GC_1215',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG12*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1216 = Coupling(name = 'GC_1216',
                   value = '(delta*complex(0,1)*gsD6*ImCdG12*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1217 = Coupling(name = 'GC_1217',
                   value = '-((delta*ImCdG13*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1218 = Coupling(name = 'GC_1218',
                   value = '(delta*ImCdG13*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1219 = Coupling(name = 'GC_1219',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG13*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCdG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1220 = Coupling(name = 'GC_1220',
                   value = '(delta*complex(0,1)*gsD6*ImCdG13*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCdG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1221 = Coupling(name = 'GC_1221',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG13*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1222 = Coupling(name = 'GC_1222',
                   value = '(delta*complex(0,1)*gsD6*ImCdG13*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1223 = Coupling(name = 'GC_1223',
                   value = '-((delta*ImCdG21*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1224 = Coupling(name = 'GC_1224',
                   value = '(delta*ImCdG21*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1225 = Coupling(name = 'GC_1225',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG21*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCdG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1226 = Coupling(name = 'GC_1226',
                   value = '(delta*complex(0,1)*gsD6*ImCdG21*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCdG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1227 = Coupling(name = 'GC_1227',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG21*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1228 = Coupling(name = 'GC_1228',
                   value = '(delta*complex(0,1)*gsD6*ImCdG21*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1229 = Coupling(name = 'GC_1229',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG22*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCdG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1230 = Coupling(name = 'GC_1230',
                   value = '(delta*complex(0,1)*gsD6*ImCdG22*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCdG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1231 = Coupling(name = 'GC_1231',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG22*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1232 = Coupling(name = 'GC_1232',
                   value = '(delta*complex(0,1)*gsD6*ImCdG22*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1233 = Coupling(name = 'GC_1233',
                   value = '-((delta*ImCdG23*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1234 = Coupling(name = 'GC_1234',
                   value = '(delta*ImCdG23*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1235 = Coupling(name = 'GC_1235',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG23*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCdG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1236 = Coupling(name = 'GC_1236',
                   value = '(delta*complex(0,1)*gsD6*ImCdG23*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCdG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1237 = Coupling(name = 'GC_1237',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG23*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1238 = Coupling(name = 'GC_1238',
                   value = '(delta*complex(0,1)*gsD6*ImCdG23*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1239 = Coupling(name = 'GC_1239',
                   value = '-((delta*ImCdG31*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1240 = Coupling(name = 'GC_1240',
                   value = '(delta*ImCdG31*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1241 = Coupling(name = 'GC_1241',
                   value = '(delta*complex(0,1)*gsD6*ImCdG31*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCdG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1242 = Coupling(name = 'GC_1242',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG31*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1243 = Coupling(name = 'GC_1243',
                   value = '(delta*complex(0,1)*gsD6*ImCdG31*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1244 = Coupling(name = 'GC_1244',
                   value = '-((delta*ImCdG32*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1245 = Coupling(name = 'GC_1245',
                   value = '(delta*ImCdG32*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1246 = Coupling(name = 'GC_1246',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG32*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCdG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1247 = Coupling(name = 'GC_1247',
                   value = '(delta*complex(0,1)*gsD6*ImCdG32*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCdG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1248 = Coupling(name = 'GC_1248',
                   value = '-((delta*complex(0,1)*gsD6*ImCdG32*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCdG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1249 = Coupling(name = 'GC_1249',
                   value = '(delta*complex(0,1)*gsD6*ImCdG32*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCdG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1250 = Coupling(name = 'GC_1250',
                   value = '(-3*delta*ImCdPhi12*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1251 = Coupling(name = 'GC_1251',
                   value = '(3*delta*ImCdPhi12*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1252 = Coupling(name = 'GC_1252',
                   value = '(-3*delta*ImCdPhi13*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1253 = Coupling(name = 'GC_1253',
                   value = '(3*delta*ImCdPhi13*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1254 = Coupling(name = 'GC_1254',
                   value = '(-3*delta*ImCdPhi21*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1255 = Coupling(name = 'GC_1255',
                   value = '(3*delta*ImCdPhi21*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1256 = Coupling(name = 'GC_1256',
                   value = '(-3*delta*ImCdPhi23*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1257 = Coupling(name = 'GC_1257',
                   value = '(3*delta*ImCdPhi23*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1258 = Coupling(name = 'GC_1258',
                   value = '(-3*delta*ImCdPhi31*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1259 = Coupling(name = 'GC_1259',
                   value = '(3*delta*ImCdPhi31*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1260 = Coupling(name = 'GC_1260',
                   value = '(-3*delta*ImCdPhi32*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1261 = Coupling(name = 'GC_1261',
                   value = '(3*delta*ImCdPhi32*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCdPhi32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1262 = Coupling(name = 'GC_1262',
                   value = '-(delta*ImCdW11*vevT) + delta*complex(0,1)*ReCdW11*vevT',
                   order = {'NP':2})

GC_1263 = Coupling(name = 'GC_1263',
                   value = 'delta*ImCdW11*vevT + delta*complex(0,1)*ReCdW11*vevT',
                   order = {'NP':2})

GC_1264 = Coupling(name = 'GC_1264',
                   value = '-((delta*gwD6*ImCdW11*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1265 = Coupling(name = 'GC_1265',
                   value = '(delta*gwD6*ImCdW11*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1266 = Coupling(name = 'GC_1266',
                   value = '-((delta*gwD6*ImCdW11*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1267 = Coupling(name = 'GC_1267',
                   value = '(delta*gwD6*ImCdW11*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1268 = Coupling(name = 'GC_1268',
                   value = '-(cwD6*delta*gwD6*ImCdW11*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1269 = Coupling(name = 'GC_1269',
                   value = 'cwD6*delta*gwD6*ImCdW11*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1270 = Coupling(name = 'GC_1270',
                   value = '-(cwD6*delta*gwD6*ImCdW11*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1271 = Coupling(name = 'GC_1271',
                   value = 'cwD6*delta*gwD6*ImCdW11*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1272 = Coupling(name = 'GC_1272',
                   value = '-(delta*ImCdW12*vevT) + delta*complex(0,1)*ReCdW12*vevT',
                   order = {'NP':2})

GC_1273 = Coupling(name = 'GC_1273',
                   value = 'delta*ImCdW12*vevT + delta*complex(0,1)*ReCdW12*vevT',
                   order = {'NP':2})

GC_1274 = Coupling(name = 'GC_1274',
                   value = '-((delta*gwD6*ImCdW12*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1275 = Coupling(name = 'GC_1275',
                   value = '(delta*gwD6*ImCdW12*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1276 = Coupling(name = 'GC_1276',
                   value = '-((delta*gwD6*ImCdW12*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1277 = Coupling(name = 'GC_1277',
                   value = '(delta*gwD6*ImCdW12*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1278 = Coupling(name = 'GC_1278',
                   value = '-(cwD6*delta*gwD6*ImCdW12*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1279 = Coupling(name = 'GC_1279',
                   value = 'cwD6*delta*gwD6*ImCdW12*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1280 = Coupling(name = 'GC_1280',
                   value = '-(cwD6*delta*gwD6*ImCdW12*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1281 = Coupling(name = 'GC_1281',
                   value = 'cwD6*delta*gwD6*ImCdW12*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1282 = Coupling(name = 'GC_1282',
                   value = '-(delta*ImCdW13*vevT) + delta*complex(0,1)*ReCdW13*vevT',
                   order = {'NP':2})

GC_1283 = Coupling(name = 'GC_1283',
                   value = 'delta*ImCdW13*vevT + delta*complex(0,1)*ReCdW13*vevT',
                   order = {'NP':2})

GC_1284 = Coupling(name = 'GC_1284',
                   value = '-((delta*gwD6*ImCdW13*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1285 = Coupling(name = 'GC_1285',
                   value = '(delta*gwD6*ImCdW13*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1286 = Coupling(name = 'GC_1286',
                   value = '-((delta*gwD6*ImCdW13*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1287 = Coupling(name = 'GC_1287',
                   value = '(delta*gwD6*ImCdW13*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1288 = Coupling(name = 'GC_1288',
                   value = '-(cwD6*delta*gwD6*ImCdW13*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1289 = Coupling(name = 'GC_1289',
                   value = 'cwD6*delta*gwD6*ImCdW13*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1290 = Coupling(name = 'GC_1290',
                   value = '-(cwD6*delta*gwD6*ImCdW13*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1291 = Coupling(name = 'GC_1291',
                   value = 'cwD6*delta*gwD6*ImCdW13*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1292 = Coupling(name = 'GC_1292',
                   value = '-(delta*ImCdW21*vevT) + delta*complex(0,1)*ReCdW21*vevT',
                   order = {'NP':2})

GC_1293 = Coupling(name = 'GC_1293',
                   value = 'delta*ImCdW21*vevT + delta*complex(0,1)*ReCdW21*vevT',
                   order = {'NP':2})

GC_1294 = Coupling(name = 'GC_1294',
                   value = '-((delta*gwD6*ImCdW21*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1295 = Coupling(name = 'GC_1295',
                   value = '(delta*gwD6*ImCdW21*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1296 = Coupling(name = 'GC_1296',
                   value = '-((delta*gwD6*ImCdW21*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1297 = Coupling(name = 'GC_1297',
                   value = '(delta*gwD6*ImCdW21*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1298 = Coupling(name = 'GC_1298',
                   value = '-(cwD6*delta*gwD6*ImCdW21*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1299 = Coupling(name = 'GC_1299',
                   value = 'cwD6*delta*gwD6*ImCdW21*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1300 = Coupling(name = 'GC_1300',
                   value = '-(cwD6*delta*gwD6*ImCdW21*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1301 = Coupling(name = 'GC_1301',
                   value = 'cwD6*delta*gwD6*ImCdW21*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1302 = Coupling(name = 'GC_1302',
                   value = '-(delta*ImCdW22*vevT) + delta*complex(0,1)*ReCdW22*vevT',
                   order = {'NP':2})

GC_1303 = Coupling(name = 'GC_1303',
                   value = 'delta*ImCdW22*vevT + delta*complex(0,1)*ReCdW22*vevT',
                   order = {'NP':2})

GC_1304 = Coupling(name = 'GC_1304',
                   value = '-((delta*gwD6*ImCdW22*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1305 = Coupling(name = 'GC_1305',
                   value = '(delta*gwD6*ImCdW22*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1306 = Coupling(name = 'GC_1306',
                   value = '-((delta*gwD6*ImCdW22*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1307 = Coupling(name = 'GC_1307',
                   value = '(delta*gwD6*ImCdW22*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1308 = Coupling(name = 'GC_1308',
                   value = '-(cwD6*delta*gwD6*ImCdW22*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1309 = Coupling(name = 'GC_1309',
                   value = 'cwD6*delta*gwD6*ImCdW22*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1310 = Coupling(name = 'GC_1310',
                   value = '-(cwD6*delta*gwD6*ImCdW22*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1311 = Coupling(name = 'GC_1311',
                   value = 'cwD6*delta*gwD6*ImCdW22*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1312 = Coupling(name = 'GC_1312',
                   value = '-(delta*ImCdW23*vevT) + delta*complex(0,1)*ReCdW23*vevT',
                   order = {'NP':2})

GC_1313 = Coupling(name = 'GC_1313',
                   value = 'delta*ImCdW23*vevT + delta*complex(0,1)*ReCdW23*vevT',
                   order = {'NP':2})

GC_1314 = Coupling(name = 'GC_1314',
                   value = '-((delta*gwD6*ImCdW23*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1315 = Coupling(name = 'GC_1315',
                   value = '(delta*gwD6*ImCdW23*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1316 = Coupling(name = 'GC_1316',
                   value = '-((delta*gwD6*ImCdW23*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1317 = Coupling(name = 'GC_1317',
                   value = '(delta*gwD6*ImCdW23*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1318 = Coupling(name = 'GC_1318',
                   value = '-(cwD6*delta*gwD6*ImCdW23*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1319 = Coupling(name = 'GC_1319',
                   value = 'cwD6*delta*gwD6*ImCdW23*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1320 = Coupling(name = 'GC_1320',
                   value = '-(cwD6*delta*gwD6*ImCdW23*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1321 = Coupling(name = 'GC_1321',
                   value = 'cwD6*delta*gwD6*ImCdW23*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1322 = Coupling(name = 'GC_1322',
                   value = '-(delta*ImCdW31*vevT) + delta*complex(0,1)*ReCdW31*vevT',
                   order = {'NP':2})

GC_1323 = Coupling(name = 'GC_1323',
                   value = 'delta*ImCdW31*vevT + delta*complex(0,1)*ReCdW31*vevT',
                   order = {'NP':2})

GC_1324 = Coupling(name = 'GC_1324',
                   value = '-((delta*gwD6*ImCdW31*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1325 = Coupling(name = 'GC_1325',
                   value = '(delta*gwD6*ImCdW31*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1326 = Coupling(name = 'GC_1326',
                   value = '-((delta*gwD6*ImCdW31*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1327 = Coupling(name = 'GC_1327',
                   value = '(delta*gwD6*ImCdW31*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1328 = Coupling(name = 'GC_1328',
                   value = '-(cwD6*delta*gwD6*ImCdW31*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1329 = Coupling(name = 'GC_1329',
                   value = 'cwD6*delta*gwD6*ImCdW31*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1330 = Coupling(name = 'GC_1330',
                   value = '-(cwD6*delta*gwD6*ImCdW31*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1331 = Coupling(name = 'GC_1331',
                   value = 'cwD6*delta*gwD6*ImCdW31*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1332 = Coupling(name = 'GC_1332',
                   value = '-(delta*ImCdW32*vevT) + delta*complex(0,1)*ReCdW32*vevT',
                   order = {'NP':2})

GC_1333 = Coupling(name = 'GC_1333',
                   value = 'delta*ImCdW32*vevT + delta*complex(0,1)*ReCdW32*vevT',
                   order = {'NP':2})

GC_1334 = Coupling(name = 'GC_1334',
                   value = '-((delta*gwD6*ImCdW32*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1335 = Coupling(name = 'GC_1335',
                   value = '(delta*gwD6*ImCdW32*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1336 = Coupling(name = 'GC_1336',
                   value = '-((delta*gwD6*ImCdW32*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1337 = Coupling(name = 'GC_1337',
                   value = '(delta*gwD6*ImCdW32*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1338 = Coupling(name = 'GC_1338',
                   value = '-(cwD6*delta*gwD6*ImCdW32*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1339 = Coupling(name = 'GC_1339',
                   value = 'cwD6*delta*gwD6*ImCdW32*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1340 = Coupling(name = 'GC_1340',
                   value = '-(cwD6*delta*gwD6*ImCdW32*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1341 = Coupling(name = 'GC_1341',
                   value = 'cwD6*delta*gwD6*ImCdW32*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1342 = Coupling(name = 'GC_1342',
                   value = '-(delta*ImCdW33*vevT) + delta*complex(0,1)*ReCdW33*vevT',
                   order = {'NP':2})

GC_1343 = Coupling(name = 'GC_1343',
                   value = 'delta*ImCdW33*vevT + delta*complex(0,1)*ReCdW33*vevT',
                   order = {'NP':2})

GC_1344 = Coupling(name = 'GC_1344',
                   value = '-((delta*gwD6*ImCdW33*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCdW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1345 = Coupling(name = 'GC_1345',
                   value = '(delta*gwD6*ImCdW33*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCdW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1346 = Coupling(name = 'GC_1346',
                   value = '-((delta*gwD6*ImCdW33*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCdW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1347 = Coupling(name = 'GC_1347',
                   value = '(delta*gwD6*ImCdW33*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCdW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1348 = Coupling(name = 'GC_1348',
                   value = '-(cwD6*delta*gwD6*ImCdW33*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCdW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1349 = Coupling(name = 'GC_1349',
                   value = 'cwD6*delta*gwD6*ImCdW33*vevT - cwD6*delta*complex(0,1)*gwD6*ReCdW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1350 = Coupling(name = 'GC_1350',
                   value = '-(cwD6*delta*gwD6*ImCdW33*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCdW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1351 = Coupling(name = 'GC_1351',
                   value = 'cwD6*delta*gwD6*ImCdW33*vevT + cwD6*delta*complex(0,1)*gwD6*ReCdW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1352 = Coupling(name = 'GC_1352',
                   value = '(-3*delta*ImCePhi12*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1353 = Coupling(name = 'GC_1353',
                   value = '(3*delta*ImCePhi12*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1354 = Coupling(name = 'GC_1354',
                   value = '(-3*delta*ImCePhi13*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1355 = Coupling(name = 'GC_1355',
                   value = '(3*delta*ImCePhi13*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1356 = Coupling(name = 'GC_1356',
                   value = '(-3*delta*ImCePhi21*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1357 = Coupling(name = 'GC_1357',
                   value = '(3*delta*ImCePhi21*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1358 = Coupling(name = 'GC_1358',
                   value = '(-3*delta*ImCePhi23*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1359 = Coupling(name = 'GC_1359',
                   value = '(3*delta*ImCePhi23*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1360 = Coupling(name = 'GC_1360',
                   value = '(-3*delta*ImCePhi31*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1361 = Coupling(name = 'GC_1361',
                   value = '(3*delta*ImCePhi31*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1362 = Coupling(name = 'GC_1362',
                   value = '(-3*delta*ImCePhi32*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1363 = Coupling(name = 'GC_1363',
                   value = '(3*delta*ImCePhi32*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCePhi32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1364 = Coupling(name = 'GC_1364',
                   value = '-(delta*ImCeW11*vevT) + delta*complex(0,1)*ReCeW11*vevT',
                   order = {'NP':2})

GC_1365 = Coupling(name = 'GC_1365',
                   value = 'delta*ImCeW11*vevT + delta*complex(0,1)*ReCeW11*vevT',
                   order = {'NP':2})

GC_1366 = Coupling(name = 'GC_1366',
                   value = '-((delta*gwD6*ImCeW11*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1367 = Coupling(name = 'GC_1367',
                   value = '(delta*gwD6*ImCeW11*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1368 = Coupling(name = 'GC_1368',
                   value = '-((delta*gwD6*ImCeW11*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1369 = Coupling(name = 'GC_1369',
                   value = '(delta*gwD6*ImCeW11*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1370 = Coupling(name = 'GC_1370',
                   value = 'cwD6*delta*gwD6*ImCeW11*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1371 = Coupling(name = 'GC_1371',
                   value = '-(cwD6*delta*gwD6*ImCeW11*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1372 = Coupling(name = 'GC_1372',
                   value = 'cwD6*delta*gwD6*ImCeW11*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1373 = Coupling(name = 'GC_1373',
                   value = 'delta*ImCeW12*vevT - delta*complex(0,1)*ReCeW12*vevT',
                   order = {'NP':2})

GC_1374 = Coupling(name = 'GC_1374',
                   value = '-(delta*ImCeW12*vevT) + delta*complex(0,1)*ReCeW12*vevT',
                   order = {'NP':2})

GC_1375 = Coupling(name = 'GC_1375',
                   value = 'delta*ImCeW12*vevT + delta*complex(0,1)*ReCeW12*vevT',
                   order = {'NP':2})

GC_1376 = Coupling(name = 'GC_1376',
                   value = '-((delta*gwD6*ImCeW12*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1377 = Coupling(name = 'GC_1377',
                   value = '(delta*gwD6*ImCeW12*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1378 = Coupling(name = 'GC_1378',
                   value = '-((delta*gwD6*ImCeW12*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1379 = Coupling(name = 'GC_1379',
                   value = '(delta*gwD6*ImCeW12*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1380 = Coupling(name = 'GC_1380',
                   value = '-(cwD6*delta*gwD6*ImCeW12*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1381 = Coupling(name = 'GC_1381',
                   value = 'cwD6*delta*gwD6*ImCeW12*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1382 = Coupling(name = 'GC_1382',
                   value = '-(cwD6*delta*gwD6*ImCeW12*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1383 = Coupling(name = 'GC_1383',
                   value = 'cwD6*delta*gwD6*ImCeW12*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1384 = Coupling(name = 'GC_1384',
                   value = 'delta*ImCeW13*vevT - delta*complex(0,1)*ReCeW13*vevT',
                   order = {'NP':2})

GC_1385 = Coupling(name = 'GC_1385',
                   value = '-(delta*ImCeW13*vevT) + delta*complex(0,1)*ReCeW13*vevT',
                   order = {'NP':2})

GC_1386 = Coupling(name = 'GC_1386',
                   value = 'delta*ImCeW13*vevT + delta*complex(0,1)*ReCeW13*vevT',
                   order = {'NP':2})

GC_1387 = Coupling(name = 'GC_1387',
                   value = '-((delta*gwD6*ImCeW13*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1388 = Coupling(name = 'GC_1388',
                   value = '(delta*gwD6*ImCeW13*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1389 = Coupling(name = 'GC_1389',
                   value = '-((delta*gwD6*ImCeW13*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1390 = Coupling(name = 'GC_1390',
                   value = '(delta*gwD6*ImCeW13*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1391 = Coupling(name = 'GC_1391',
                   value = '-(cwD6*delta*gwD6*ImCeW13*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1392 = Coupling(name = 'GC_1392',
                   value = 'cwD6*delta*gwD6*ImCeW13*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1393 = Coupling(name = 'GC_1393',
                   value = '-(cwD6*delta*gwD6*ImCeW13*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1394 = Coupling(name = 'GC_1394',
                   value = 'cwD6*delta*gwD6*ImCeW13*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1395 = Coupling(name = 'GC_1395',
                   value = 'delta*ImCeW21*vevT - delta*complex(0,1)*ReCeW21*vevT',
                   order = {'NP':2})

GC_1396 = Coupling(name = 'GC_1396',
                   value = '-(delta*ImCeW21*vevT) + delta*complex(0,1)*ReCeW21*vevT',
                   order = {'NP':2})

GC_1397 = Coupling(name = 'GC_1397',
                   value = 'delta*ImCeW21*vevT + delta*complex(0,1)*ReCeW21*vevT',
                   order = {'NP':2})

GC_1398 = Coupling(name = 'GC_1398',
                   value = '-((delta*gwD6*ImCeW21*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1399 = Coupling(name = 'GC_1399',
                   value = '(delta*gwD6*ImCeW21*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1400 = Coupling(name = 'GC_1400',
                   value = '-((delta*gwD6*ImCeW21*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1401 = Coupling(name = 'GC_1401',
                   value = '(delta*gwD6*ImCeW21*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1402 = Coupling(name = 'GC_1402',
                   value = '-(cwD6*delta*gwD6*ImCeW21*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1403 = Coupling(name = 'GC_1403',
                   value = 'cwD6*delta*gwD6*ImCeW21*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1404 = Coupling(name = 'GC_1404',
                   value = '-(cwD6*delta*gwD6*ImCeW21*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1405 = Coupling(name = 'GC_1405',
                   value = 'cwD6*delta*gwD6*ImCeW21*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1406 = Coupling(name = 'GC_1406',
                   value = '-(delta*ImCeW22*vevT) + delta*complex(0,1)*ReCeW22*vevT',
                   order = {'NP':2})

GC_1407 = Coupling(name = 'GC_1407',
                   value = 'delta*ImCeW22*vevT + delta*complex(0,1)*ReCeW22*vevT',
                   order = {'NP':2})

GC_1408 = Coupling(name = 'GC_1408',
                   value = '-((delta*gwD6*ImCeW22*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1409 = Coupling(name = 'GC_1409',
                   value = '(delta*gwD6*ImCeW22*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1410 = Coupling(name = 'GC_1410',
                   value = '-((delta*gwD6*ImCeW22*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1411 = Coupling(name = 'GC_1411',
                   value = '(delta*gwD6*ImCeW22*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1412 = Coupling(name = 'GC_1412',
                   value = '-(cwD6*delta*gwD6*ImCeW22*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1413 = Coupling(name = 'GC_1413',
                   value = 'cwD6*delta*gwD6*ImCeW22*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1414 = Coupling(name = 'GC_1414',
                   value = '-(cwD6*delta*gwD6*ImCeW22*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1415 = Coupling(name = 'GC_1415',
                   value = 'cwD6*delta*gwD6*ImCeW22*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1416 = Coupling(name = 'GC_1416',
                   value = 'delta*ImCeW23*vevT - delta*complex(0,1)*ReCeW23*vevT',
                   order = {'NP':2})

GC_1417 = Coupling(name = 'GC_1417',
                   value = '-(delta*ImCeW23*vevT) + delta*complex(0,1)*ReCeW23*vevT',
                   order = {'NP':2})

GC_1418 = Coupling(name = 'GC_1418',
                   value = 'delta*ImCeW23*vevT + delta*complex(0,1)*ReCeW23*vevT',
                   order = {'NP':2})

GC_1419 = Coupling(name = 'GC_1419',
                   value = '-((delta*gwD6*ImCeW23*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1420 = Coupling(name = 'GC_1420',
                   value = '(delta*gwD6*ImCeW23*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1421 = Coupling(name = 'GC_1421',
                   value = '-((delta*gwD6*ImCeW23*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1422 = Coupling(name = 'GC_1422',
                   value = '(delta*gwD6*ImCeW23*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1423 = Coupling(name = 'GC_1423',
                   value = '-(cwD6*delta*gwD6*ImCeW23*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1424 = Coupling(name = 'GC_1424',
                   value = 'cwD6*delta*gwD6*ImCeW23*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1425 = Coupling(name = 'GC_1425',
                   value = '-(cwD6*delta*gwD6*ImCeW23*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1426 = Coupling(name = 'GC_1426',
                   value = 'cwD6*delta*gwD6*ImCeW23*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1427 = Coupling(name = 'GC_1427',
                   value = 'delta*ImCeW31*vevT - delta*complex(0,1)*ReCeW31*vevT',
                   order = {'NP':2})

GC_1428 = Coupling(name = 'GC_1428',
                   value = '-(delta*ImCeW31*vevT) + delta*complex(0,1)*ReCeW31*vevT',
                   order = {'NP':2})

GC_1429 = Coupling(name = 'GC_1429',
                   value = 'delta*ImCeW31*vevT + delta*complex(0,1)*ReCeW31*vevT',
                   order = {'NP':2})

GC_1430 = Coupling(name = 'GC_1430',
                   value = '-((delta*gwD6*ImCeW31*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1431 = Coupling(name = 'GC_1431',
                   value = '(delta*gwD6*ImCeW31*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1432 = Coupling(name = 'GC_1432',
                   value = '-((delta*gwD6*ImCeW31*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1433 = Coupling(name = 'GC_1433',
                   value = '(delta*gwD6*ImCeW31*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1434 = Coupling(name = 'GC_1434',
                   value = '-(cwD6*delta*gwD6*ImCeW31*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1435 = Coupling(name = 'GC_1435',
                   value = 'cwD6*delta*gwD6*ImCeW31*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1436 = Coupling(name = 'GC_1436',
                   value = '-(cwD6*delta*gwD6*ImCeW31*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1437 = Coupling(name = 'GC_1437',
                   value = 'cwD6*delta*gwD6*ImCeW31*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1438 = Coupling(name = 'GC_1438',
                   value = 'delta*ImCeW32*vevT - delta*complex(0,1)*ReCeW32*vevT',
                   order = {'NP':2})

GC_1439 = Coupling(name = 'GC_1439',
                   value = '-(delta*ImCeW32*vevT) + delta*complex(0,1)*ReCeW32*vevT',
                   order = {'NP':2})

GC_1440 = Coupling(name = 'GC_1440',
                   value = 'delta*ImCeW32*vevT + delta*complex(0,1)*ReCeW32*vevT',
                   order = {'NP':2})

GC_1441 = Coupling(name = 'GC_1441',
                   value = '-((delta*gwD6*ImCeW32*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1442 = Coupling(name = 'GC_1442',
                   value = '(delta*gwD6*ImCeW32*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1443 = Coupling(name = 'GC_1443',
                   value = '-((delta*gwD6*ImCeW32*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1444 = Coupling(name = 'GC_1444',
                   value = '(delta*gwD6*ImCeW32*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1445 = Coupling(name = 'GC_1445',
                   value = '-(cwD6*delta*gwD6*ImCeW32*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1446 = Coupling(name = 'GC_1446',
                   value = 'cwD6*delta*gwD6*ImCeW32*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1447 = Coupling(name = 'GC_1447',
                   value = '-(cwD6*delta*gwD6*ImCeW32*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1448 = Coupling(name = 'GC_1448',
                   value = 'cwD6*delta*gwD6*ImCeW32*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1449 = Coupling(name = 'GC_1449',
                   value = '-(delta*ImCeW33*vevT) + delta*complex(0,1)*ReCeW33*vevT',
                   order = {'NP':2})

GC_1450 = Coupling(name = 'GC_1450',
                   value = 'delta*ImCeW33*vevT + delta*complex(0,1)*ReCeW33*vevT',
                   order = {'NP':2})

GC_1451 = Coupling(name = 'GC_1451',
                   value = '-((delta*gwD6*ImCeW33*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCeW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1452 = Coupling(name = 'GC_1452',
                   value = '(delta*gwD6*ImCeW33*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCeW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1453 = Coupling(name = 'GC_1453',
                   value = '-((delta*gwD6*ImCeW33*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCeW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1454 = Coupling(name = 'GC_1454',
                   value = '(delta*gwD6*ImCeW33*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCeW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1455 = Coupling(name = 'GC_1455',
                   value = '-(cwD6*delta*gwD6*ImCeW33*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCeW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1456 = Coupling(name = 'GC_1456',
                   value = 'cwD6*delta*gwD6*ImCeW33*vevT - cwD6*delta*complex(0,1)*gwD6*ReCeW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1457 = Coupling(name = 'GC_1457',
                   value = '-(cwD6*delta*gwD6*ImCeW33*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCeW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1458 = Coupling(name = 'GC_1458',
                   value = 'cwD6*delta*gwD6*ImCeW33*vevT + cwD6*delta*complex(0,1)*gwD6*ReCeW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1459 = Coupling(name = 'GC_1459',
                   value = '-((delta*gwD6*ImCPhiud11*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1460 = Coupling(name = 'GC_1460',
                   value = '(delta*gwD6*ImCPhiud11*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1461 = Coupling(name = 'GC_1461',
                   value = '-((delta*gwD6*ImCPhiud12*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1462 = Coupling(name = 'GC_1462',
                   value = '(delta*gwD6*ImCPhiud12*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1463 = Coupling(name = 'GC_1463',
                   value = '-((delta*gwD6*ImCPhiud13*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1464 = Coupling(name = 'GC_1464',
                   value = '(delta*gwD6*ImCPhiud13*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1465 = Coupling(name = 'GC_1465',
                   value = '-((delta*gwD6*ImCPhiud21*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1466 = Coupling(name = 'GC_1466',
                   value = '(delta*gwD6*ImCPhiud21*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1467 = Coupling(name = 'GC_1467',
                   value = '-((delta*gwD6*ImCPhiud22*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1468 = Coupling(name = 'GC_1468',
                   value = '(delta*gwD6*ImCPhiud22*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1469 = Coupling(name = 'GC_1469',
                   value = '-((delta*gwD6*ImCPhiud23*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1470 = Coupling(name = 'GC_1470',
                   value = '(delta*gwD6*ImCPhiud23*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1471 = Coupling(name = 'GC_1471',
                   value = '-((delta*gwD6*ImCPhiud31*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1472 = Coupling(name = 'GC_1472',
                   value = '(delta*gwD6*ImCPhiud31*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1473 = Coupling(name = 'GC_1473',
                   value = '-((delta*gwD6*ImCPhiud32*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1474 = Coupling(name = 'GC_1474',
                   value = '(delta*gwD6*ImCPhiud32*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1475 = Coupling(name = 'GC_1475',
                   value = '-((delta*gwD6*ImCPhiud33*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1476 = Coupling(name = 'GC_1476',
                   value = '(delta*gwD6*ImCPhiud33*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCPhiud33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1477 = Coupling(name = 'GC_1477',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG11*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1478 = Coupling(name = 'GC_1478',
                   value = '(delta*complex(0,1)*gsD6*ImCuG11*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1479 = Coupling(name = 'GC_1479',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG11*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1480 = Coupling(name = 'GC_1480',
                   value = '(delta*complex(0,1)*gsD6*ImCuG11*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1481 = Coupling(name = 'GC_1481',
                   value = '-((delta*ImCuG12*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1482 = Coupling(name = 'GC_1482',
                   value = '(delta*ImCuG12*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1483 = Coupling(name = 'GC_1483',
                   value = '-((delta*ImCuG12*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1484 = Coupling(name = 'GC_1484',
                   value = '(delta*ImCuG12*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1485 = Coupling(name = 'GC_1485',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG12*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1486 = Coupling(name = 'GC_1486',
                   value = '(delta*complex(0,1)*gsD6*ImCuG12*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1487 = Coupling(name = 'GC_1487',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG12*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1488 = Coupling(name = 'GC_1488',
                   value = '(delta*complex(0,1)*gsD6*ImCuG12*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1489 = Coupling(name = 'GC_1489',
                   value = '-((delta*ImCuG13*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1490 = Coupling(name = 'GC_1490',
                   value = '(delta*ImCuG13*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1491 = Coupling(name = 'GC_1491',
                   value = '-((delta*ImCuG13*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1492 = Coupling(name = 'GC_1492',
                   value = '(delta*ImCuG13*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1493 = Coupling(name = 'GC_1493',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG13*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1494 = Coupling(name = 'GC_1494',
                   value = '(delta*complex(0,1)*gsD6*ImCuG13*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1495 = Coupling(name = 'GC_1495',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG13*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1496 = Coupling(name = 'GC_1496',
                   value = '(delta*complex(0,1)*gsD6*ImCuG13*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1497 = Coupling(name = 'GC_1497',
                   value = '-((delta*ImCuG21*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1498 = Coupling(name = 'GC_1498',
                   value = '(delta*ImCuG21*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1499 = Coupling(name = 'GC_1499',
                   value = '-((delta*ImCuG21*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1500 = Coupling(name = 'GC_1500',
                   value = '(delta*ImCuG21*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1501 = Coupling(name = 'GC_1501',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG21*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1502 = Coupling(name = 'GC_1502',
                   value = '(delta*complex(0,1)*gsD6*ImCuG21*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1503 = Coupling(name = 'GC_1503',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG21*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1504 = Coupling(name = 'GC_1504',
                   value = '(delta*complex(0,1)*gsD6*ImCuG21*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1505 = Coupling(name = 'GC_1505',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG22*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1506 = Coupling(name = 'GC_1506',
                   value = '(delta*complex(0,1)*gsD6*ImCuG22*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1507 = Coupling(name = 'GC_1507',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG22*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1508 = Coupling(name = 'GC_1508',
                   value = '(delta*complex(0,1)*gsD6*ImCuG22*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1509 = Coupling(name = 'GC_1509',
                   value = '-((delta*ImCuG23*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1510 = Coupling(name = 'GC_1510',
                   value = '(delta*ImCuG23*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1511 = Coupling(name = 'GC_1511',
                   value = '-((delta*ImCuG23*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1512 = Coupling(name = 'GC_1512',
                   value = '(delta*ImCuG23*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1513 = Coupling(name = 'GC_1513',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG23*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1514 = Coupling(name = 'GC_1514',
                   value = '(delta*complex(0,1)*gsD6*ImCuG23*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1515 = Coupling(name = 'GC_1515',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG23*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1516 = Coupling(name = 'GC_1516',
                   value = '(delta*complex(0,1)*gsD6*ImCuG23*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1517 = Coupling(name = 'GC_1517',
                   value = '-((delta*ImCuG31*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1518 = Coupling(name = 'GC_1518',
                   value = '(delta*ImCuG31*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1519 = Coupling(name = 'GC_1519',
                   value = '-((delta*ImCuG31*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1520 = Coupling(name = 'GC_1520',
                   value = '(delta*ImCuG31*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1521 = Coupling(name = 'GC_1521',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG31*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1522 = Coupling(name = 'GC_1522',
                   value = '(delta*complex(0,1)*gsD6*ImCuG31*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1523 = Coupling(name = 'GC_1523',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG31*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1524 = Coupling(name = 'GC_1524',
                   value = '(delta*complex(0,1)*gsD6*ImCuG31*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1525 = Coupling(name = 'GC_1525',
                   value = '-((delta*ImCuG32*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1526 = Coupling(name = 'GC_1526',
                   value = '(delta*ImCuG32*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1527 = Coupling(name = 'GC_1527',
                   value = '-((delta*ImCuG32*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1528 = Coupling(name = 'GC_1528',
                   value = '(delta*ImCuG32*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1529 = Coupling(name = 'GC_1529',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG32*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1530 = Coupling(name = 'GC_1530',
                   value = '(delta*complex(0,1)*gsD6*ImCuG32*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1531 = Coupling(name = 'GC_1531',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG32*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1532 = Coupling(name = 'GC_1532',
                   value = '(delta*complex(0,1)*gsD6*ImCuG32*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1533 = Coupling(name = 'GC_1533',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG33*vevT)/cmath.sqrt(2)) - (delta*gsD6*ReCuG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1534 = Coupling(name = 'GC_1534',
                   value = '(delta*complex(0,1)*gsD6*ImCuG33*vevT)/cmath.sqrt(2) - (delta*gsD6*ReCuG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1535 = Coupling(name = 'GC_1535',
                   value = '-((delta*complex(0,1)*gsD6*ImCuG33*vevT)/cmath.sqrt(2)) + (delta*gsD6*ReCuG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1536 = Coupling(name = 'GC_1536',
                   value = '(delta*complex(0,1)*gsD6*ImCuG33*vevT)/cmath.sqrt(2) + (delta*gsD6*ReCuG33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QCD':1})

GC_1537 = Coupling(name = 'GC_1537',
                   value = '(-3*delta*ImCuPhi12*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1538 = Coupling(name = 'GC_1538',
                   value = '(3*delta*ImCuPhi12*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1539 = Coupling(name = 'GC_1539',
                   value = '(-3*delta*ImCuPhi13*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1540 = Coupling(name = 'GC_1540',
                   value = '(3*delta*ImCuPhi13*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1541 = Coupling(name = 'GC_1541',
                   value = '(-3*delta*ImCuPhi21*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1542 = Coupling(name = 'GC_1542',
                   value = '(3*delta*ImCuPhi21*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1543 = Coupling(name = 'GC_1543',
                   value = '(-3*delta*ImCuPhi23*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1544 = Coupling(name = 'GC_1544',
                   value = '(3*delta*ImCuPhi23*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1545 = Coupling(name = 'GC_1545',
                   value = '(-3*delta*ImCuPhi31*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1546 = Coupling(name = 'GC_1546',
                   value = '(3*delta*ImCuPhi31*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1547 = Coupling(name = 'GC_1547',
                   value = '(-3*delta*ImCuPhi32*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1548 = Coupling(name = 'GC_1548',
                   value = '(3*delta*ImCuPhi32*vevT)/cmath.sqrt(2) + (3*delta*complex(0,1)*ReCuPhi32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':2})

GC_1549 = Coupling(name = 'GC_1549',
                   value = '-(delta*ImCuW11*vevT) + delta*complex(0,1)*ReCuW11*vevT',
                   order = {'NP':2})

GC_1550 = Coupling(name = 'GC_1550',
                   value = 'delta*ImCuW11*vevT + delta*complex(0,1)*ReCuW11*vevT',
                   order = {'NP':2})

GC_1551 = Coupling(name = 'GC_1551',
                   value = '-((delta*gwD6*ImCuW11*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1552 = Coupling(name = 'GC_1552',
                   value = '(delta*gwD6*ImCuW11*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1553 = Coupling(name = 'GC_1553',
                   value = '-((delta*gwD6*ImCuW11*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1554 = Coupling(name = 'GC_1554',
                   value = '(delta*gwD6*ImCuW11*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW11*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1555 = Coupling(name = 'GC_1555',
                   value = '-(cwD6*delta*gwD6*ImCuW11*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1556 = Coupling(name = 'GC_1556',
                   value = 'cwD6*delta*gwD6*ImCuW11*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1557 = Coupling(name = 'GC_1557',
                   value = '-(cwD6*delta*gwD6*ImCuW11*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1558 = Coupling(name = 'GC_1558',
                   value = 'cwD6*delta*gwD6*ImCuW11*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW11*vevT',
                   order = {'NP':2,'QED':1})

GC_1559 = Coupling(name = 'GC_1559',
                   value = '-(delta*ImCuW12*vevT) + delta*complex(0,1)*ReCuW12*vevT',
                   order = {'NP':2})

GC_1560 = Coupling(name = 'GC_1560',
                   value = 'delta*ImCuW12*vevT + delta*complex(0,1)*ReCuW12*vevT',
                   order = {'NP':2})

GC_1561 = Coupling(name = 'GC_1561',
                   value = '-((delta*gwD6*ImCuW12*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1562 = Coupling(name = 'GC_1562',
                   value = '(delta*gwD6*ImCuW12*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1563 = Coupling(name = 'GC_1563',
                   value = '-((delta*gwD6*ImCuW12*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1564 = Coupling(name = 'GC_1564',
                   value = '(delta*gwD6*ImCuW12*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW12*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1565 = Coupling(name = 'GC_1565',
                   value = '-(cwD6*delta*gwD6*ImCuW12*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1566 = Coupling(name = 'GC_1566',
                   value = 'cwD6*delta*gwD6*ImCuW12*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1567 = Coupling(name = 'GC_1567',
                   value = '-(cwD6*delta*gwD6*ImCuW12*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1568 = Coupling(name = 'GC_1568',
                   value = 'cwD6*delta*gwD6*ImCuW12*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW12*vevT',
                   order = {'NP':2,'QED':1})

GC_1569 = Coupling(name = 'GC_1569',
                   value = '-(delta*ImCuW13*vevT) + delta*complex(0,1)*ReCuW13*vevT',
                   order = {'NP':2})

GC_1570 = Coupling(name = 'GC_1570',
                   value = 'delta*ImCuW13*vevT + delta*complex(0,1)*ReCuW13*vevT',
                   order = {'NP':2})

GC_1571 = Coupling(name = 'GC_1571',
                   value = '-((delta*gwD6*ImCuW13*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1572 = Coupling(name = 'GC_1572',
                   value = '(delta*gwD6*ImCuW13*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1573 = Coupling(name = 'GC_1573',
                   value = '-((delta*gwD6*ImCuW13*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1574 = Coupling(name = 'GC_1574',
                   value = '(delta*gwD6*ImCuW13*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW13*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1575 = Coupling(name = 'GC_1575',
                   value = '-(cwD6*delta*gwD6*ImCuW13*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1576 = Coupling(name = 'GC_1576',
                   value = 'cwD6*delta*gwD6*ImCuW13*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1577 = Coupling(name = 'GC_1577',
                   value = '-(cwD6*delta*gwD6*ImCuW13*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1578 = Coupling(name = 'GC_1578',
                   value = 'cwD6*delta*gwD6*ImCuW13*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW13*vevT',
                   order = {'NP':2,'QED':1})

GC_1579 = Coupling(name = 'GC_1579',
                   value = '-(delta*ImCuW21*vevT) + delta*complex(0,1)*ReCuW21*vevT',
                   order = {'NP':2})

GC_1580 = Coupling(name = 'GC_1580',
                   value = 'delta*ImCuW21*vevT + delta*complex(0,1)*ReCuW21*vevT',
                   order = {'NP':2})

GC_1581 = Coupling(name = 'GC_1581',
                   value = '-((delta*gwD6*ImCuW21*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1582 = Coupling(name = 'GC_1582',
                   value = '(delta*gwD6*ImCuW21*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1583 = Coupling(name = 'GC_1583',
                   value = '-((delta*gwD6*ImCuW21*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1584 = Coupling(name = 'GC_1584',
                   value = '(delta*gwD6*ImCuW21*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW21*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1585 = Coupling(name = 'GC_1585',
                   value = '-(cwD6*delta*gwD6*ImCuW21*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1586 = Coupling(name = 'GC_1586',
                   value = 'cwD6*delta*gwD6*ImCuW21*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1587 = Coupling(name = 'GC_1587',
                   value = '-(cwD6*delta*gwD6*ImCuW21*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1588 = Coupling(name = 'GC_1588',
                   value = 'cwD6*delta*gwD6*ImCuW21*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW21*vevT',
                   order = {'NP':2,'QED':1})

GC_1589 = Coupling(name = 'GC_1589',
                   value = '-(delta*ImCuW22*vevT) + delta*complex(0,1)*ReCuW22*vevT',
                   order = {'NP':2})

GC_1590 = Coupling(name = 'GC_1590',
                   value = 'delta*ImCuW22*vevT + delta*complex(0,1)*ReCuW22*vevT',
                   order = {'NP':2})

GC_1591 = Coupling(name = 'GC_1591',
                   value = '-((delta*gwD6*ImCuW22*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1592 = Coupling(name = 'GC_1592',
                   value = '(delta*gwD6*ImCuW22*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1593 = Coupling(name = 'GC_1593',
                   value = '-((delta*gwD6*ImCuW22*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1594 = Coupling(name = 'GC_1594',
                   value = '(delta*gwD6*ImCuW22*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW22*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1595 = Coupling(name = 'GC_1595',
                   value = '-(cwD6*delta*gwD6*ImCuW22*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1596 = Coupling(name = 'GC_1596',
                   value = 'cwD6*delta*gwD6*ImCuW22*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1597 = Coupling(name = 'GC_1597',
                   value = '-(cwD6*delta*gwD6*ImCuW22*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1598 = Coupling(name = 'GC_1598',
                   value = 'cwD6*delta*gwD6*ImCuW22*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW22*vevT',
                   order = {'NP':2,'QED':1})

GC_1599 = Coupling(name = 'GC_1599',
                   value = '-(delta*ImCuW23*vevT) + delta*complex(0,1)*ReCuW23*vevT',
                   order = {'NP':2})

GC_1600 = Coupling(name = 'GC_1600',
                   value = 'delta*ImCuW23*vevT + delta*complex(0,1)*ReCuW23*vevT',
                   order = {'NP':2})

GC_1601 = Coupling(name = 'GC_1601',
                   value = '-((delta*gwD6*ImCuW23*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1602 = Coupling(name = 'GC_1602',
                   value = '(delta*gwD6*ImCuW23*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1603 = Coupling(name = 'GC_1603',
                   value = '-((delta*gwD6*ImCuW23*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1604 = Coupling(name = 'GC_1604',
                   value = '(delta*gwD6*ImCuW23*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW23*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1605 = Coupling(name = 'GC_1605',
                   value = '-(cwD6*delta*gwD6*ImCuW23*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1606 = Coupling(name = 'GC_1606',
                   value = 'cwD6*delta*gwD6*ImCuW23*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1607 = Coupling(name = 'GC_1607',
                   value = '-(cwD6*delta*gwD6*ImCuW23*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1608 = Coupling(name = 'GC_1608',
                   value = 'cwD6*delta*gwD6*ImCuW23*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW23*vevT',
                   order = {'NP':2,'QED':1})

GC_1609 = Coupling(name = 'GC_1609',
                   value = '-(delta*ImCuW31*vevT) + delta*complex(0,1)*ReCuW31*vevT',
                   order = {'NP':2})

GC_1610 = Coupling(name = 'GC_1610',
                   value = 'delta*ImCuW31*vevT + delta*complex(0,1)*ReCuW31*vevT',
                   order = {'NP':2})

GC_1611 = Coupling(name = 'GC_1611',
                   value = '-((delta*gwD6*ImCuW31*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1612 = Coupling(name = 'GC_1612',
                   value = '(delta*gwD6*ImCuW31*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1613 = Coupling(name = 'GC_1613',
                   value = '-((delta*gwD6*ImCuW31*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1614 = Coupling(name = 'GC_1614',
                   value = '(delta*gwD6*ImCuW31*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW31*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1615 = Coupling(name = 'GC_1615',
                   value = '-(cwD6*delta*gwD6*ImCuW31*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1616 = Coupling(name = 'GC_1616',
                   value = 'cwD6*delta*gwD6*ImCuW31*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1617 = Coupling(name = 'GC_1617',
                   value = '-(cwD6*delta*gwD6*ImCuW31*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1618 = Coupling(name = 'GC_1618',
                   value = 'cwD6*delta*gwD6*ImCuW31*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW31*vevT',
                   order = {'NP':2,'QED':1})

GC_1619 = Coupling(name = 'GC_1619',
                   value = '-(delta*ImCuW32*vevT) + delta*complex(0,1)*ReCuW32*vevT',
                   order = {'NP':2})

GC_1620 = Coupling(name = 'GC_1620',
                   value = 'delta*ImCuW32*vevT + delta*complex(0,1)*ReCuW32*vevT',
                   order = {'NP':2})

GC_1621 = Coupling(name = 'GC_1621',
                   value = '-((delta*gwD6*ImCuW32*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1622 = Coupling(name = 'GC_1622',
                   value = '(delta*gwD6*ImCuW32*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1623 = Coupling(name = 'GC_1623',
                   value = '-((delta*gwD6*ImCuW32*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1624 = Coupling(name = 'GC_1624',
                   value = '(delta*gwD6*ImCuW32*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW32*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1625 = Coupling(name = 'GC_1625',
                   value = '-(cwD6*delta*gwD6*ImCuW32*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1626 = Coupling(name = 'GC_1626',
                   value = 'cwD6*delta*gwD6*ImCuW32*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1627 = Coupling(name = 'GC_1627',
                   value = '-(cwD6*delta*gwD6*ImCuW32*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1628 = Coupling(name = 'GC_1628',
                   value = 'cwD6*delta*gwD6*ImCuW32*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW32*vevT',
                   order = {'NP':2,'QED':1})

GC_1629 = Coupling(name = 'GC_1629',
                   value = '-(delta*ImCuW33*vevT) + delta*complex(0,1)*ReCuW33*vevT',
                   order = {'NP':2})

GC_1630 = Coupling(name = 'GC_1630',
                   value = 'delta*ImCuW33*vevT + delta*complex(0,1)*ReCuW33*vevT',
                   order = {'NP':2})

GC_1631 = Coupling(name = 'GC_1631',
                   value = '-((delta*gwD6*ImCuW33*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*gwD6*ReCuW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1632 = Coupling(name = 'GC_1632',
                   value = '(delta*gwD6*ImCuW33*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*gwD6*ReCuW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1633 = Coupling(name = 'GC_1633',
                   value = '-((delta*gwD6*ImCuW33*vevT)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCuW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1634 = Coupling(name = 'GC_1634',
                   value = '(delta*gwD6*ImCuW33*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReCuW33*vevT)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1635 = Coupling(name = 'GC_1635',
                   value = '-(cwD6*delta*gwD6*ImCuW33*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCuW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1636 = Coupling(name = 'GC_1636',
                   value = 'cwD6*delta*gwD6*ImCuW33*vevT - cwD6*delta*complex(0,1)*gwD6*ReCuW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1637 = Coupling(name = 'GC_1637',
                   value = '-(cwD6*delta*gwD6*ImCuW33*vevT) + cwD6*delta*complex(0,1)*gwD6*ReCuW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1638 = Coupling(name = 'GC_1638',
                   value = 'cwD6*delta*gwD6*ImCuW33*vevT + cwD6*delta*complex(0,1)*gwD6*ReCuW33*vevT',
                   order = {'NP':2,'QED':1})

GC_1639 = Coupling(name = 'GC_1639',
                   value = '-((cwD6*delta*ImCdW11*vevT)/cmath.sqrt(2)) - (delta*ImCdB11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1640 = Coupling(name = 'GC_1640',
                   value = '-((cwD6*delta*ImCdW33*vevT)/cmath.sqrt(2)) - (delta*ImCdB33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1641 = Coupling(name = 'GC_1641',
                   value = '(cwD6*delta*ImCdB11*vevT)/cmath.sqrt(2) - (delta*ImCdW11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1642 = Coupling(name = 'GC_1642',
                   value = '(cwD6*delta*ImCdB22*vevT)/cmath.sqrt(2) - (delta*ImCdW22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1643 = Coupling(name = 'GC_1643',
                   value = '(cwD6*delta*ImCdB33*vevT)/cmath.sqrt(2) - (delta*ImCdW33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1644 = Coupling(name = 'GC_1644',
                   value = '-((cwD6*delta*ImCeW11*vevT)/cmath.sqrt(2)) - (delta*ImCeB11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1645 = Coupling(name = 'GC_1645',
                   value = '-((cwD6*delta*ImCeW22*vevT)/cmath.sqrt(2)) - (delta*ImCeB22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1646 = Coupling(name = 'GC_1646',
                   value = '-((cwD6*delta*ImCeW33*vevT)/cmath.sqrt(2)) - (delta*ImCeB33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1647 = Coupling(name = 'GC_1647',
                   value = '(cwD6*delta*ImCeB11*vevT)/cmath.sqrt(2) - (delta*ImCeW11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1648 = Coupling(name = 'GC_1648',
                   value = '(cwD6*delta*ImCeB22*vevT)/cmath.sqrt(2) - (delta*ImCeW22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1649 = Coupling(name = 'GC_1649',
                   value = '(cwD6*delta*ImCeB33*vevT)/cmath.sqrt(2) - (delta*ImCeW33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1650 = Coupling(name = 'GC_1650',
                   value = '(cwD6*delta*ImCuW11*vevT)/cmath.sqrt(2) - (delta*ImCuB11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1651 = Coupling(name = 'GC_1651',
                   value = '(cwD6*delta*ImCuW22*vevT)/cmath.sqrt(2) - (delta*ImCuB22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1652 = Coupling(name = 'GC_1652',
                   value = '(cwD6*delta*ImCuW33*vevT)/cmath.sqrt(2) - (delta*ImCuB33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1653 = Coupling(name = 'GC_1653',
                   value = '(cwD6*delta*ImCuB11*vevT)/cmath.sqrt(2) + (delta*ImCuW11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1654 = Coupling(name = 'GC_1654',
                   value = '(cwD6*delta*ImCuB22*vevT)/cmath.sqrt(2) + (delta*ImCuW22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1655 = Coupling(name = 'GC_1655',
                   value = '(cwD6*delta*ImCuB33*vevT)/cmath.sqrt(2) + (delta*ImCuW33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1656 = Coupling(name = 'GC_1656',
                   value = '-2*cwD6*delta*complex(0,1)*gwD6*ReC1Phil33*vevT - 2*delta*complex(0,1)*g1D6*ReC1Phil33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1657 = Coupling(name = 'GC_1657',
                   value = '2*cwD6*delta*complex(0,1)*g1D6*ReC1Phil33*vevT - 2*delta*complex(0,1)*gwD6*ReC1Phil33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1658 = Coupling(name = 'GC_1658',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil11*vevT) - cwD6*delta*complex(0,1)*gwD6*ReC3Phil11*vevT - delta*complex(0,1)*g1D6*ReC1Phil11*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phil11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1659 = Coupling(name = 'GC_1659',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil11*vevT) + cwD6*delta*complex(0,1)*gwD6*ReC3Phil11*vevT - delta*complex(0,1)*g1D6*ReC1Phil11*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phil11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1660 = Coupling(name = 'GC_1660',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil11*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phil11*vevT - delta*complex(0,1)*gwD6*ReC1Phil11*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phil11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1661 = Coupling(name = 'GC_1661',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil11*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phil11*vevT - delta*complex(0,1)*gwD6*ReC1Phil11*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phil11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1662 = Coupling(name = 'GC_1662',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil22*vevT) - cwD6*delta*complex(0,1)*gwD6*ReC3Phil22*vevT - delta*complex(0,1)*g1D6*ReC1Phil22*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phil22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1663 = Coupling(name = 'GC_1663',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil22*vevT) + cwD6*delta*complex(0,1)*gwD6*ReC3Phil22*vevT - delta*complex(0,1)*g1D6*ReC1Phil22*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phil22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1664 = Coupling(name = 'GC_1664',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil22*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phil22*vevT - delta*complex(0,1)*gwD6*ReC1Phil22*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phil22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1665 = Coupling(name = 'GC_1665',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil22*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phil22*vevT - delta*complex(0,1)*gwD6*ReC1Phil22*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phil22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1666 = Coupling(name = 'GC_1666',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq11*vevT) - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq11*vevT - delta*complex(0,1)*g1D6*ReC1Phiq11*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1667 = Coupling(name = 'GC_1667',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq11*vevT) + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq11*vevT - delta*complex(0,1)*g1D6*ReC1Phiq11*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1668 = Coupling(name = 'GC_1668',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq11*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq11*vevT - delta*complex(0,1)*gwD6*ReC1Phiq11*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1669 = Coupling(name = 'GC_1669',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq11*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq11*vevT - delta*complex(0,1)*gwD6*ReC1Phiq11*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1670 = Coupling(name = 'GC_1670',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq12*vevT) - cwD6*delta*gwD6*ImC3Phiq12*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT - delta*g1D6*ImC1Phiq12*swD6*vevT - delta*g1D6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1671 = Coupling(name = 'GC_1671',
                   value = 'cwD6*delta*gwD6*ImC1Phiq12*vevT + cwD6*delta*gwD6*ImC3Phiq12*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT + delta*g1D6*ImC1Phiq12*swD6*vevT + delta*g1D6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1672 = Coupling(name = 'GC_1672',
                   value = 'cwD6*delta*gwD6*ImC1Phiq12*vevT - cwD6*delta*gwD6*ImC3Phiq12*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT + delta*g1D6*ImC1Phiq12*swD6*vevT - delta*g1D6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1673 = Coupling(name = 'GC_1673',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq12*vevT) + cwD6*delta*gwD6*ImC3Phiq12*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT - delta*g1D6*ImC1Phiq12*swD6*vevT + delta*g1D6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1674 = Coupling(name = 'GC_1674',
                   value = 'cwD6*delta*g1D6*ImC1Phiq12*vevT + cwD6*delta*g1D6*ImC3Phiq12*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT - delta*gwD6*ImC1Phiq12*swD6*vevT - delta*gwD6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1675 = Coupling(name = 'GC_1675',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq12*vevT) - cwD6*delta*g1D6*ImC3Phiq12*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT + delta*gwD6*ImC1Phiq12*swD6*vevT + delta*gwD6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1676 = Coupling(name = 'GC_1676',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq12*vevT) + cwD6*delta*g1D6*ImC3Phiq12*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT + delta*gwD6*ImC1Phiq12*swD6*vevT - delta*gwD6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1677 = Coupling(name = 'GC_1677',
                   value = 'cwD6*delta*g1D6*ImC1Phiq12*vevT - cwD6*delta*g1D6*ImC3Phiq12*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT - delta*gwD6*ImC1Phiq12*swD6*vevT + delta*gwD6*ImC3Phiq12*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1678 = Coupling(name = 'GC_1678',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq13*vevT) - cwD6*delta*gwD6*ImC3Phiq13*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT - delta*g1D6*ImC1Phiq13*swD6*vevT - delta*g1D6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1679 = Coupling(name = 'GC_1679',
                   value = 'cwD6*delta*gwD6*ImC1Phiq13*vevT + cwD6*delta*gwD6*ImC3Phiq13*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT + delta*g1D6*ImC1Phiq13*swD6*vevT + delta*g1D6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1680 = Coupling(name = 'GC_1680',
                   value = 'cwD6*delta*gwD6*ImC1Phiq13*vevT - cwD6*delta*gwD6*ImC3Phiq13*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT + delta*g1D6*ImC1Phiq13*swD6*vevT - delta*g1D6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1681 = Coupling(name = 'GC_1681',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq13*vevT) + cwD6*delta*gwD6*ImC3Phiq13*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT - delta*g1D6*ImC1Phiq13*swD6*vevT + delta*g1D6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1682 = Coupling(name = 'GC_1682',
                   value = 'cwD6*delta*g1D6*ImC1Phiq13*vevT + cwD6*delta*g1D6*ImC3Phiq13*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT - delta*gwD6*ImC1Phiq13*swD6*vevT - delta*gwD6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1683 = Coupling(name = 'GC_1683',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq13*vevT) - cwD6*delta*g1D6*ImC3Phiq13*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT + delta*gwD6*ImC1Phiq13*swD6*vevT + delta*gwD6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1684 = Coupling(name = 'GC_1684',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq13*vevT) + cwD6*delta*g1D6*ImC3Phiq13*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT + delta*gwD6*ImC1Phiq13*swD6*vevT - delta*gwD6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1685 = Coupling(name = 'GC_1685',
                   value = 'cwD6*delta*g1D6*ImC1Phiq13*vevT - cwD6*delta*g1D6*ImC3Phiq13*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT - delta*gwD6*ImC1Phiq13*swD6*vevT + delta*gwD6*ImC3Phiq13*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1686 = Coupling(name = 'GC_1686',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq22*vevT) - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq22*vevT - delta*complex(0,1)*g1D6*ReC1Phiq22*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1687 = Coupling(name = 'GC_1687',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq22*vevT) + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq22*vevT - delta*complex(0,1)*g1D6*ReC1Phiq22*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1688 = Coupling(name = 'GC_1688',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq22*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq22*vevT - delta*complex(0,1)*gwD6*ReC1Phiq22*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1689 = Coupling(name = 'GC_1689',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq22*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq22*vevT - delta*complex(0,1)*gwD6*ReC1Phiq22*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1690 = Coupling(name = 'GC_1690',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq23*vevT) - cwD6*delta*gwD6*ImC3Phiq23*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT - delta*g1D6*ImC1Phiq23*swD6*vevT - delta*g1D6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1691 = Coupling(name = 'GC_1691',
                   value = 'cwD6*delta*gwD6*ImC1Phiq23*vevT + cwD6*delta*gwD6*ImC3Phiq23*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT + delta*g1D6*ImC1Phiq23*swD6*vevT + delta*g1D6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1692 = Coupling(name = 'GC_1692',
                   value = 'cwD6*delta*gwD6*ImC1Phiq23*vevT - cwD6*delta*gwD6*ImC3Phiq23*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT + delta*g1D6*ImC1Phiq23*swD6*vevT - delta*g1D6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1693 = Coupling(name = 'GC_1693',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq23*vevT) + cwD6*delta*gwD6*ImC3Phiq23*vevT - cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT - delta*g1D6*ImC1Phiq23*swD6*vevT + delta*g1D6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1694 = Coupling(name = 'GC_1694',
                   value = 'cwD6*delta*g1D6*ImC1Phiq23*vevT + cwD6*delta*g1D6*ImC3Phiq23*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT - delta*gwD6*ImC1Phiq23*swD6*vevT - delta*gwD6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1695 = Coupling(name = 'GC_1695',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq23*vevT) - cwD6*delta*g1D6*ImC3Phiq23*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT + delta*gwD6*ImC1Phiq23*swD6*vevT + delta*gwD6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1696 = Coupling(name = 'GC_1696',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq23*vevT) + cwD6*delta*g1D6*ImC3Phiq23*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT + delta*gwD6*ImC1Phiq23*swD6*vevT - delta*gwD6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1697 = Coupling(name = 'GC_1697',
                   value = 'cwD6*delta*g1D6*ImC1Phiq23*vevT - cwD6*delta*g1D6*ImC3Phiq23*vevT + cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT - delta*gwD6*ImC1Phiq23*swD6*vevT + delta*gwD6*ImC3Phiq23*swD6*vevT - delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1698 = Coupling(name = 'GC_1698',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq33*vevT) - cwD6*delta*complex(0,1)*gwD6*ReC3Phiq33*vevT - delta*complex(0,1)*g1D6*ReC1Phiq33*swD6*vevT - delta*complex(0,1)*g1D6*ReC3Phiq33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1699 = Coupling(name = 'GC_1699',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq33*vevT) + cwD6*delta*complex(0,1)*gwD6*ReC3Phiq33*vevT - delta*complex(0,1)*g1D6*ReC1Phiq33*swD6*vevT + delta*complex(0,1)*g1D6*ReC3Phiq33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1700 = Coupling(name = 'GC_1700',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq33*vevT + cwD6*delta*complex(0,1)*g1D6*ReC3Phiq33*vevT - delta*complex(0,1)*gwD6*ReC1Phiq33*swD6*vevT - delta*complex(0,1)*gwD6*ReC3Phiq33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1701 = Coupling(name = 'GC_1701',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phiq33*vevT - cwD6*delta*complex(0,1)*g1D6*ReC3Phiq33*vevT - delta*complex(0,1)*gwD6*ReC1Phiq33*swD6*vevT + delta*complex(0,1)*gwD6*ReC3Phiq33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1702 = Coupling(name = 'GC_1702',
                   value = '-((cwD6*delta*complex(0,1)*ReCdW11*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCdB11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1703 = Coupling(name = 'GC_1703',
                   value = '-((cwD6*delta*ImCdW12*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW12*vevT)/cmath.sqrt(2) - (delta*ImCdB12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1704 = Coupling(name = 'GC_1704',
                   value = '(cwD6*delta*ImCdW12*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW12*vevT)/cmath.sqrt(2) + (delta*ImCdB12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1705 = Coupling(name = 'GC_1705',
                   value = '-((cwD6*delta*ImCdW13*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW13*vevT)/cmath.sqrt(2) - (delta*ImCdB13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1706 = Coupling(name = 'GC_1706',
                   value = '(cwD6*delta*ImCdW13*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW13*vevT)/cmath.sqrt(2) + (delta*ImCdB13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1707 = Coupling(name = 'GC_1707',
                   value = '-((cwD6*delta*ImCdW21*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW21*vevT)/cmath.sqrt(2) - (delta*ImCdB21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1708 = Coupling(name = 'GC_1708',
                   value = '(cwD6*delta*ImCdW21*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW21*vevT)/cmath.sqrt(2) + (delta*ImCdB21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1709 = Coupling(name = 'GC_1709',
                   value = '-((cwD6*delta*complex(0,1)*ReCdW22*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCdB22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1710 = Coupling(name = 'GC_1710',
                   value = '-((cwD6*delta*ImCdW23*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW23*vevT)/cmath.sqrt(2) - (delta*ImCdB23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1711 = Coupling(name = 'GC_1711',
                   value = '(cwD6*delta*ImCdW23*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW23*vevT)/cmath.sqrt(2) + (delta*ImCdB23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1712 = Coupling(name = 'GC_1712',
                   value = '-((cwD6*delta*ImCdW31*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW31*vevT)/cmath.sqrt(2) - (delta*ImCdB31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1713 = Coupling(name = 'GC_1713',
                   value = '(cwD6*delta*ImCdW31*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW31*vevT)/cmath.sqrt(2) + (delta*ImCdB31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1714 = Coupling(name = 'GC_1714',
                   value = '-((cwD6*delta*ImCdW32*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCdW32*vevT)/cmath.sqrt(2) - (delta*ImCdB32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1715 = Coupling(name = 'GC_1715',
                   value = '(cwD6*delta*ImCdW32*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCdW32*vevT)/cmath.sqrt(2) + (delta*ImCdB32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdB32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1716 = Coupling(name = 'GC_1716',
                   value = '-((cwD6*delta*complex(0,1)*ReCdW33*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCdB33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1717 = Coupling(name = 'GC_1717',
                   value = '(cwD6*delta*complex(0,1)*ReCdB11*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1718 = Coupling(name = 'GC_1718',
                   value = '-(delta*gwD6*ImCdW11*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1719 = Coupling(name = 'GC_1719',
                   value = 'delta*gwD6*ImCdW11*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1720 = Coupling(name = 'GC_1720',
                   value = '-(delta*gwD6*ImCdW11*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1721 = Coupling(name = 'GC_1721',
                   value = 'delta*gwD6*ImCdW11*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1722 = Coupling(name = 'GC_1722',
                   value = '(cwD6*delta*ImCdB12*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB12*vevT)/cmath.sqrt(2) - (delta*ImCdW12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1723 = Coupling(name = 'GC_1723',
                   value = '-((cwD6*delta*ImCdB12*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB12*vevT)/cmath.sqrt(2) + (delta*ImCdW12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1724 = Coupling(name = 'GC_1724',
                   value = '-(delta*gwD6*ImCdW12*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1725 = Coupling(name = 'GC_1725',
                   value = 'delta*gwD6*ImCdW12*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1726 = Coupling(name = 'GC_1726',
                   value = '-(delta*gwD6*ImCdW12*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1727 = Coupling(name = 'GC_1727',
                   value = 'delta*gwD6*ImCdW12*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1728 = Coupling(name = 'GC_1728',
                   value = '(cwD6*delta*ImCdB13*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB13*vevT)/cmath.sqrt(2) - (delta*ImCdW13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1729 = Coupling(name = 'GC_1729',
                   value = '-((cwD6*delta*ImCdB13*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB13*vevT)/cmath.sqrt(2) + (delta*ImCdW13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1730 = Coupling(name = 'GC_1730',
                   value = '-(delta*gwD6*ImCdW13*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1731 = Coupling(name = 'GC_1731',
                   value = 'delta*gwD6*ImCdW13*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1732 = Coupling(name = 'GC_1732',
                   value = '-(delta*gwD6*ImCdW13*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1733 = Coupling(name = 'GC_1733',
                   value = 'delta*gwD6*ImCdW13*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1734 = Coupling(name = 'GC_1734',
                   value = '(cwD6*delta*ImCdB21*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB21*vevT)/cmath.sqrt(2) - (delta*ImCdW21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1735 = Coupling(name = 'GC_1735',
                   value = '-((cwD6*delta*ImCdB21*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB21*vevT)/cmath.sqrt(2) + (delta*ImCdW21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1736 = Coupling(name = 'GC_1736',
                   value = '-(delta*gwD6*ImCdW21*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1737 = Coupling(name = 'GC_1737',
                   value = 'delta*gwD6*ImCdW21*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1738 = Coupling(name = 'GC_1738',
                   value = '-(delta*gwD6*ImCdW21*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1739 = Coupling(name = 'GC_1739',
                   value = 'delta*gwD6*ImCdW21*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1740 = Coupling(name = 'GC_1740',
                   value = '(cwD6*delta*complex(0,1)*ReCdB22*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1741 = Coupling(name = 'GC_1741',
                   value = '-(delta*gwD6*ImCdW22*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1742 = Coupling(name = 'GC_1742',
                   value = 'delta*gwD6*ImCdW22*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1743 = Coupling(name = 'GC_1743',
                   value = '-(delta*gwD6*ImCdW22*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1744 = Coupling(name = 'GC_1744',
                   value = 'delta*gwD6*ImCdW22*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1745 = Coupling(name = 'GC_1745',
                   value = '(cwD6*delta*ImCdB23*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB23*vevT)/cmath.sqrt(2) - (delta*ImCdW23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1746 = Coupling(name = 'GC_1746',
                   value = '-((cwD6*delta*ImCdB23*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB23*vevT)/cmath.sqrt(2) + (delta*ImCdW23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1747 = Coupling(name = 'GC_1747',
                   value = '-(delta*gwD6*ImCdW23*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1748 = Coupling(name = 'GC_1748',
                   value = 'delta*gwD6*ImCdW23*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1749 = Coupling(name = 'GC_1749',
                   value = '-(delta*gwD6*ImCdW23*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1750 = Coupling(name = 'GC_1750',
                   value = 'delta*gwD6*ImCdW23*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1751 = Coupling(name = 'GC_1751',
                   value = '(cwD6*delta*ImCdB31*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB31*vevT)/cmath.sqrt(2) - (delta*ImCdW31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1752 = Coupling(name = 'GC_1752',
                   value = '-((cwD6*delta*ImCdB31*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB31*vevT)/cmath.sqrt(2) + (delta*ImCdW31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1753 = Coupling(name = 'GC_1753',
                   value = '-(delta*gwD6*ImCdW31*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1754 = Coupling(name = 'GC_1754',
                   value = 'delta*gwD6*ImCdW31*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1755 = Coupling(name = 'GC_1755',
                   value = '-(delta*gwD6*ImCdW31*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1756 = Coupling(name = 'GC_1756',
                   value = 'delta*gwD6*ImCdW31*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1757 = Coupling(name = 'GC_1757',
                   value = '(cwD6*delta*ImCdB32*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCdB32*vevT)/cmath.sqrt(2) - (delta*ImCdW32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1758 = Coupling(name = 'GC_1758',
                   value = '-((cwD6*delta*ImCdB32*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCdB32*vevT)/cmath.sqrt(2) + (delta*ImCdW32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1759 = Coupling(name = 'GC_1759',
                   value = '-(delta*gwD6*ImCdW32*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1760 = Coupling(name = 'GC_1760',
                   value = 'delta*gwD6*ImCdW32*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1761 = Coupling(name = 'GC_1761',
                   value = '-(delta*gwD6*ImCdW32*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1762 = Coupling(name = 'GC_1762',
                   value = 'delta*gwD6*ImCdW32*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1763 = Coupling(name = 'GC_1763',
                   value = '(cwD6*delta*complex(0,1)*ReCdB33*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCdW33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1764 = Coupling(name = 'GC_1764',
                   value = '-(delta*gwD6*ImCdW33*swD6*vevT) - delta*complex(0,1)*gwD6*ReCdW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1765 = Coupling(name = 'GC_1765',
                   value = 'delta*gwD6*ImCdW33*swD6*vevT - delta*complex(0,1)*gwD6*ReCdW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1766 = Coupling(name = 'GC_1766',
                   value = '-(delta*gwD6*ImCdW33*swD6*vevT) + delta*complex(0,1)*gwD6*ReCdW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1767 = Coupling(name = 'GC_1767',
                   value = 'delta*gwD6*ImCdW33*swD6*vevT + delta*complex(0,1)*gwD6*ReCdW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1768 = Coupling(name = 'GC_1768',
                   value = '-((cwD6*delta*complex(0,1)*ReCeW11*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCeB11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1769 = Coupling(name = 'GC_1769',
                   value = '-((cwD6*delta*ImCeW12*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW12*vevT)/cmath.sqrt(2) - (delta*ImCeB12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1770 = Coupling(name = 'GC_1770',
                   value = '(cwD6*delta*ImCeW12*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW12*vevT)/cmath.sqrt(2) + (delta*ImCeB12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1771 = Coupling(name = 'GC_1771',
                   value = '-((cwD6*delta*ImCeW13*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW13*vevT)/cmath.sqrt(2) - (delta*ImCeB13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1772 = Coupling(name = 'GC_1772',
                   value = '(cwD6*delta*ImCeW13*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW13*vevT)/cmath.sqrt(2) + (delta*ImCeB13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1773 = Coupling(name = 'GC_1773',
                   value = '-((cwD6*delta*ImCeW21*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW21*vevT)/cmath.sqrt(2) - (delta*ImCeB21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1774 = Coupling(name = 'GC_1774',
                   value = '(cwD6*delta*ImCeW21*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW21*vevT)/cmath.sqrt(2) + (delta*ImCeB21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1775 = Coupling(name = 'GC_1775',
                   value = '-((cwD6*delta*complex(0,1)*ReCeW22*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCeB22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1776 = Coupling(name = 'GC_1776',
                   value = '-((cwD6*delta*ImCeW23*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW23*vevT)/cmath.sqrt(2) - (delta*ImCeB23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1777 = Coupling(name = 'GC_1777',
                   value = '(cwD6*delta*ImCeW23*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW23*vevT)/cmath.sqrt(2) + (delta*ImCeB23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1778 = Coupling(name = 'GC_1778',
                   value = '-((cwD6*delta*ImCeW31*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW31*vevT)/cmath.sqrt(2) - (delta*ImCeB31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1779 = Coupling(name = 'GC_1779',
                   value = '(cwD6*delta*ImCeW31*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW31*vevT)/cmath.sqrt(2) + (delta*ImCeB31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1780 = Coupling(name = 'GC_1780',
                   value = '-((cwD6*delta*ImCeW32*vevT)/cmath.sqrt(2)) - (cwD6*delta*complex(0,1)*ReCeW32*vevT)/cmath.sqrt(2) - (delta*ImCeB32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1781 = Coupling(name = 'GC_1781',
                   value = '(cwD6*delta*ImCeW32*vevT)/cmath.sqrt(2) - (cwD6*delta*complex(0,1)*ReCeW32*vevT)/cmath.sqrt(2) + (delta*ImCeB32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeB32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1782 = Coupling(name = 'GC_1782',
                   value = '-((cwD6*delta*complex(0,1)*ReCeW33*vevT)/cmath.sqrt(2)) - (delta*complex(0,1)*ReCeB33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1783 = Coupling(name = 'GC_1783',
                   value = '(cwD6*delta*complex(0,1)*ReCeB11*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1784 = Coupling(name = 'GC_1784',
                   value = '-(delta*gwD6*ImCeW11*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1785 = Coupling(name = 'GC_1785',
                   value = 'delta*gwD6*ImCeW11*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1786 = Coupling(name = 'GC_1786',
                   value = '-(delta*gwD6*ImCeW11*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1787 = Coupling(name = 'GC_1787',
                   value = 'delta*gwD6*ImCeW11*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1788 = Coupling(name = 'GC_1788',
                   value = '(cwD6*delta*ImCeB12*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB12*vevT)/cmath.sqrt(2) - (delta*ImCeW12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1789 = Coupling(name = 'GC_1789',
                   value = '-((cwD6*delta*ImCeB12*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB12*vevT)/cmath.sqrt(2) + (delta*ImCeW12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1790 = Coupling(name = 'GC_1790',
                   value = '-(delta*gwD6*ImCeW12*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1791 = Coupling(name = 'GC_1791',
                   value = 'delta*gwD6*ImCeW12*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1792 = Coupling(name = 'GC_1792',
                   value = '-(delta*gwD6*ImCeW12*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1793 = Coupling(name = 'GC_1793',
                   value = 'delta*gwD6*ImCeW12*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1794 = Coupling(name = 'GC_1794',
                   value = '(cwD6*delta*ImCeB13*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB13*vevT)/cmath.sqrt(2) - (delta*ImCeW13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1795 = Coupling(name = 'GC_1795',
                   value = '-((cwD6*delta*ImCeB13*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB13*vevT)/cmath.sqrt(2) + (delta*ImCeW13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1796 = Coupling(name = 'GC_1796',
                   value = '-(delta*gwD6*ImCeW13*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1797 = Coupling(name = 'GC_1797',
                   value = 'delta*gwD6*ImCeW13*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1798 = Coupling(name = 'GC_1798',
                   value = '-(delta*gwD6*ImCeW13*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1799 = Coupling(name = 'GC_1799',
                   value = 'delta*gwD6*ImCeW13*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1800 = Coupling(name = 'GC_1800',
                   value = '(cwD6*delta*ImCeB21*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB21*vevT)/cmath.sqrt(2) - (delta*ImCeW21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1801 = Coupling(name = 'GC_1801',
                   value = '-((cwD6*delta*ImCeB21*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB21*vevT)/cmath.sqrt(2) + (delta*ImCeW21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1802 = Coupling(name = 'GC_1802',
                   value = '-(delta*gwD6*ImCeW21*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1803 = Coupling(name = 'GC_1803',
                   value = 'delta*gwD6*ImCeW21*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1804 = Coupling(name = 'GC_1804',
                   value = '-(delta*gwD6*ImCeW21*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1805 = Coupling(name = 'GC_1805',
                   value = 'delta*gwD6*ImCeW21*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1806 = Coupling(name = 'GC_1806',
                   value = '(cwD6*delta*complex(0,1)*ReCeB22*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1807 = Coupling(name = 'GC_1807',
                   value = '-(delta*gwD6*ImCeW22*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1808 = Coupling(name = 'GC_1808',
                   value = 'delta*gwD6*ImCeW22*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1809 = Coupling(name = 'GC_1809',
                   value = '-(delta*gwD6*ImCeW22*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1810 = Coupling(name = 'GC_1810',
                   value = 'delta*gwD6*ImCeW22*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1811 = Coupling(name = 'GC_1811',
                   value = '(cwD6*delta*ImCeB23*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB23*vevT)/cmath.sqrt(2) - (delta*ImCeW23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1812 = Coupling(name = 'GC_1812',
                   value = '-((cwD6*delta*ImCeB23*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB23*vevT)/cmath.sqrt(2) + (delta*ImCeW23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1813 = Coupling(name = 'GC_1813',
                   value = '-(delta*gwD6*ImCeW23*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1814 = Coupling(name = 'GC_1814',
                   value = 'delta*gwD6*ImCeW23*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1815 = Coupling(name = 'GC_1815',
                   value = '-(delta*gwD6*ImCeW23*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1816 = Coupling(name = 'GC_1816',
                   value = 'delta*gwD6*ImCeW23*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1817 = Coupling(name = 'GC_1817',
                   value = '(cwD6*delta*ImCeB31*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB31*vevT)/cmath.sqrt(2) - (delta*ImCeW31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1818 = Coupling(name = 'GC_1818',
                   value = '-((cwD6*delta*ImCeB31*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB31*vevT)/cmath.sqrt(2) + (delta*ImCeW31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1819 = Coupling(name = 'GC_1819',
                   value = '-(delta*gwD6*ImCeW31*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1820 = Coupling(name = 'GC_1820',
                   value = 'delta*gwD6*ImCeW31*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1821 = Coupling(name = 'GC_1821',
                   value = '-(delta*gwD6*ImCeW31*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1822 = Coupling(name = 'GC_1822',
                   value = 'delta*gwD6*ImCeW31*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1823 = Coupling(name = 'GC_1823',
                   value = '(cwD6*delta*ImCeB32*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCeB32*vevT)/cmath.sqrt(2) - (delta*ImCeW32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1824 = Coupling(name = 'GC_1824',
                   value = '-((cwD6*delta*ImCeB32*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCeB32*vevT)/cmath.sqrt(2) + (delta*ImCeW32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1825 = Coupling(name = 'GC_1825',
                   value = '-(delta*gwD6*ImCeW32*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1826 = Coupling(name = 'GC_1826',
                   value = 'delta*gwD6*ImCeW32*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1827 = Coupling(name = 'GC_1827',
                   value = '-(delta*gwD6*ImCeW32*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1828 = Coupling(name = 'GC_1828',
                   value = 'delta*gwD6*ImCeW32*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1829 = Coupling(name = 'GC_1829',
                   value = '(cwD6*delta*complex(0,1)*ReCeB33*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCeW33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1830 = Coupling(name = 'GC_1830',
                   value = '-(delta*gwD6*ImCeW33*swD6*vevT) - delta*complex(0,1)*gwD6*ReCeW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1831 = Coupling(name = 'GC_1831',
                   value = 'delta*gwD6*ImCeW33*swD6*vevT - delta*complex(0,1)*gwD6*ReCeW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1832 = Coupling(name = 'GC_1832',
                   value = '-(delta*gwD6*ImCeW33*swD6*vevT) + delta*complex(0,1)*gwD6*ReCeW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1833 = Coupling(name = 'GC_1833',
                   value = 'delta*gwD6*ImCeW33*swD6*vevT + delta*complex(0,1)*gwD6*ReCeW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1834 = Coupling(name = 'GC_1834',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid11*vevT) - delta*complex(0,1)*g1D6*ReCPhid11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1835 = Coupling(name = 'GC_1835',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhid11*vevT - delta*complex(0,1)*gwD6*ReCPhid11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1836 = Coupling(name = 'GC_1836',
                   value = '-(cwD6*delta*gwD6*ImCPhid12*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCPhid12*vevT - delta*g1D6*ImCPhid12*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhid12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1837 = Coupling(name = 'GC_1837',
                   value = 'cwD6*delta*gwD6*ImCPhid12*vevT - cwD6*delta*complex(0,1)*gwD6*ReCPhid12*vevT + delta*g1D6*ImCPhid12*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhid12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1838 = Coupling(name = 'GC_1838',
                   value = 'cwD6*delta*g1D6*ImCPhid12*vevT + cwD6*delta*complex(0,1)*g1D6*ReCPhid12*vevT - delta*gwD6*ImCPhid12*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhid12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1839 = Coupling(name = 'GC_1839',
                   value = '-(cwD6*delta*g1D6*ImCPhid12*vevT) + cwD6*delta*complex(0,1)*g1D6*ReCPhid12*vevT + delta*gwD6*ImCPhid12*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhid12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1840 = Coupling(name = 'GC_1840',
                   value = '-(cwD6*delta*gwD6*ImCPhid13*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCPhid13*vevT - delta*g1D6*ImCPhid13*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhid13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1841 = Coupling(name = 'GC_1841',
                   value = 'cwD6*delta*gwD6*ImCPhid13*vevT - cwD6*delta*complex(0,1)*gwD6*ReCPhid13*vevT + delta*g1D6*ImCPhid13*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhid13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1842 = Coupling(name = 'GC_1842',
                   value = 'cwD6*delta*g1D6*ImCPhid13*vevT + cwD6*delta*complex(0,1)*g1D6*ReCPhid13*vevT - delta*gwD6*ImCPhid13*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhid13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1843 = Coupling(name = 'GC_1843',
                   value = '-(cwD6*delta*g1D6*ImCPhid13*vevT) + cwD6*delta*complex(0,1)*g1D6*ReCPhid13*vevT + delta*gwD6*ImCPhid13*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhid13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1844 = Coupling(name = 'GC_1844',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid22*vevT) - delta*complex(0,1)*g1D6*ReCPhid22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1845 = Coupling(name = 'GC_1845',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhid22*vevT - delta*complex(0,1)*gwD6*ReCPhid22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1846 = Coupling(name = 'GC_1846',
                   value = '-(cwD6*delta*gwD6*ImCPhid23*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCPhid23*vevT - delta*g1D6*ImCPhid23*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhid23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1847 = Coupling(name = 'GC_1847',
                   value = 'cwD6*delta*gwD6*ImCPhid23*vevT - cwD6*delta*complex(0,1)*gwD6*ReCPhid23*vevT + delta*g1D6*ImCPhid23*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhid23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1848 = Coupling(name = 'GC_1848',
                   value = 'cwD6*delta*g1D6*ImCPhid23*vevT + cwD6*delta*complex(0,1)*g1D6*ReCPhid23*vevT - delta*gwD6*ImCPhid23*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhid23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1849 = Coupling(name = 'GC_1849',
                   value = '-(cwD6*delta*g1D6*ImCPhid23*vevT) + cwD6*delta*complex(0,1)*g1D6*ReCPhid23*vevT + delta*gwD6*ImCPhid23*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhid23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1850 = Coupling(name = 'GC_1850',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid33*vevT) - delta*complex(0,1)*g1D6*ReCPhid33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1851 = Coupling(name = 'GC_1851',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhid33*vevT - delta*complex(0,1)*gwD6*ReCPhid33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1852 = Coupling(name = 'GC_1852',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie11*vevT) - delta*complex(0,1)*g1D6*ReCPhie11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1853 = Coupling(name = 'GC_1853',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhie11*vevT - delta*complex(0,1)*gwD6*ReCPhie11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1854 = Coupling(name = 'GC_1854',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie22*vevT) - delta*complex(0,1)*g1D6*ReCPhie22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1855 = Coupling(name = 'GC_1855',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhie22*vevT - delta*complex(0,1)*gwD6*ReCPhie22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1856 = Coupling(name = 'GC_1856',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie33*vevT) - delta*complex(0,1)*g1D6*ReCPhie33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1857 = Coupling(name = 'GC_1857',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhie33*vevT - delta*complex(0,1)*gwD6*ReCPhie33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1858 = Coupling(name = 'GC_1858',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu11*vevT) - delta*complex(0,1)*g1D6*ReCPhiu11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1859 = Coupling(name = 'GC_1859',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhiu11*vevT - delta*complex(0,1)*gwD6*ReCPhiu11*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1860 = Coupling(name = 'GC_1860',
                   value = '-(cwD6*delta*gwD6*ImCPhiu12*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCPhiu12*vevT - delta*g1D6*ImCPhiu12*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhiu12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1861 = Coupling(name = 'GC_1861',
                   value = 'cwD6*delta*gwD6*ImCPhiu12*vevT - cwD6*delta*complex(0,1)*gwD6*ReCPhiu12*vevT + delta*g1D6*ImCPhiu12*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhiu12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1862 = Coupling(name = 'GC_1862',
                   value = 'cwD6*delta*g1D6*ImCPhiu12*vevT + cwD6*delta*complex(0,1)*g1D6*ReCPhiu12*vevT - delta*gwD6*ImCPhiu12*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhiu12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1863 = Coupling(name = 'GC_1863',
                   value = '-(cwD6*delta*g1D6*ImCPhiu12*vevT) + cwD6*delta*complex(0,1)*g1D6*ReCPhiu12*vevT + delta*gwD6*ImCPhiu12*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhiu12*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1864 = Coupling(name = 'GC_1864',
                   value = '-(cwD6*delta*gwD6*ImCPhiu13*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCPhiu13*vevT - delta*g1D6*ImCPhiu13*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhiu13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1865 = Coupling(name = 'GC_1865',
                   value = 'cwD6*delta*gwD6*ImCPhiu13*vevT - cwD6*delta*complex(0,1)*gwD6*ReCPhiu13*vevT + delta*g1D6*ImCPhiu13*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhiu13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1866 = Coupling(name = 'GC_1866',
                   value = 'cwD6*delta*g1D6*ImCPhiu13*vevT + cwD6*delta*complex(0,1)*g1D6*ReCPhiu13*vevT - delta*gwD6*ImCPhiu13*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhiu13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1867 = Coupling(name = 'GC_1867',
                   value = '-(cwD6*delta*g1D6*ImCPhiu13*vevT) + cwD6*delta*complex(0,1)*g1D6*ReCPhiu13*vevT + delta*gwD6*ImCPhiu13*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhiu13*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1868 = Coupling(name = 'GC_1868',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu22*vevT) - delta*complex(0,1)*g1D6*ReCPhiu22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1869 = Coupling(name = 'GC_1869',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhiu22*vevT - delta*complex(0,1)*gwD6*ReCPhiu22*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1870 = Coupling(name = 'GC_1870',
                   value = '-(cwD6*delta*gwD6*ImCPhiu23*vevT) - cwD6*delta*complex(0,1)*gwD6*ReCPhiu23*vevT - delta*g1D6*ImCPhiu23*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhiu23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1871 = Coupling(name = 'GC_1871',
                   value = 'cwD6*delta*gwD6*ImCPhiu23*vevT - cwD6*delta*complex(0,1)*gwD6*ReCPhiu23*vevT + delta*g1D6*ImCPhiu23*swD6*vevT - delta*complex(0,1)*g1D6*ReCPhiu23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1872 = Coupling(name = 'GC_1872',
                   value = 'cwD6*delta*g1D6*ImCPhiu23*vevT + cwD6*delta*complex(0,1)*g1D6*ReCPhiu23*vevT - delta*gwD6*ImCPhiu23*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhiu23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1873 = Coupling(name = 'GC_1873',
                   value = '-(cwD6*delta*g1D6*ImCPhiu23*vevT) + cwD6*delta*complex(0,1)*g1D6*ReCPhiu23*vevT + delta*gwD6*ImCPhiu23*swD6*vevT - delta*complex(0,1)*gwD6*ReCPhiu23*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1874 = Coupling(name = 'GC_1874',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu33*vevT) - delta*complex(0,1)*g1D6*ReCPhiu33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1875 = Coupling(name = 'GC_1875',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReCPhiu33*vevT - delta*complex(0,1)*gwD6*ReCPhiu33*swD6*vevT',
                   order = {'NP':2,'QED':2})

GC_1876 = Coupling(name = 'GC_1876',
                   value = '(cwD6*delta*complex(0,1)*ReCuW11*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1877 = Coupling(name = 'GC_1877',
                   value = '(cwD6*delta*ImCuW12*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW12*vevT)/cmath.sqrt(2) - (delta*ImCuB12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1878 = Coupling(name = 'GC_1878',
                   value = '-((cwD6*delta*ImCuW12*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW12*vevT)/cmath.sqrt(2) + (delta*ImCuB12*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1879 = Coupling(name = 'GC_1879',
                   value = '(cwD6*delta*ImCuW13*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW13*vevT)/cmath.sqrt(2) - (delta*ImCuB13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1880 = Coupling(name = 'GC_1880',
                   value = '-((cwD6*delta*ImCuW13*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW13*vevT)/cmath.sqrt(2) + (delta*ImCuB13*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1881 = Coupling(name = 'GC_1881',
                   value = '(cwD6*delta*ImCuW21*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW21*vevT)/cmath.sqrt(2) - (delta*ImCuB21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1882 = Coupling(name = 'GC_1882',
                   value = '-((cwD6*delta*ImCuW21*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW21*vevT)/cmath.sqrt(2) + (delta*ImCuB21*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1883 = Coupling(name = 'GC_1883',
                   value = '(cwD6*delta*complex(0,1)*ReCuW22*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1884 = Coupling(name = 'GC_1884',
                   value = '(cwD6*delta*ImCuW23*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW23*vevT)/cmath.sqrt(2) - (delta*ImCuB23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1885 = Coupling(name = 'GC_1885',
                   value = '-((cwD6*delta*ImCuW23*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW23*vevT)/cmath.sqrt(2) + (delta*ImCuB23*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1886 = Coupling(name = 'GC_1886',
                   value = '(cwD6*delta*ImCuW31*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW31*vevT)/cmath.sqrt(2) - (delta*ImCuB31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1887 = Coupling(name = 'GC_1887',
                   value = '-((cwD6*delta*ImCuW31*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW31*vevT)/cmath.sqrt(2) + (delta*ImCuB31*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1888 = Coupling(name = 'GC_1888',
                   value = '(cwD6*delta*ImCuW32*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuW32*vevT)/cmath.sqrt(2) - (delta*ImCuB32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1889 = Coupling(name = 'GC_1889',
                   value = '-((cwD6*delta*ImCuW32*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuW32*vevT)/cmath.sqrt(2) + (delta*ImCuB32*swD6*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1890 = Coupling(name = 'GC_1890',
                   value = '(cwD6*delta*complex(0,1)*ReCuW33*vevT)/cmath.sqrt(2) - (delta*complex(0,1)*ReCuB33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1891 = Coupling(name = 'GC_1891',
                   value = '(cwD6*delta*complex(0,1)*ReCuB11*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW11*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1892 = Coupling(name = 'GC_1892',
                   value = '-(delta*gwD6*ImCuW11*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1893 = Coupling(name = 'GC_1893',
                   value = 'delta*gwD6*ImCuW11*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1894 = Coupling(name = 'GC_1894',
                   value = '-(delta*gwD6*ImCuW11*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1895 = Coupling(name = 'GC_1895',
                   value = 'delta*gwD6*ImCuW11*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW11*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1896 = Coupling(name = 'GC_1896',
                   value = '-((cwD6*delta*ImCuB12*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB12*vevT)/cmath.sqrt(2) - (delta*ImCuW12*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1897 = Coupling(name = 'GC_1897',
                   value = '(cwD6*delta*ImCuB12*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB12*vevT)/cmath.sqrt(2) + (delta*ImCuW12*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW12*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1898 = Coupling(name = 'GC_1898',
                   value = '-(delta*gwD6*ImCuW12*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1899 = Coupling(name = 'GC_1899',
                   value = 'delta*gwD6*ImCuW12*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1900 = Coupling(name = 'GC_1900',
                   value = '-(delta*gwD6*ImCuW12*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1901 = Coupling(name = 'GC_1901',
                   value = 'delta*gwD6*ImCuW12*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW12*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1902 = Coupling(name = 'GC_1902',
                   value = '-((cwD6*delta*ImCuB13*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB13*vevT)/cmath.sqrt(2) - (delta*ImCuW13*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1903 = Coupling(name = 'GC_1903',
                   value = '(cwD6*delta*ImCuB13*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB13*vevT)/cmath.sqrt(2) + (delta*ImCuW13*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW13*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1904 = Coupling(name = 'GC_1904',
                   value = '-(delta*gwD6*ImCuW13*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1905 = Coupling(name = 'GC_1905',
                   value = 'delta*gwD6*ImCuW13*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1906 = Coupling(name = 'GC_1906',
                   value = '-(delta*gwD6*ImCuW13*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1907 = Coupling(name = 'GC_1907',
                   value = 'delta*gwD6*ImCuW13*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW13*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1908 = Coupling(name = 'GC_1908',
                   value = '-((cwD6*delta*ImCuB21*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB21*vevT)/cmath.sqrt(2) - (delta*ImCuW21*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1909 = Coupling(name = 'GC_1909',
                   value = '(cwD6*delta*ImCuB21*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB21*vevT)/cmath.sqrt(2) + (delta*ImCuW21*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW21*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1910 = Coupling(name = 'GC_1910',
                   value = '-(delta*gwD6*ImCuW21*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1911 = Coupling(name = 'GC_1911',
                   value = 'delta*gwD6*ImCuW21*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1912 = Coupling(name = 'GC_1912',
                   value = '-(delta*gwD6*ImCuW21*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1913 = Coupling(name = 'GC_1913',
                   value = 'delta*gwD6*ImCuW21*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW21*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1914 = Coupling(name = 'GC_1914',
                   value = '(cwD6*delta*complex(0,1)*ReCuB22*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW22*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1915 = Coupling(name = 'GC_1915',
                   value = '-(delta*gwD6*ImCuW22*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1916 = Coupling(name = 'GC_1916',
                   value = 'delta*gwD6*ImCuW22*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1917 = Coupling(name = 'GC_1917',
                   value = '-(delta*gwD6*ImCuW22*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1918 = Coupling(name = 'GC_1918',
                   value = 'delta*gwD6*ImCuW22*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW22*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1919 = Coupling(name = 'GC_1919',
                   value = '-((cwD6*delta*ImCuB23*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB23*vevT)/cmath.sqrt(2) - (delta*ImCuW23*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1920 = Coupling(name = 'GC_1920',
                   value = '(cwD6*delta*ImCuB23*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB23*vevT)/cmath.sqrt(2) + (delta*ImCuW23*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW23*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1921 = Coupling(name = 'GC_1921',
                   value = '-(delta*gwD6*ImCuW23*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1922 = Coupling(name = 'GC_1922',
                   value = 'delta*gwD6*ImCuW23*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1923 = Coupling(name = 'GC_1923',
                   value = '-(delta*gwD6*ImCuW23*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1924 = Coupling(name = 'GC_1924',
                   value = 'delta*gwD6*ImCuW23*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW23*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1925 = Coupling(name = 'GC_1925',
                   value = '-((cwD6*delta*ImCuB31*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB31*vevT)/cmath.sqrt(2) - (delta*ImCuW31*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1926 = Coupling(name = 'GC_1926',
                   value = '(cwD6*delta*ImCuB31*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB31*vevT)/cmath.sqrt(2) + (delta*ImCuW31*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW31*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1927 = Coupling(name = 'GC_1927',
                   value = '-(delta*gwD6*ImCuW31*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1928 = Coupling(name = 'GC_1928',
                   value = 'delta*gwD6*ImCuW31*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1929 = Coupling(name = 'GC_1929',
                   value = '-(delta*gwD6*ImCuW31*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1930 = Coupling(name = 'GC_1930',
                   value = 'delta*gwD6*ImCuW31*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW31*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1931 = Coupling(name = 'GC_1931',
                   value = '-((cwD6*delta*ImCuB32*vevT)/cmath.sqrt(2)) + (cwD6*delta*complex(0,1)*ReCuB32*vevT)/cmath.sqrt(2) - (delta*ImCuW32*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1932 = Coupling(name = 'GC_1932',
                   value = '(cwD6*delta*ImCuB32*vevT)/cmath.sqrt(2) + (cwD6*delta*complex(0,1)*ReCuB32*vevT)/cmath.sqrt(2) + (delta*ImCuW32*swD6*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW32*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1933 = Coupling(name = 'GC_1933',
                   value = '-(delta*gwD6*ImCuW32*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1934 = Coupling(name = 'GC_1934',
                   value = 'delta*gwD6*ImCuW32*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1935 = Coupling(name = 'GC_1935',
                   value = '-(delta*gwD6*ImCuW32*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1936 = Coupling(name = 'GC_1936',
                   value = 'delta*gwD6*ImCuW32*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW32*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1937 = Coupling(name = 'GC_1937',
                   value = '(cwD6*delta*complex(0,1)*ReCuB33*vevT)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuW33*swD6*vevT)/cmath.sqrt(2)',
                   order = {'NP':2})

GC_1938 = Coupling(name = 'GC_1938',
                   value = '-(delta*gwD6*ImCuW33*swD6*vevT) - delta*complex(0,1)*gwD6*ReCuW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1939 = Coupling(name = 'GC_1939',
                   value = 'delta*gwD6*ImCuW33*swD6*vevT - delta*complex(0,1)*gwD6*ReCuW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1940 = Coupling(name = 'GC_1940',
                   value = '-(delta*gwD6*ImCuW33*swD6*vevT) + delta*complex(0,1)*gwD6*ReCuW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1941 = Coupling(name = 'GC_1941',
                   value = 'delta*gwD6*ImCuW33*swD6*vevT + delta*complex(0,1)*gwD6*ReCuW33*swD6*vevT',
                   order = {'NP':2,'QED':1})

GC_1942 = Coupling(name = 'GC_1942',
                   value = '4*CPhiW*cwD6**2*delta*complex(0,1)*vevT + 4*CPhiWB*cwD6*delta*complex(0,1)*swD6*vevT + 4*CPhiB*delta*complex(0,1)*swD6**2*vevT',
                   order = {'NP':2,'QED':1})

GC_1943 = Coupling(name = 'GC_1943',
                   value = '4*CPhiB*cwD6**2*delta*complex(0,1)*vevT - 4*CPhiWB*cwD6*delta*complex(0,1)*swD6*vevT + 4*CPhiW*delta*complex(0,1)*swD6**2*vevT',
                   order = {'NP':2,'QED':1})

GC_1944 = Coupling(name = 'GC_1944',
                   value = '-2*CPhiWB*cwD6**2*delta*complex(0,1)*vevT - 4*CPhiB*cwD6*delta*complex(0,1)*swD6*vevT + 4*CPhiW*cwD6*delta*complex(0,1)*swD6*vevT + 2*CPhiWB*delta*complex(0,1)*swD6**2*vevT',
                   order = {'NP':2,'QED':1})

GC_1945 = Coupling(name = 'GC_1945',
                   value = '(cwD6**2*complex(0,1)*gwD6**2*vevT)/2. + cwD6*complex(0,1)*g1D6*gwD6*swD6*vevT + (complex(0,1)*g1D6**2*swD6**2*vevT)/2.',
                   order = {'QED':1})

GC_1946 = Coupling(name = 'GC_1946',
                   value = '3*CPhiD*cwD6**2*delta*complex(0,1)*gwD6**2*vevT + 6*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT + 3*CPhiD*delta*complex(0,1)*g1D6**2*swD6**2*vevT',
                   order = {'NP':2,'QED':5})

GC_1947 = Coupling(name = 'GC_1947',
                   value = '-(cwD6**2*complex(0,1)*g1D6*gwD6*vevT)/2. - (cwD6*complex(0,1)*g1D6**2*swD6*vevT)/2. + (cwD6*complex(0,1)*gwD6**2*swD6*vevT)/2. + (complex(0,1)*g1D6*gwD6*swD6**2*vevT)/2.',
                   order = {'QED':1})

GC_1948 = Coupling(name = 'GC_1948',
                   value = '-3*CPhiD*cwD6**2*delta*complex(0,1)*g1D6*gwD6*vevT - 3*CPhiD*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT + 3*CPhiD*cwD6*delta*complex(0,1)*gwD6**2*swD6*vevT + 3*CPhiD*delta*complex(0,1)*g1D6*gwD6*swD6**2*vevT',
                   order = {'NP':2,'QED':5})

GC_1949 = Coupling(name = 'GC_1949',
                   value = '(cwD6**2*complex(0,1)*g1D6**2*vevT)/2. - cwD6*complex(0,1)*g1D6*gwD6*swD6*vevT + (complex(0,1)*gwD6**2*swD6**2*vevT)/2.',
                   order = {'QED':1})

GC_1950 = Coupling(name = 'GC_1950',
                   value = '3*CPhiD*cwD6**2*delta*complex(0,1)*g1D6**2*vevT - 6*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT + 3*CPhiD*delta*complex(0,1)*gwD6**2*swD6**2*vevT',
                   order = {'NP':2,'QED':5})

GC_1951 = Coupling(name = 'GC_1951',
                   value = '-(CPhiD*delta*complex(0,1)*gwD6**2*vevT**2)/4. + CPhiDAl*delta*complex(0,1)*gwD6**2*vevT**2',
                   order = {'NP':2,'QED':4})

GC_1952 = Coupling(name = 'GC_1952',
                   value = '45*CPhi*delta*complex(0,1)*vevT**2 + 6*CPhiD*delta*complex(0,1)*lam*vevT**2 - 24*CPhiDAl*delta*complex(0,1)*lam*vevT**2',
                   order = {'NP':2,'QED':4})

GC_1953 = Coupling(name = 'GC_1953',
                   value = '-((delta*gwD6*ImC3Phiq12*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReC3Phiq12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1954 = Coupling(name = 'GC_1954',
                   value = '(delta*gwD6*ImC3Phiq12*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReC3Phiq12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1955 = Coupling(name = 'GC_1955',
                   value = '-((delta*gwD6*ImC3Phiq13*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReC3Phiq13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1956 = Coupling(name = 'GC_1956',
                   value = '(delta*gwD6*ImC3Phiq13*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReC3Phiq13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1957 = Coupling(name = 'GC_1957',
                   value = '-((delta*gwD6*ImC3Phiq23*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReC3Phiq23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1958 = Coupling(name = 'GC_1958',
                   value = '(delta*gwD6*ImC3Phiq23*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*gwD6*ReC3Phiq23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1959 = Coupling(name = 'GC_1959',
                   value = '-((delta*ImCdPhi12*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdPhi12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1960 = Coupling(name = 'GC_1960',
                   value = '(delta*ImCdPhi12*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdPhi12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1961 = Coupling(name = 'GC_1961',
                   value = '-((delta*ImCdPhi13*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdPhi13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1962 = Coupling(name = 'GC_1962',
                   value = '(delta*ImCdPhi13*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdPhi13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1963 = Coupling(name = 'GC_1963',
                   value = '-((delta*ImCdPhi21*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdPhi21*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1964 = Coupling(name = 'GC_1964',
                   value = '(delta*ImCdPhi21*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdPhi21*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1965 = Coupling(name = 'GC_1965',
                   value = '-((delta*ImCdPhi23*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdPhi23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1966 = Coupling(name = 'GC_1966',
                   value = '(delta*ImCdPhi23*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdPhi23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1967 = Coupling(name = 'GC_1967',
                   value = '-((delta*ImCdPhi31*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdPhi31*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1968 = Coupling(name = 'GC_1968',
                   value = '(delta*ImCdPhi31*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdPhi31*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1969 = Coupling(name = 'GC_1969',
                   value = '-((delta*ImCdPhi32*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCdPhi32*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1970 = Coupling(name = 'GC_1970',
                   value = '(delta*ImCdPhi32*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCdPhi32*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1971 = Coupling(name = 'GC_1971',
                   value = '-((delta*ImCePhi12*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCePhi12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1972 = Coupling(name = 'GC_1972',
                   value = '(delta*ImCePhi12*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCePhi12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1973 = Coupling(name = 'GC_1973',
                   value = '-((delta*ImCePhi13*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCePhi13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1974 = Coupling(name = 'GC_1974',
                   value = '(delta*ImCePhi13*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCePhi13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1975 = Coupling(name = 'GC_1975',
                   value = '-((delta*ImCePhi21*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCePhi21*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1976 = Coupling(name = 'GC_1976',
                   value = '(delta*ImCePhi21*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCePhi21*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1977 = Coupling(name = 'GC_1977',
                   value = '-((delta*ImCePhi23*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCePhi23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1978 = Coupling(name = 'GC_1978',
                   value = '(delta*ImCePhi23*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCePhi23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1979 = Coupling(name = 'GC_1979',
                   value = '-((delta*ImCePhi31*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCePhi31*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1980 = Coupling(name = 'GC_1980',
                   value = '(delta*ImCePhi31*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCePhi31*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1981 = Coupling(name = 'GC_1981',
                   value = '-((delta*ImCePhi32*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCePhi32*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1982 = Coupling(name = 'GC_1982',
                   value = '(delta*ImCePhi32*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCePhi32*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_1983 = Coupling(name = 'GC_1983',
                   value = '-(delta*gwD6*ImCPhiud11*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud11*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1984 = Coupling(name = 'GC_1984',
                   value = '(delta*gwD6*ImCPhiud11*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud11*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1985 = Coupling(name = 'GC_1985',
                   value = '-(delta*gwD6*ImCPhiud12*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud12*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1986 = Coupling(name = 'GC_1986',
                   value = '(delta*gwD6*ImCPhiud12*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud12*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1987 = Coupling(name = 'GC_1987',
                   value = '-(delta*gwD6*ImCPhiud13*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud13*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1988 = Coupling(name = 'GC_1988',
                   value = '(delta*gwD6*ImCPhiud13*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud13*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1989 = Coupling(name = 'GC_1989',
                   value = '-(delta*gwD6*ImCPhiud21*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud21*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1990 = Coupling(name = 'GC_1990',
                   value = '(delta*gwD6*ImCPhiud21*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud21*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1991 = Coupling(name = 'GC_1991',
                   value = '-(delta*gwD6*ImCPhiud22*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud22*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1992 = Coupling(name = 'GC_1992',
                   value = '(delta*gwD6*ImCPhiud22*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud22*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1993 = Coupling(name = 'GC_1993',
                   value = '-(delta*gwD6*ImCPhiud23*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud23*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1994 = Coupling(name = 'GC_1994',
                   value = '(delta*gwD6*ImCPhiud23*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud23*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1995 = Coupling(name = 'GC_1995',
                   value = '-(delta*gwD6*ImCPhiud31*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud31*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1996 = Coupling(name = 'GC_1996',
                   value = '(delta*gwD6*ImCPhiud31*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud31*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1997 = Coupling(name = 'GC_1997',
                   value = '-(delta*gwD6*ImCPhiud32*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud32*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1998 = Coupling(name = 'GC_1998',
                   value = '(delta*gwD6*ImCPhiud32*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud32*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_1999 = Coupling(name = 'GC_1999',
                   value = '-(delta*gwD6*ImCPhiud33*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud33*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_2000 = Coupling(name = 'GC_2000',
                   value = '(delta*gwD6*ImCPhiud33*vevT**2)/(2.*cmath.sqrt(2)) + (delta*complex(0,1)*gwD6*ReCPhiud33*vevT**2)/(2.*cmath.sqrt(2))',
                   order = {'NP':2,'QED':1})

GC_2001 = Coupling(name = 'GC_2001',
                   value = '-((delta*ImCuPhi12*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuPhi12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2002 = Coupling(name = 'GC_2002',
                   value = '(delta*ImCuPhi12*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuPhi12*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2003 = Coupling(name = 'GC_2003',
                   value = '-((delta*ImCuPhi13*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuPhi13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2004 = Coupling(name = 'GC_2004',
                   value = '(delta*ImCuPhi13*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuPhi13*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2005 = Coupling(name = 'GC_2005',
                   value = '-((delta*ImCuPhi21*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuPhi21*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2006 = Coupling(name = 'GC_2006',
                   value = '(delta*ImCuPhi21*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuPhi21*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2007 = Coupling(name = 'GC_2007',
                   value = '-((delta*ImCuPhi23*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuPhi23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2008 = Coupling(name = 'GC_2008',
                   value = '(delta*ImCuPhi23*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuPhi23*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2009 = Coupling(name = 'GC_2009',
                   value = '-((delta*ImCuPhi31*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuPhi31*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2010 = Coupling(name = 'GC_2010',
                   value = '(delta*ImCuPhi31*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuPhi31*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2011 = Coupling(name = 'GC_2011',
                   value = '-((delta*ImCuPhi32*vevT**2)/cmath.sqrt(2)) + (delta*complex(0,1)*ReCuPhi32*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2012 = Coupling(name = 'GC_2012',
                   value = '(delta*ImCuPhi32*vevT**2)/cmath.sqrt(2) + (delta*complex(0,1)*ReCuPhi32*vevT**2)/cmath.sqrt(2)',
                   order = {'NP':2,'QED':1})

GC_2013 = Coupling(name = 'GC_2013',
                   value = 'CPhiWB*cwD6**2*delta*complex(0,1)*g1D6*gwD6*vevT**2 + CPhiWB*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**2',
                   order = {'NP':2,'QED':2})

GC_2014 = Coupling(name = 'GC_2014',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil33*vevT**2) - delta*complex(0,1)*g1D6*ReC1Phil33*swD6*vevT**2',
                   order = {'NP':2,'QED':1})

GC_2015 = Coupling(name = 'GC_2015',
                   value = 'cwD6*delta*complex(0,1)*g1D6*ReC1Phil33*vevT**2 - delta*complex(0,1)*gwD6*ReC1Phil33*swD6*vevT**2',
                   order = {'NP':2,'QED':1})

GC_2016 = Coupling(name = 'GC_2016',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil11*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phil11*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phil11*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phil11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2017 = Coupling(name = 'GC_2017',
                   value = '(CPhiWB*cwD6*delta*complex(0,1)*g1D6*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phil11*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phil11*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phil11*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phil11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2018 = Coupling(name = 'GC_2018',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phil11*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phil11*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phil11*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phil11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2019 = Coupling(name = 'GC_2019',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phil11*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phil11*vevT**2)/2. + (CPhiWB*delta*complex(0,1)*g1D6*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phil11*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phil11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2020 = Coupling(name = 'GC_2020',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phil22*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phil22*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phil22*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phil22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2021 = Coupling(name = 'GC_2021',
                   value = '(CPhiWB*cwD6*delta*complex(0,1)*g1D6*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phil22*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phil22*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phil22*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phil22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2022 = Coupling(name = 'GC_2022',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phil22*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phil22*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phil22*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phil22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2023 = Coupling(name = 'GC_2023',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phil22*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phil22*vevT**2)/2. + (CPhiWB*delta*complex(0,1)*g1D6*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phil22*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phil22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2024 = Coupling(name = 'GC_2024',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq11*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq11*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq11*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2025 = Coupling(name = 'GC_2025',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq11*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq11*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq11*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2026 = Coupling(name = 'GC_2026',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phiq11*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq11*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq11*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2027 = Coupling(name = 'GC_2027',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phiq11*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq11*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq11*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2028 = Coupling(name = 'GC_2028',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq12*vevT**2)/2. - (cwD6*delta*gwD6*ImC3Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT**2)/2. - (delta*g1D6*ImC1Phiq12*swD6*vevT**2)/2. - (delta*g1D6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2029 = Coupling(name = 'GC_2029',
                   value = '(cwD6*delta*gwD6*ImC1Phiq12*vevT**2)/2. + (cwD6*delta*gwD6*ImC3Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT**2)/2. + (delta*g1D6*ImC1Phiq12*swD6*vevT**2)/2. + (delta*g1D6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2030 = Coupling(name = 'GC_2030',
                   value = '(cwD6*delta*gwD6*ImC1Phiq12*vevT**2)/2. - (cwD6*delta*gwD6*ImC3Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT**2)/2. + (delta*g1D6*ImC1Phiq12*swD6*vevT**2)/2. - (delta*g1D6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2031 = Coupling(name = 'GC_2031',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq12*vevT**2)/2. + (cwD6*delta*gwD6*ImC3Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq12*vevT**2)/2. - (delta*g1D6*ImC1Phiq12*swD6*vevT**2)/2. + (delta*g1D6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq12*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2032 = Coupling(name = 'GC_2032',
                   value = '(cwD6*delta*g1D6*ImC1Phiq12*vevT**2)/2. + (cwD6*delta*g1D6*ImC3Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT**2)/2. - (delta*gwD6*ImC1Phiq12*swD6*vevT**2)/2. - (delta*gwD6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2033 = Coupling(name = 'GC_2033',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq12*vevT**2)/2. - (cwD6*delta*g1D6*ImC3Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT**2)/2. + (delta*gwD6*ImC1Phiq12*swD6*vevT**2)/2. + (delta*gwD6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2034 = Coupling(name = 'GC_2034',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq12*vevT**2)/2. + (cwD6*delta*g1D6*ImC3Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT**2)/2. + (delta*gwD6*ImC1Phiq12*swD6*vevT**2)/2. - (delta*gwD6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2035 = Coupling(name = 'GC_2035',
                   value = '(cwD6*delta*g1D6*ImC1Phiq12*vevT**2)/2. - (cwD6*delta*g1D6*ImC3Phiq12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq12*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq12*vevT**2)/2. - (delta*gwD6*ImC1Phiq12*swD6*vevT**2)/2. + (delta*gwD6*ImC3Phiq12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq12*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2036 = Coupling(name = 'GC_2036',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq13*vevT**2)/2. - (cwD6*delta*gwD6*ImC3Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT**2)/2. - (delta*g1D6*ImC1Phiq13*swD6*vevT**2)/2. - (delta*g1D6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2037 = Coupling(name = 'GC_2037',
                   value = '(cwD6*delta*gwD6*ImC1Phiq13*vevT**2)/2. + (cwD6*delta*gwD6*ImC3Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT**2)/2. + (delta*g1D6*ImC1Phiq13*swD6*vevT**2)/2. + (delta*g1D6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2038 = Coupling(name = 'GC_2038',
                   value = '(cwD6*delta*gwD6*ImC1Phiq13*vevT**2)/2. - (cwD6*delta*gwD6*ImC3Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT**2)/2. + (delta*g1D6*ImC1Phiq13*swD6*vevT**2)/2. - (delta*g1D6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2039 = Coupling(name = 'GC_2039',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq13*vevT**2)/2. + (cwD6*delta*gwD6*ImC3Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq13*vevT**2)/2. - (delta*g1D6*ImC1Phiq13*swD6*vevT**2)/2. + (delta*g1D6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq13*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2040 = Coupling(name = 'GC_2040',
                   value = '(cwD6*delta*g1D6*ImC1Phiq13*vevT**2)/2. + (cwD6*delta*g1D6*ImC3Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT**2)/2. - (delta*gwD6*ImC1Phiq13*swD6*vevT**2)/2. - (delta*gwD6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2041 = Coupling(name = 'GC_2041',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq13*vevT**2)/2. - (cwD6*delta*g1D6*ImC3Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT**2)/2. + (delta*gwD6*ImC1Phiq13*swD6*vevT**2)/2. + (delta*gwD6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2042 = Coupling(name = 'GC_2042',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq13*vevT**2)/2. + (cwD6*delta*g1D6*ImC3Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT**2)/2. + (delta*gwD6*ImC1Phiq13*swD6*vevT**2)/2. - (delta*gwD6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2043 = Coupling(name = 'GC_2043',
                   value = '(cwD6*delta*g1D6*ImC1Phiq13*vevT**2)/2. - (cwD6*delta*g1D6*ImC3Phiq13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq13*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq13*vevT**2)/2. - (delta*gwD6*ImC1Phiq13*swD6*vevT**2)/2. + (delta*gwD6*ImC3Phiq13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq13*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2044 = Coupling(name = 'GC_2044',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq22*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq22*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq22*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2045 = Coupling(name = 'GC_2045',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq22*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq22*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq22*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2046 = Coupling(name = 'GC_2046',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phiq22*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq22*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq22*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2047 = Coupling(name = 'GC_2047',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phiq22*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq22*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq22*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2048 = Coupling(name = 'GC_2048',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq23*vevT**2)/2. - (cwD6*delta*gwD6*ImC3Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT**2)/2. - (delta*g1D6*ImC1Phiq23*swD6*vevT**2)/2. - (delta*g1D6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2049 = Coupling(name = 'GC_2049',
                   value = '(cwD6*delta*gwD6*ImC1Phiq23*vevT**2)/2. + (cwD6*delta*gwD6*ImC3Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT**2)/2. + (delta*g1D6*ImC1Phiq23*swD6*vevT**2)/2. + (delta*g1D6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2050 = Coupling(name = 'GC_2050',
                   value = '(cwD6*delta*gwD6*ImC1Phiq23*vevT**2)/2. - (cwD6*delta*gwD6*ImC3Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT**2)/2. + (delta*g1D6*ImC1Phiq23*swD6*vevT**2)/2. - (delta*g1D6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2051 = Coupling(name = 'GC_2051',
                   value = '-(cwD6*delta*gwD6*ImC1Phiq23*vevT**2)/2. + (cwD6*delta*gwD6*ImC3Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC1Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq23*vevT**2)/2. - (delta*g1D6*ImC1Phiq23*swD6*vevT**2)/2. + (delta*g1D6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq23*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2052 = Coupling(name = 'GC_2052',
                   value = '(cwD6*delta*g1D6*ImC1Phiq23*vevT**2)/2. + (cwD6*delta*g1D6*ImC3Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT**2)/2. - (delta*gwD6*ImC1Phiq23*swD6*vevT**2)/2. - (delta*gwD6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2053 = Coupling(name = 'GC_2053',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq23*vevT**2)/2. - (cwD6*delta*g1D6*ImC3Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT**2)/2. + (delta*gwD6*ImC1Phiq23*swD6*vevT**2)/2. + (delta*gwD6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2054 = Coupling(name = 'GC_2054',
                   value = '-(cwD6*delta*g1D6*ImC1Phiq23*vevT**2)/2. + (cwD6*delta*g1D6*ImC3Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT**2)/2. + (delta*gwD6*ImC1Phiq23*swD6*vevT**2)/2. - (delta*gwD6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2055 = Coupling(name = 'GC_2055',
                   value = '(cwD6*delta*g1D6*ImC1Phiq23*vevT**2)/2. - (cwD6*delta*g1D6*ImC3Phiq23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC1Phiq23*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq23*vevT**2)/2. - (delta*gwD6*ImC1Phiq23*swD6*vevT**2)/2. + (delta*gwD6*ImC3Phiq23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq23*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2056 = Coupling(name = 'GC_2056',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq33*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq33*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq33*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC3Phiq33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2057 = Coupling(name = 'GC_2057',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReC1Phiq33*vevT**2)/2. + (cwD6*delta*complex(0,1)*gwD6*ReC3Phiq33*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReC1Phiq33*swD6*vevT**2)/2. + (delta*complex(0,1)*g1D6*ReC3Phiq33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2058 = Coupling(name = 'GC_2058',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phiq33*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq33*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq33*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC3Phiq33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2059 = Coupling(name = 'GC_2059',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReC1Phiq33*vevT**2)/2. - (cwD6*delta*complex(0,1)*g1D6*ReC3Phiq33*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReC1Phiq33*swD6*vevT**2)/2. + (delta*complex(0,1)*gwD6*ReC3Phiq33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2060 = Coupling(name = 'GC_2060',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid11*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2061 = Coupling(name = 'GC_2061',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhid11*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2062 = Coupling(name = 'GC_2062',
                   value = '-(cwD6*delta*gwD6*ImCPhid12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhid12*vevT**2)/2. - (delta*g1D6*ImCPhid12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2063 = Coupling(name = 'GC_2063',
                   value = '(cwD6*delta*gwD6*ImCPhid12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhid12*vevT**2)/2. + (delta*g1D6*ImCPhid12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2064 = Coupling(name = 'GC_2064',
                   value = '(cwD6*delta*g1D6*ImCPhid12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhid12*vevT**2)/2. - (delta*gwD6*ImCPhid12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2065 = Coupling(name = 'GC_2065',
                   value = '-(cwD6*delta*g1D6*ImCPhid12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhid12*vevT**2)/2. + (delta*gwD6*ImCPhid12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2066 = Coupling(name = 'GC_2066',
                   value = '-(cwD6*delta*gwD6*ImCPhid13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhid13*vevT**2)/2. - (delta*g1D6*ImCPhid13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2067 = Coupling(name = 'GC_2067',
                   value = '(cwD6*delta*gwD6*ImCPhid13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhid13*vevT**2)/2. + (delta*g1D6*ImCPhid13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2068 = Coupling(name = 'GC_2068',
                   value = '(cwD6*delta*g1D6*ImCPhid13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhid13*vevT**2)/2. - (delta*gwD6*ImCPhid13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2069 = Coupling(name = 'GC_2069',
                   value = '-(cwD6*delta*g1D6*ImCPhid13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhid13*vevT**2)/2. + (delta*gwD6*ImCPhid13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2070 = Coupling(name = 'GC_2070',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid22*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2071 = Coupling(name = 'GC_2071',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhid22*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2072 = Coupling(name = 'GC_2072',
                   value = '-(cwD6*delta*gwD6*ImCPhid23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhid23*vevT**2)/2. - (delta*g1D6*ImCPhid23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2073 = Coupling(name = 'GC_2073',
                   value = '(cwD6*delta*gwD6*ImCPhid23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhid23*vevT**2)/2. + (delta*g1D6*ImCPhid23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2074 = Coupling(name = 'GC_2074',
                   value = '(cwD6*delta*g1D6*ImCPhid23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhid23*vevT**2)/2. - (delta*gwD6*ImCPhid23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2075 = Coupling(name = 'GC_2075',
                   value = '-(cwD6*delta*g1D6*ImCPhid23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhid23*vevT**2)/2. + (delta*gwD6*ImCPhid23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2076 = Coupling(name = 'GC_2076',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhid33*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhid33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2077 = Coupling(name = 'GC_2077',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhid33*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhid33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2078 = Coupling(name = 'GC_2078',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie11*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhie11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2079 = Coupling(name = 'GC_2079',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhie11*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhie11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2080 = Coupling(name = 'GC_2080',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie22*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhie22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2081 = Coupling(name = 'GC_2081',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhie22*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhie22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2082 = Coupling(name = 'GC_2082',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhie33*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhie33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2083 = Coupling(name = 'GC_2083',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhie33*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhie33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2084 = Coupling(name = 'GC_2084',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu11*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2085 = Coupling(name = 'GC_2085',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhiu11*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu11*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2086 = Coupling(name = 'GC_2086',
                   value = '-(cwD6*delta*gwD6*ImCPhiu12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhiu12*vevT**2)/2. - (delta*g1D6*ImCPhiu12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2087 = Coupling(name = 'GC_2087',
                   value = '(cwD6*delta*gwD6*ImCPhiu12*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhiu12*vevT**2)/2. + (delta*g1D6*ImCPhiu12*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2088 = Coupling(name = 'GC_2088',
                   value = '(cwD6*delta*g1D6*ImCPhiu12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhiu12*vevT**2)/2. - (delta*gwD6*ImCPhiu12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2089 = Coupling(name = 'GC_2089',
                   value = '-(cwD6*delta*g1D6*ImCPhiu12*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhiu12*vevT**2)/2. + (delta*gwD6*ImCPhiu12*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu12*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2090 = Coupling(name = 'GC_2090',
                   value = '-(cwD6*delta*gwD6*ImCPhiu13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhiu13*vevT**2)/2. - (delta*g1D6*ImCPhiu13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2091 = Coupling(name = 'GC_2091',
                   value = '(cwD6*delta*gwD6*ImCPhiu13*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhiu13*vevT**2)/2. + (delta*g1D6*ImCPhiu13*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2092 = Coupling(name = 'GC_2092',
                   value = '(cwD6*delta*g1D6*ImCPhiu13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhiu13*vevT**2)/2. - (delta*gwD6*ImCPhiu13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2093 = Coupling(name = 'GC_2093',
                   value = '-(cwD6*delta*g1D6*ImCPhiu13*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhiu13*vevT**2)/2. + (delta*gwD6*ImCPhiu13*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu13*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2094 = Coupling(name = 'GC_2094',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu22*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2095 = Coupling(name = 'GC_2095',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhiu22*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu22*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2096 = Coupling(name = 'GC_2096',
                   value = '-(cwD6*delta*gwD6*ImCPhiu23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhiu23*vevT**2)/2. - (delta*g1D6*ImCPhiu23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2097 = Coupling(name = 'GC_2097',
                   value = '(cwD6*delta*gwD6*ImCPhiu23*vevT**2)/2. - (cwD6*delta*complex(0,1)*gwD6*ReCPhiu23*vevT**2)/2. + (delta*g1D6*ImCPhiu23*swD6*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2098 = Coupling(name = 'GC_2098',
                   value = '(cwD6*delta*g1D6*ImCPhiu23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhiu23*vevT**2)/2. - (delta*gwD6*ImCPhiu23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2099 = Coupling(name = 'GC_2099',
                   value = '-(cwD6*delta*g1D6*ImCPhiu23*vevT**2)/2. + (cwD6*delta*complex(0,1)*g1D6*ReCPhiu23*vevT**2)/2. + (delta*gwD6*ImCPhiu23*swD6*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu23*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2100 = Coupling(name = 'GC_2100',
                   value = '-(cwD6*delta*complex(0,1)*gwD6*ReCPhiu33*vevT**2)/2. - (delta*complex(0,1)*g1D6*ReCPhiu33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2101 = Coupling(name = 'GC_2101',
                   value = '(cwD6*delta*complex(0,1)*g1D6*ReCPhiu33*vevT**2)/2. - (delta*complex(0,1)*gwD6*ReCPhiu33*swD6*vevT**2)/2.',
                   order = {'NP':2,'QED':1})

GC_2102 = Coupling(name = 'GC_2102',
                   value = '(5*CPhiD*cwD6**2*delta*complex(0,1)*gwD6**2*vevT**2)/4. + CPhiDAl*cwD6**2*delta*complex(0,1)*gwD6**2*vevT**2 + (5*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**2)/2. + 2*CPhiDAl*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**2 + (5*CPhiD*delta*complex(0,1)*g1D6**2*swD6**2*vevT**2)/4. + CPhiDAl*delta*complex(0,1)*g1D6**2*swD6**2*vevT**2',
                   order = {'NP':2,'QED':4})

GC_2103 = Coupling(name = 'GC_2103',
                   value = '-(CPhiWB*cwD6**2*delta*complex(0,1)*g1D6**2*vevT**2)/2. + CPhiWB*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**2 + (CPhiWB*delta*complex(0,1)*g1D6**2*swD6**2*vevT**2)/2.',
                   order = {'NP':2,'QED':2})

GC_2104 = Coupling(name = 'GC_2104',
                   value = '(-5*CPhiD*cwD6**2*delta*complex(0,1)*g1D6*gwD6*vevT**2)/4. - CPhiDAl*cwD6**2*delta*complex(0,1)*g1D6*gwD6*vevT**2 - (5*CPhiD*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**2)/4. - CPhiDAl*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**2 + (5*CPhiD*cwD6*delta*complex(0,1)*gwD6**2*swD6*vevT**2)/4. + CPhiDAl*cwD6*delta*complex(0,1)*gwD6**2*swD6*vevT**2 + (5*CPhiD*delta*complex(0,1)*g1D6*gwD6*swD6**2*vevT**2)/4. + CPhiDAl*delta*complex(0,1)*g1D6*gwD6*swD6**2*vevT**2',
                   order = {'NP':2,'QED':4})

GC_2105 = Coupling(name = 'GC_2105',
                   value = '-(CPhiWB*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**2) + CPhiWB*delta*complex(0,1)*g1D6*gwD6*swD6**2*vevT**2',
                   order = {'NP':2,'QED':2})

GC_2106 = Coupling(name = 'GC_2106',
                   value = '(5*CPhiD*cwD6**2*delta*complex(0,1)*g1D6**2*vevT**2)/4. + CPhiDAl*cwD6**2*delta*complex(0,1)*g1D6**2*vevT**2 - (5*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**2)/2. - 2*CPhiDAl*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**2 + (5*CPhiD*delta*complex(0,1)*gwD6**2*swD6**2*vevT**2)/4. + CPhiDAl*delta*complex(0,1)*gwD6**2*swD6**2*vevT**2',
                   order = {'NP':2,'QED':4})

GC_2107 = Coupling(name = 'GC_2107',
                   value = '-(CPhiD*delta*complex(0,1)*gwD6**2*vevT**3)/8. + (CPhiDAl*delta*complex(0,1)*gwD6**2*vevT**3)/2.',
                   order = {'NP':2,'QED':3})

GC_2108 = Coupling(name = 'GC_2108',
                   value = '15*CPhi*delta*complex(0,1)*vevT**3 + (9*CPhiD*delta*complex(0,1)*lam*vevT**3)/2. - 18*CPhiDAl*delta*complex(0,1)*lam*vevT**3',
                   order = {'NP':2,'QED':3})

GC_2109 = Coupling(name = 'GC_2109',
                   value = 'CPhiWB*cwD6**2*delta*complex(0,1)*g1D6*gwD6*vevT**3 + CPhiWB*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**3',
                   order = {'NP':2,'QED':1})

GC_2110 = Coupling(name = 'GC_2110',
                   value = '(3*CPhiD*cwD6**2*delta*complex(0,1)*gwD6**2*vevT**3)/8. + (CPhiDAl*cwD6**2*delta*complex(0,1)*gwD6**2*vevT**3)/2. + (3*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**3)/4. + CPhiDAl*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**3 + (3*CPhiD*delta*complex(0,1)*g1D6**2*swD6**2*vevT**3)/8. + (CPhiDAl*delta*complex(0,1)*g1D6**2*swD6**2*vevT**3)/2.',
                   order = {'NP':2,'QED':3})

GC_2111 = Coupling(name = 'GC_2111',
                   value = '-(CPhiWB*cwD6**2*delta*complex(0,1)*g1D6**2*vevT**3)/2. + CPhiWB*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**3 + (CPhiWB*delta*complex(0,1)*g1D6**2*swD6**2*vevT**3)/2.',
                   order = {'NP':2,'QED':1})

GC_2112 = Coupling(name = 'GC_2112',
                   value = '(-3*CPhiD*cwD6**2*delta*complex(0,1)*g1D6*gwD6*vevT**3)/8. - (CPhiDAl*cwD6**2*delta*complex(0,1)*g1D6*gwD6*vevT**3)/2. - (3*CPhiD*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**3)/8. - (CPhiDAl*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**3)/2. + (3*CPhiD*cwD6*delta*complex(0,1)*gwD6**2*swD6*vevT**3)/8. + (CPhiDAl*cwD6*delta*complex(0,1)*gwD6**2*swD6*vevT**3)/2. + (3*CPhiD*delta*complex(0,1)*g1D6*gwD6*swD6**2*vevT**3)/8. + (CPhiDAl*delta*complex(0,1)*g1D6*gwD6*swD6**2*vevT**3)/2.',
                   order = {'NP':2,'QED':3})

GC_2113 = Coupling(name = 'GC_2113',
                   value = '-(CPhiWB*cwD6*delta*complex(0,1)*g1D6**2*swD6*vevT**3) + CPhiWB*delta*complex(0,1)*g1D6*gwD6*swD6**2*vevT**3',
                   order = {'NP':2,'QED':1})

GC_2114 = Coupling(name = 'GC_2114',
                   value = '(3*CPhiD*cwD6**2*delta*complex(0,1)*g1D6**2*vevT**3)/8. + (CPhiDAl*cwD6**2*delta*complex(0,1)*g1D6**2*vevT**3)/2. - (3*CPhiD*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**3)/4. - CPhiDAl*cwD6*delta*complex(0,1)*g1D6*gwD6*swD6*vevT**3 + (3*CPhiD*delta*complex(0,1)*gwD6**2*swD6**2*vevT**3)/8. + (CPhiDAl*delta*complex(0,1)*gwD6**2*swD6**2*vevT**3)/2.',
                   order = {'NP':2,'QED':3})

GC_2115 = Coupling(name = 'GC_2115',
                   value = '-((complex(0,1)*ybD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2116 = Coupling(name = 'GC_2116',
                   value = '-((complex(0,1)*ycD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2117 = Coupling(name = 'GC_2117',
                   value = '-((complex(0,1)*ydoD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2118 = Coupling(name = 'GC_2118',
                   value = '-((complex(0,1)*yeD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2119 = Coupling(name = 'GC_2119',
                   value = '-((complex(0,1)*ymD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2120 = Coupling(name = 'GC_2120',
                   value = '-((complex(0,1)*ysD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2121 = Coupling(name = 'GC_2121',
                   value = '-((complex(0,1)*ytauD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2122 = Coupling(name = 'GC_2122',
                   value = '-((complex(0,1)*ytD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2123 = Coupling(name = 'GC_2123',
                   value = '-((complex(0,1)*yupD6)/cmath.sqrt(2))',
                   order = {'QED':1})

GC_2124 = Coupling(name = 'GC_2124',
                   value = '-(delta*complex(0,1)*complexconjugate(C1lequ))',
                   order = {'NP':2})

GC_2125 = Coupling(name = 'GC_2125',
                   value = 'delta*complex(0,1)*complexconjugate(C1lequ)',
                   order = {'NP':2})

GC_2126 = Coupling(name = 'GC_2126',
                   value = '-(delta*complex(0,1)*complexconjugate(C3lequ))',
                   order = {'NP':2})

GC_2127 = Coupling(name = 'GC_2127',
                   value = 'delta*complex(0,1)*complexconjugate(C3lequ)',
                   order = {'NP':2})

GC_2128 = Coupling(name = 'GC_2128',
                   value = '-2*delta*complex(0,1)*complexconjugate(C3lequ)',
                   order = {'NP':2})

GC_2129 = Coupling(name = 'GC_2129',
                   value = '2*delta*complex(0,1)*complexconjugate(C3lequ)',
                   order = {'NP':2})

GC_2130 = Coupling(name = 'GC_2130',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD61x1))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2131 = Coupling(name = 'GC_2131',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD61x2))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2132 = Coupling(name = 'GC_2132',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD61x3))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2133 = Coupling(name = 'GC_2133',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD62x1))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2134 = Coupling(name = 'GC_2134',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD62x2))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2135 = Coupling(name = 'GC_2135',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD62x3))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2136 = Coupling(name = 'GC_2136',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD63x1))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2137 = Coupling(name = 'GC_2137',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD63x2))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2138 = Coupling(name = 'GC_2138',
                   value = '(complex(0,1)*gwD6*complexconjugate(CKMD63x3))/cmath.sqrt(2)',
                   order = {'QED':1})

GC_2139 = Coupling(name = 'GC_2139',
                   value = 'delta*complex(0,1)*complexconjugate(Cledq)',
                   order = {'NP':2})

