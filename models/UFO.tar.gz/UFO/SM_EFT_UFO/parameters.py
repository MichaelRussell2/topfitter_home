# This file was automatically created by FeynRules 2.3.3
# Mathematica version: 9.0 for Linux x86 (64-bit) (February 7, 2013)
# Date: Tue 6 Oct 2015 05:32:49



from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# User-defined parameters.
cabi = Parameter(name = 'cabi',
                 nature = 'external',
                 type = 'real',
                 value = 0.227736,
                 texname = '\\theta _c',
                 lhablock = 'CKMBLOCK',
                 lhacode = [ 1 ])

delta = Parameter(name = 'delta',
                  nature = 'external',
                  type = 'real',
                  value = 1,
                  texname = '\\delta',
                  lhablock = 'D6',
                  lhacode = [ 1 ])

CG = Parameter(name = 'CG',
               nature = 'external',
               type = 'real',
               value = 0,
               texname = 'C_G',
               lhablock = 'D6',
               lhacode = [ 2 ])

CW = Parameter(name = 'CW',
               nature = 'external',
               type = 'real',
               value = 0,
               texname = 'C_W',
               lhablock = 'D6',
               lhacode = [ 3 ])

CGdual = Parameter(name = 'CGdual',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = 'C_{\\tilde{G}}',
                   lhablock = 'D6',
                   lhacode = [ 4 ])

CWdual = Parameter(name = 'CWdual',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = 'C_{\\tilde{W}}',
                   lhablock = 'D6',
                   lhacode = [ 5 ])

CPhiG = Parameter(name = 'CPhiG',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C_{\\text{$\\phi $G}}',
                  lhablock = 'D6',
                  lhacode = [ 6 ])

CPhiW = Parameter(name = 'CPhiW',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C_{\\text{$\\phi $W}}',
                  lhablock = 'D6',
                  lhacode = [ 7 ])

CPhiB = Parameter(name = 'CPhiB',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C_{\\text{$\\phi $B}}',
                  lhablock = 'D6',
                  lhacode = [ 8 ])

CPhiWB = Parameter(name = 'CPhiWB',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = 'C_{\\text{$\\phi $WB}}',
                   lhablock = 'D6',
                   lhacode = [ 9 ])

CPhiGdual = Parameter(name = 'CPhiGdual',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C_{\\text{$\\phi $OverTilde}(G)}',
                      lhablock = 'D6',
                      lhacode = [ 10 ])

CPhiWdual = Parameter(name = 'CPhiWdual',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C_{\\text{$\\phi $OverTilde}(W)}',
                      lhablock = 'D6',
                      lhacode = [ 11 ])

CPhiBdual = Parameter(name = 'CPhiBdual',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = 'C_{\\text{$\\phi $OverTilde}(B)}',
                      lhablock = 'D6',
                      lhacode = [ 12 ])

CPhiWdualB = Parameter(name = 'CPhiWdualB',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = 'C_{B \\text{$\\phi $OverTilde}(W)}',
                       lhablock = 'D6',
                       lhacode = [ 13 ])

CPhi = Parameter(name = 'CPhi',
                 nature = 'external',
                 type = 'real',
                 value = 1,
                 texname = 'C_{\\phi }',
                 lhablock = 'D6',
                 lhacode = [ 14 ])

CPhiDAl = Parameter(name = 'CPhiDAl',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{$\\phi $Superscript}(\\delta ,2)}',
                    lhablock = 'D6',
                    lhacode = [ 15 ])

CPhiD = Parameter(name = 'CPhiD',
                  nature = 'external',
                  type = 'real',
                  value = 0,
                  texname = 'C_{\\text{$\\phi $D}}',
                  lhablock = 'D6',
                  lhacode = [ 16 ])

ReCeW11 = Parameter(name = 'ReCeW11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW11}}',
                    lhablock = 'D6',
                    lhacode = [ 17 ])

ImCeW11 = Parameter(name = 'ImCeW11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW11}}',
                    lhablock = 'D6',
                    lhacode = [ 18 ])

ReCeW22 = Parameter(name = 'ReCeW22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW22}}',
                    lhablock = 'D6',
                    lhacode = [ 19 ])

ImCeW22 = Parameter(name = 'ImCeW22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW22}}',
                    lhablock = 'D6',
                    lhacode = [ 20 ])

ReCeW33 = Parameter(name = 'ReCeW33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW33}}',
                    lhablock = 'D6',
                    lhacode = [ 21 ])

ImCeW33 = Parameter(name = 'ImCeW33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW33}}',
                    lhablock = 'D6',
                    lhacode = [ 22 ])

ReCeW12 = Parameter(name = 'ReCeW12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW12}}',
                    lhablock = 'D6',
                    lhacode = [ 23 ])

ImCeW12 = Parameter(name = 'ImCeW12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW12}}',
                    lhablock = 'D6',
                    lhacode = [ 24 ])

ReCeW21 = Parameter(name = 'ReCeW21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW21}}',
                    lhablock = 'D6',
                    lhacode = [ 25 ])

ImCeW21 = Parameter(name = 'ImCeW21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW21}}',
                    lhablock = 'D6',
                    lhacode = [ 26 ])

ReCeW13 = Parameter(name = 'ReCeW13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW13}}',
                    lhablock = 'D6',
                    lhacode = [ 27 ])

ImCeW13 = Parameter(name = 'ImCeW13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW13}}',
                    lhablock = 'D6',
                    lhacode = [ 28 ])

ReCeW31 = Parameter(name = 'ReCeW31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW31}}',
                    lhablock = 'D6',
                    lhacode = [ 29 ])

ImCeW31 = Parameter(name = 'ImCeW31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW31}}',
                    lhablock = 'D6',
                    lhacode = [ 30 ])

ReCeW23 = Parameter(name = 'ReCeW23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW23}}',
                    lhablock = 'D6',
                    lhacode = [ 31 ])

ImCeW23 = Parameter(name = 'ImCeW23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW23}}',
                    lhablock = 'D6',
                    lhacode = [ 32 ])

ReCeW32 = Parameter(name = 'ReCeW32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eW32}}',
                    lhablock = 'D6',
                    lhacode = [ 33 ])

ImCeW32 = Parameter(name = 'ImCeW32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eW32}}',
                    lhablock = 'D6',
                    lhacode = [ 34 ])

ReCeB11 = Parameter(name = 'ReCeB11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB11}}',
                    lhablock = 'D6',
                    lhacode = [ 35 ])

ImCeB11 = Parameter(name = 'ImCeB11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB11}}',
                    lhablock = 'D6',
                    lhacode = [ 36 ])

ReCeB22 = Parameter(name = 'ReCeB22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB22}}',
                    lhablock = 'D6',
                    lhacode = [ 37 ])

ImCeB22 = Parameter(name = 'ImCeB22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB22}}',
                    lhablock = 'D6',
                    lhacode = [ 38 ])

ReCeB33 = Parameter(name = 'ReCeB33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB33}}',
                    lhablock = 'D6',
                    lhacode = [ 39 ])

ImCeB33 = Parameter(name = 'ImCeB33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB33}}',
                    lhablock = 'D6',
                    lhacode = [ 40 ])

ReCeB12 = Parameter(name = 'ReCeB12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB12}}',
                    lhablock = 'D6',
                    lhacode = [ 41 ])

ImCeB12 = Parameter(name = 'ImCeB12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB12}}',
                    lhablock = 'D6',
                    lhacode = [ 42 ])

ReCeB21 = Parameter(name = 'ReCeB21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB21}}',
                    lhablock = 'D6',
                    lhacode = [ 43 ])

ImCeB21 = Parameter(name = 'ImCeB21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB21}}',
                    lhablock = 'D6',
                    lhacode = [ 44 ])

ReCeB13 = Parameter(name = 'ReCeB13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB13}}',
                    lhablock = 'D6',
                    lhacode = [ 45 ])

ImCeB13 = Parameter(name = 'ImCeB13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB13}}',
                    lhablock = 'D6',
                    lhacode = [ 46 ])

ReCeB31 = Parameter(name = 'ReCeB31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB31}}',
                    lhablock = 'D6',
                    lhacode = [ 47 ])

ImCeB31 = Parameter(name = 'ImCeB31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB31}}',
                    lhablock = 'D6',
                    lhacode = [ 48 ])

ReCeB23 = Parameter(name = 'ReCeB23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB23}}',
                    lhablock = 'D6',
                    lhacode = [ 49 ])

ImCeB23 = Parameter(name = 'ImCeB23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB23}}',
                    lhablock = 'D6',
                    lhacode = [ 50 ])

ReCeB32 = Parameter(name = 'ReCeB32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{eB32}}',
                    lhablock = 'D6',
                    lhacode = [ 51 ])

ImCeB32 = Parameter(name = 'ImCeB32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{eB32}}',
                    lhablock = 'D6',
                    lhacode = [ 52 ])

ReCuG11 = Parameter(name = 'ReCuG11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG11}}',
                    lhablock = 'D6',
                    lhacode = [ 53 ])

ImCuG11 = Parameter(name = 'ImCuG11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG11}}',
                    lhablock = 'D6',
                    lhacode = [ 54 ])

ReCuG22 = Parameter(name = 'ReCuG22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG22}}',
                    lhablock = 'D6',
                    lhacode = [ 55 ])

ImCuG22 = Parameter(name = 'ImCuG22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG22}}',
                    lhablock = 'D6',
                    lhacode = [ 56 ])

ReCuG33 = Parameter(name = 'ReCuG33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG33}}',
                    lhablock = 'D6',
                    lhacode = [ 57 ])

ImCuG33 = Parameter(name = 'ImCuG33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG33}}',
                    lhablock = 'D6',
                    lhacode = [ 58 ])

ReCuG12 = Parameter(name = 'ReCuG12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG12}}',
                    lhablock = 'D6',
                    lhacode = [ 59 ])

ImCuG12 = Parameter(name = 'ImCuG12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG12}}',
                    lhablock = 'D6',
                    lhacode = [ 60 ])

ReCuG21 = Parameter(name = 'ReCuG21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG21}}',
                    lhablock = 'D6',
                    lhacode = [ 61 ])

ImCuG21 = Parameter(name = 'ImCuG21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG21}}',
                    lhablock = 'D6',
                    lhacode = [ 62 ])

ReCuG13 = Parameter(name = 'ReCuG13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG13}}',
                    lhablock = 'D6',
                    lhacode = [ 63 ])

ImCuG13 = Parameter(name = 'ImCuG13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG13}}',
                    lhablock = 'D6',
                    lhacode = [ 64 ])

ReCuG31 = Parameter(name = 'ReCuG31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG31}}',
                    lhablock = 'D6',
                    lhacode = [ 65 ])

ImCuG31 = Parameter(name = 'ImCuG31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG31}}',
                    lhablock = 'D6',
                    lhacode = [ 66 ])

ReCuG23 = Parameter(name = 'ReCuG23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG23}}',
                    lhablock = 'D6',
                    lhacode = [ 67 ])

ImCuG23 = Parameter(name = 'ImCuG23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG23}}',
                    lhablock = 'D6',
                    lhacode = [ 68 ])

ReCuG32 = Parameter(name = 'ReCuG32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uG32}}',
                    lhablock = 'D6',
                    lhacode = [ 69 ])

ImCuG32 = Parameter(name = 'ImCuG32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uG32}}',
                    lhablock = 'D6',
                    lhacode = [ 70 ])

ReCuW11 = Parameter(name = 'ReCuW11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW11}}',
                    lhablock = 'D6',
                    lhacode = [ 71 ])

ImCuW11 = Parameter(name = 'ImCuW11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW11}}',
                    lhablock = 'D6',
                    lhacode = [ 72 ])

ReCuW22 = Parameter(name = 'ReCuW22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW22}}',
                    lhablock = 'D6',
                    lhacode = [ 73 ])

ImCuW22 = Parameter(name = 'ImCuW22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW22}}',
                    lhablock = 'D6',
                    lhacode = [ 74 ])

ReCuW33 = Parameter(name = 'ReCuW33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW33}}',
                    lhablock = 'D6',
                    lhacode = [ 75 ])

ImCuW33 = Parameter(name = 'ImCuW33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW33}}',
                    lhablock = 'D6',
                    lhacode = [ 76 ])

ReCuW12 = Parameter(name = 'ReCuW12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW12}}',
                    lhablock = 'D6',
                    lhacode = [ 77 ])

ImCuW12 = Parameter(name = 'ImCuW12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW12}}',
                    lhablock = 'D6',
                    lhacode = [ 78 ])

ReCuW21 = Parameter(name = 'ReCuW21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW21}}',
                    lhablock = 'D6',
                    lhacode = [ 79 ])

ImCuW21 = Parameter(name = 'ImCuW21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW21}}',
                    lhablock = 'D6',
                    lhacode = [ 80 ])

ReCuW13 = Parameter(name = 'ReCuW13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW13}}',
                    lhablock = 'D6',
                    lhacode = [ 81 ])

ImCuW13 = Parameter(name = 'ImCuW13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW13}}',
                    lhablock = 'D6',
                    lhacode = [ 82 ])

ReCuW31 = Parameter(name = 'ReCuW31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW31}}',
                    lhablock = 'D6',
                    lhacode = [ 83 ])

ImCuW31 = Parameter(name = 'ImCuW31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW31}}',
                    lhablock = 'D6',
                    lhacode = [ 84 ])

ReCuW23 = Parameter(name = 'ReCuW23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW23}}',
                    lhablock = 'D6',
                    lhacode = [ 85 ])

ImCuW23 = Parameter(name = 'ImCuW23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW23}}',
                    lhablock = 'D6',
                    lhacode = [ 86 ])

ReCuW32 = Parameter(name = 'ReCuW32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uW32}}',
                    lhablock = 'D6',
                    lhacode = [ 87 ])

ImCuW32 = Parameter(name = 'ImCuW32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uW32}}',
                    lhablock = 'D6',
                    lhacode = [ 88 ])

ReCuB11 = Parameter(name = 'ReCuB11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB11}}',
                    lhablock = 'D6',
                    lhacode = [ 89 ])

ImCuB11 = Parameter(name = 'ImCuB11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB11}}',
                    lhablock = 'D6',
                    lhacode = [ 90 ])

ReCuB22 = Parameter(name = 'ReCuB22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB22}}',
                    lhablock = 'D6',
                    lhacode = [ 91 ])

ImCuB22 = Parameter(name = 'ImCuB22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB22}}',
                    lhablock = 'D6',
                    lhacode = [ 92 ])

ReCuB33 = Parameter(name = 'ReCuB33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB33}}',
                    lhablock = 'D6',
                    lhacode = [ 93 ])

ImCuB33 = Parameter(name = 'ImCuB33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB33}}',
                    lhablock = 'D6',
                    lhacode = [ 94 ])

ReCuB12 = Parameter(name = 'ReCuB12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB12}}',
                    lhablock = 'D6',
                    lhacode = [ 95 ])

ImCuB12 = Parameter(name = 'ImCuB12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB12}}',
                    lhablock = 'D6',
                    lhacode = [ 96 ])

ReCuB21 = Parameter(name = 'ReCuB21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB21}}',
                    lhablock = 'D6',
                    lhacode = [ 97 ])

ImCuB21 = Parameter(name = 'ImCuB21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB21}}',
                    lhablock = 'D6',
                    lhacode = [ 98 ])

ReCuB13 = Parameter(name = 'ReCuB13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB13}}',
                    lhablock = 'D6',
                    lhacode = [ 99 ])

ImCuB13 = Parameter(name = 'ImCuB13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB13}}',
                    lhablock = 'D6',
                    lhacode = [ 100 ])

ReCuB31 = Parameter(name = 'ReCuB31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB31}}',
                    lhablock = 'D6',
                    lhacode = [ 101 ])

ImCuB31 = Parameter(name = 'ImCuB31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB31}}',
                    lhablock = 'D6',
                    lhacode = [ 102 ])

ReCuB23 = Parameter(name = 'ReCuB23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB23}}',
                    lhablock = 'D6',
                    lhacode = [ 103 ])

ImCuB23 = Parameter(name = 'ImCuB23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB23}}',
                    lhablock = 'D6',
                    lhacode = [ 104 ])

ReCuB32 = Parameter(name = 'ReCuB32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{uB32}}',
                    lhablock = 'D6',
                    lhacode = [ 105 ])

ImCuB32 = Parameter(name = 'ImCuB32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{uB32}}',
                    lhablock = 'D6',
                    lhacode = [ 106 ])

ReCdG11 = Parameter(name = 'ReCdG11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG11}}',
                    lhablock = 'D6',
                    lhacode = [ 107 ])

ImCdG11 = Parameter(name = 'ImCdG11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG11}}',
                    lhablock = 'D6',
                    lhacode = [ 108 ])

ReCdG22 = Parameter(name = 'ReCdG22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG22}}',
                    lhablock = 'D6',
                    lhacode = [ 109 ])

ImCdG22 = Parameter(name = 'ImCdG22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG22}}',
                    lhablock = 'D6',
                    lhacode = [ 110 ])

ReCdG33 = Parameter(name = 'ReCdG33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG33}}',
                    lhablock = 'D6',
                    lhacode = [ 111 ])

ImCdG33 = Parameter(name = 'ImCdG33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG33}}',
                    lhablock = 'D6',
                    lhacode = [ 112 ])

ReCdG12 = Parameter(name = 'ReCdG12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG12}}',
                    lhablock = 'D6',
                    lhacode = [ 113 ])

ImCdG12 = Parameter(name = 'ImCdG12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG12}}',
                    lhablock = 'D6',
                    lhacode = [ 114 ])

ReCdG21 = Parameter(name = 'ReCdG21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG21}}',
                    lhablock = 'D6',
                    lhacode = [ 115 ])

ImCdG21 = Parameter(name = 'ImCdG21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG21}}',
                    lhablock = 'D6',
                    lhacode = [ 116 ])

ReCdG13 = Parameter(name = 'ReCdG13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG13}}',
                    lhablock = 'D6',
                    lhacode = [ 117 ])

ImCdG13 = Parameter(name = 'ImCdG13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG13}}',
                    lhablock = 'D6',
                    lhacode = [ 118 ])

ReCdG31 = Parameter(name = 'ReCdG31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG31}}',
                    lhablock = 'D6',
                    lhacode = [ 119 ])

ImCdG31 = Parameter(name = 'ImCdG31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG31}}',
                    lhablock = 'D6',
                    lhacode = [ 120 ])

ReCdG23 = Parameter(name = 'ReCdG23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG23}}',
                    lhablock = 'D6',
                    lhacode = [ 121 ])

ImCdG23 = Parameter(name = 'ImCdG23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG23}}',
                    lhablock = 'D6',
                    lhacode = [ 122 ])

ReCdG32 = Parameter(name = 'ReCdG32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dG32}}',
                    lhablock = 'D6',
                    lhacode = [ 123 ])

ImCdG32 = Parameter(name = 'ImCdG32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dG32}}',
                    lhablock = 'D6',
                    lhacode = [ 124 ])

ReCdW11 = Parameter(name = 'ReCdW11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW11}}',
                    lhablock = 'D6',
                    lhacode = [ 125 ])

ImCdW11 = Parameter(name = 'ImCdW11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW11}}',
                    lhablock = 'D6',
                    lhacode = [ 126 ])

ReCdW22 = Parameter(name = 'ReCdW22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW22}}',
                    lhablock = 'D6',
                    lhacode = [ 127 ])

ImCdW22 = Parameter(name = 'ImCdW22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW22}}',
                    lhablock = 'D6',
                    lhacode = [ 128 ])

ReCdW33 = Parameter(name = 'ReCdW33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW33}}',
                    lhablock = 'D6',
                    lhacode = [ 129 ])

ImCdW33 = Parameter(name = 'ImCdW33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW33}}',
                    lhablock = 'D6',
                    lhacode = [ 130 ])

ReCdW12 = Parameter(name = 'ReCdW12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW12}}',
                    lhablock = 'D6',
                    lhacode = [ 131 ])

ImCdW12 = Parameter(name = 'ImCdW12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW12}}',
                    lhablock = 'D6',
                    lhacode = [ 132 ])

ReCdW21 = Parameter(name = 'ReCdW21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW21}}',
                    lhablock = 'D6',
                    lhacode = [ 133 ])

ImCdW21 = Parameter(name = 'ImCdW21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW21}}',
                    lhablock = 'D6',
                    lhacode = [ 134 ])

ReCdW13 = Parameter(name = 'ReCdW13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW13}}',
                    lhablock = 'D6',
                    lhacode = [ 135 ])

ImCdW13 = Parameter(name = 'ImCdW13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW13}}',
                    lhablock = 'D6',
                    lhacode = [ 136 ])

ReCdW31 = Parameter(name = 'ReCdW31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW31}}',
                    lhablock = 'D6',
                    lhacode = [ 137 ])

ImCdW31 = Parameter(name = 'ImCdW31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW31}}',
                    lhablock = 'D6',
                    lhacode = [ 138 ])

ReCdW23 = Parameter(name = 'ReCdW23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW23}}',
                    lhablock = 'D6',
                    lhacode = [ 139 ])

ImCdW23 = Parameter(name = 'ImCdW23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW23}}',
                    lhablock = 'D6',
                    lhacode = [ 140 ])

ReCdW32 = Parameter(name = 'ReCdW32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dW32}}',
                    lhablock = 'D6',
                    lhacode = [ 141 ])

ImCdW32 = Parameter(name = 'ImCdW32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dW32}}',
                    lhablock = 'D6',
                    lhacode = [ 142 ])

ReCdB11 = Parameter(name = 'ReCdB11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB11}}',
                    lhablock = 'D6',
                    lhacode = [ 143 ])

ImCdB11 = Parameter(name = 'ImCdB11',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB11}}',
                    lhablock = 'D6',
                    lhacode = [ 144 ])

ReCdB22 = Parameter(name = 'ReCdB22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB22}}',
                    lhablock = 'D6',
                    lhacode = [ 145 ])

ImCdB22 = Parameter(name = 'ImCdB22',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB22}}',
                    lhablock = 'D6',
                    lhacode = [ 146 ])

ReCdB33 = Parameter(name = 'ReCdB33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB33}}',
                    lhablock = 'D6',
                    lhacode = [ 147 ])

ImCdB33 = Parameter(name = 'ImCdB33',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB33}}',
                    lhablock = 'D6',
                    lhacode = [ 148 ])

ReCdB12 = Parameter(name = 'ReCdB12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB12}}',
                    lhablock = 'D6',
                    lhacode = [ 149 ])

ImCdB12 = Parameter(name = 'ImCdB12',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB12}}',
                    lhablock = 'D6',
                    lhacode = [ 150 ])

ReCdB21 = Parameter(name = 'ReCdB21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB21}}',
                    lhablock = 'D6',
                    lhacode = [ 151 ])

ImCdB21 = Parameter(name = 'ImCdB21',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB21}}',
                    lhablock = 'D6',
                    lhacode = [ 152 ])

ReCdB13 = Parameter(name = 'ReCdB13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB13}}',
                    lhablock = 'D6',
                    lhacode = [ 153 ])

ImCdB13 = Parameter(name = 'ImCdB13',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB13}}',
                    lhablock = 'D6',
                    lhacode = [ 154 ])

ReCdB31 = Parameter(name = 'ReCdB31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB31}}',
                    lhablock = 'D6',
                    lhacode = [ 155 ])

ImCdB31 = Parameter(name = 'ImCdB31',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB31}}',
                    lhablock = 'D6',
                    lhacode = [ 156 ])

ReCdB23 = Parameter(name = 'ReCdB23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB23}}',
                    lhablock = 'D6',
                    lhacode = [ 157 ])

ImCdB23 = Parameter(name = 'ImCdB23',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB23}}',
                    lhablock = 'D6',
                    lhacode = [ 158 ])

ReCdB32 = Parameter(name = 'ReCdB32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{dB32}}',
                    lhablock = 'D6',
                    lhacode = [ 159 ])

ImCdB32 = Parameter(name = 'ImCdB32',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{dB32}}',
                    lhablock = 'D6',
                    lhacode = [ 160 ])

ReCePhi11 = Parameter(name = 'ReCePhi11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $11}}',
                      lhablock = 'D6',
                      lhacode = [ 161 ])

ImCePhi11 = Parameter(name = 'ImCePhi11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $11}}',
                      lhablock = 'D6',
                      lhacode = [ 162 ])

ReCePhi22 = Parameter(name = 'ReCePhi22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $22}}',
                      lhablock = 'D6',
                      lhacode = [ 163 ])

ImCePhi22 = Parameter(name = 'ImCePhi22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $22}}',
                      lhablock = 'D6',
                      lhacode = [ 164 ])

ReCePhi33 = Parameter(name = 'ReCePhi33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $33}}',
                      lhablock = 'D6',
                      lhacode = [ 165 ])

ImCePhi33 = Parameter(name = 'ImCePhi33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $33}}',
                      lhablock = 'D6',
                      lhacode = [ 166 ])

ReCePhi12 = Parameter(name = 'ReCePhi12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $12}}',
                      lhablock = 'D6',
                      lhacode = [ 167 ])

ImCePhi12 = Parameter(name = 'ImCePhi12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $12}}',
                      lhablock = 'D6',
                      lhacode = [ 168 ])

ReCePhi21 = Parameter(name = 'ReCePhi21',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $21}}',
                      lhablock = 'D6',
                      lhacode = [ 169 ])

ImCePhi21 = Parameter(name = 'ImCePhi21',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $21}}',
                      lhablock = 'D6',
                      lhacode = [ 170 ])

ReCePhi13 = Parameter(name = 'ReCePhi13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $13}}',
                      lhablock = 'D6',
                      lhacode = [ 171 ])

ImCePhi13 = Parameter(name = 'ImCePhi13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $13}}',
                      lhablock = 'D6',
                      lhacode = [ 172 ])

ReCePhi31 = Parameter(name = 'ReCePhi31',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $31}}',
                      lhablock = 'D6',
                      lhacode = [ 173 ])

ImCePhi31 = Parameter(name = 'ImCePhi31',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $31}}',
                      lhablock = 'D6',
                      lhacode = [ 174 ])

ReCePhi23 = Parameter(name = 'ReCePhi23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $23}}',
                      lhablock = 'D6',
                      lhacode = [ 175 ])

ImCePhi23 = Parameter(name = 'ImCePhi23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $23}}',
                      lhablock = 'D6',
                      lhacode = [ 176 ])

ReCePhi32 = Parameter(name = 'ReCePhi32',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{e$\\phi $32}}',
                      lhablock = 'D6',
                      lhacode = [ 177 ])

ImCePhi32 = Parameter(name = 'ImCePhi32',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{e$\\phi $32}}',
                      lhablock = 'D6',
                      lhacode = [ 178 ])

ReCuPhi11 = Parameter(name = 'ReCuPhi11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $11}}',
                      lhablock = 'D6',
                      lhacode = [ 179 ])

ImCuPhi11 = Parameter(name = 'ImCuPhi11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $11}}',
                      lhablock = 'D6',
                      lhacode = [ 180 ])

ReCuPhi22 = Parameter(name = 'ReCuPhi22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $22}}',
                      lhablock = 'D6',
                      lhacode = [ 181 ])

ImCuPhi22 = Parameter(name = 'ImCuPhi22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $22}}',
                      lhablock = 'D6',
                      lhacode = [ 182 ])

ReCuPhi33 = Parameter(name = 'ReCuPhi33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $33}}',
                      lhablock = 'D6',
                      lhacode = [ 183 ])

ImCuPhi33 = Parameter(name = 'ImCuPhi33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $33}}',
                      lhablock = 'D6',
                      lhacode = [ 184 ])

ReCuPhi12 = Parameter(name = 'ReCuPhi12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $12}}',
                      lhablock = 'D6',
                      lhacode = [ 185 ])

ImCuPhi12 = Parameter(name = 'ImCuPhi12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $12}}',
                      lhablock = 'D6',
                      lhacode = [ 186 ])

ReCuPhi21 = Parameter(name = 'ReCuPhi21',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $21}}',
                      lhablock = 'D6',
                      lhacode = [ 187 ])

ImCuPhi21 = Parameter(name = 'ImCuPhi21',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $21}}',
                      lhablock = 'D6',
                      lhacode = [ 188 ])

ReCuPhi13 = Parameter(name = 'ReCuPhi13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $13}}',
                      lhablock = 'D6',
                      lhacode = [ 189 ])

ImCuPhi13 = Parameter(name = 'ImCuPhi13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $13}}',
                      lhablock = 'D6',
                      lhacode = [ 190 ])

ReCuPhi31 = Parameter(name = 'ReCuPhi31',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $31}}',
                      lhablock = 'D6',
                      lhacode = [ 191 ])

ImCuPhi31 = Parameter(name = 'ImCuPhi31',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $31}}',
                      lhablock = 'D6',
                      lhacode = [ 192 ])

ReCuPhi23 = Parameter(name = 'ReCuPhi23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $23}}',
                      lhablock = 'D6',
                      lhacode = [ 193 ])

ImCuPhi23 = Parameter(name = 'ImCuPhi23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $23}}',
                      lhablock = 'D6',
                      lhacode = [ 194 ])

ReCuPhi32 = Parameter(name = 'ReCuPhi32',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{u$\\phi $32}}',
                      lhablock = 'D6',
                      lhacode = [ 195 ])

ImCuPhi32 = Parameter(name = 'ImCuPhi32',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{u$\\phi $32}}',
                      lhablock = 'D6',
                      lhacode = [ 196 ])

ReCdPhi11 = Parameter(name = 'ReCdPhi11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $11}}',
                      lhablock = 'D6',
                      lhacode = [ 197 ])

ImCdPhi11 = Parameter(name = 'ImCdPhi11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $11}}',
                      lhablock = 'D6',
                      lhacode = [ 198 ])

ReCdPhi22 = Parameter(name = 'ReCdPhi22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $22}}',
                      lhablock = 'D6',
                      lhacode = [ 199 ])

ImCdPhi22 = Parameter(name = 'ImCdPhi22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $22}}',
                      lhablock = 'D6',
                      lhacode = [ 200 ])

ReCdPhi33 = Parameter(name = 'ReCdPhi33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $33}}',
                      lhablock = 'D6',
                      lhacode = [ 201 ])

ImCdPhi33 = Parameter(name = 'ImCdPhi33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $33}}',
                      lhablock = 'D6',
                      lhacode = [ 202 ])

ReCdPhi12 = Parameter(name = 'ReCdPhi12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $12}}',
                      lhablock = 'D6',
                      lhacode = [ 203 ])

ImCdPhi12 = Parameter(name = 'ImCdPhi12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $12}}',
                      lhablock = 'D6',
                      lhacode = [ 204 ])

ReCdPhi21 = Parameter(name = 'ReCdPhi21',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $21}}',
                      lhablock = 'D6',
                      lhacode = [ 205 ])

ImCdPhi21 = Parameter(name = 'ImCdPhi21',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $21}}',
                      lhablock = 'D6',
                      lhacode = [ 206 ])

ReCdPhi13 = Parameter(name = 'ReCdPhi13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $13}}',
                      lhablock = 'D6',
                      lhacode = [ 207 ])

ImCdPhi13 = Parameter(name = 'ImCdPhi13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $13}}',
                      lhablock = 'D6',
                      lhacode = [ 208 ])

ReCdPhi31 = Parameter(name = 'ReCdPhi31',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $31}}',
                      lhablock = 'D6',
                      lhacode = [ 209 ])

ImCdPhi31 = Parameter(name = 'ImCdPhi31',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $31}}',
                      lhablock = 'D6',
                      lhacode = [ 210 ])

ReCdPhi23 = Parameter(name = 'ReCdPhi23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $23}}',
                      lhablock = 'D6',
                      lhacode = [ 211 ])

ImCdPhi23 = Parameter(name = 'ImCdPhi23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $23}}',
                      lhablock = 'D6',
                      lhacode = [ 212 ])

ReCdPhi32 = Parameter(name = 'ReCdPhi32',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{d$\\phi $32}}',
                      lhablock = 'D6',
                      lhacode = [ 213 ])

ImCdPhi32 = Parameter(name = 'ImCdPhi32',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{d$\\phi $32}}',
                      lhablock = 'D6',
                      lhacode = [ 214 ])

ReC1Phil11 = Parameter(name = 'ReC1Phil11',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $l11}}',
                       lhablock = 'D6',
                       lhacode = [ 215 ])

ReC1Phil22 = Parameter(name = 'ReC1Phil22',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $l22}}',
                       lhablock = 'D6',
                       lhacode = [ 216 ])

ReC1Phil33 = Parameter(name = 'ReC1Phil33',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $l33}}',
                       lhablock = 'D6',
                       lhacode = [ 217 ])

ReC3Phil11 = Parameter(name = 'ReC3Phil11',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $l11}}',
                       lhablock = 'D6',
                       lhacode = [ 218 ])

ReC3Phil22 = Parameter(name = 'ReC3Phil22',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $l22}}',
                       lhablock = 'D6',
                       lhacode = [ 219 ])

ReC3Phil33 = Parameter(name = 'ReC3Phil33',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $l33}}',
                       lhablock = 'D6',
                       lhacode = [ 220 ])

ReCPhie11 = Parameter(name = 'ReCPhie11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{Phie11}}',
                      lhablock = 'D6',
                      lhacode = [ 221 ])

ReCPhie22 = Parameter(name = 'ReCPhie22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{Phie22}}',
                      lhablock = 'D6',
                      lhacode = [ 222 ])

ReCPhie33 = Parameter(name = 'ReCPhie33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{Phie33}}',
                      lhablock = 'D6',
                      lhacode = [ 223 ])

ReC1Phiq11 = Parameter(name = 'ReC1Phiq11',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $q11}}',
                       lhablock = 'D6',
                       lhacode = [ 224 ])

ReC1Phiq22 = Parameter(name = 'ReC1Phiq22',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $q22}}',
                       lhablock = 'D6',
                       lhacode = [ 225 ])

ReC1Phiq33 = Parameter(name = 'ReC1Phiq33',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $q33}}',
                       lhablock = 'D6',
                       lhacode = [ 226 ])

ReC1Phiq12 = Parameter(name = 'ReC1Phiq12',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $q12}}',
                       lhablock = 'D6',
                       lhacode = [ 227 ])

ReC1Phiq13 = Parameter(name = 'ReC1Phiq13',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $q13}}',
                       lhablock = 'D6',
                       lhacode = [ 228 ])

ReC1Phiq23 = Parameter(name = 'ReC1Phiq23',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $q23}}',
                       lhablock = 'D6',
                       lhacode = [ 229 ])

ImC1Phiq12 = Parameter(name = 'ImC1Phiq12',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $q12}}',
                       lhablock = 'D6',
                       lhacode = [ 230 ])

ImC1Phiq13 = Parameter(name = 'ImC1Phiq13',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $q13}}',
                       lhablock = 'D6',
                       lhacode = [ 231 ])

ImC1Phiq23 = Parameter(name = 'ImC1Phiq23',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $q23}}',
                       lhablock = 'D6',
                       lhacode = [ 232 ])

ReC3Phiq11 = Parameter(name = 'ReC3Phiq11',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $q11}}',
                       lhablock = 'D6',
                       lhacode = [ 233 ])

ReC3Phiq22 = Parameter(name = 'ReC3Phiq22',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $q22}}',
                       lhablock = 'D6',
                       lhacode = [ 234 ])

ReC3Phiq33 = Parameter(name = 'ReC3Phiq33',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $q33}}',
                       lhablock = 'D6',
                       lhacode = [ 235 ])

ReC3Phiq12 = Parameter(name = 'ReC3Phiq12',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $q12}}',
                       lhablock = 'D6',
                       lhacode = [ 236 ])

ReC3Phiq13 = Parameter(name = 'ReC3Phiq13',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $q13}}',
                       lhablock = 'D6',
                       lhacode = [ 237 ])

ReC3Phiq23 = Parameter(name = 'ReC3Phiq23',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{3 \\text{$\\phi $q23}}',
                       lhablock = 'D6',
                       lhacode = [ 238 ])

ImC3Phiq12 = Parameter(name = 'ImC3Phiq12',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{3 \\text{$\\phi $q12}}',
                       lhablock = 'D6',
                       lhacode = [ 239 ])

ImC3Phiq13 = Parameter(name = 'ImC3Phiq13',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{3 \\text{$\\phi $q13}}',
                       lhablock = 'D6',
                       lhacode = [ 240 ])

ImC3Phiq23 = Parameter(name = 'ImC3Phiq23',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{3 \\text{$\\phi $q23}}',
                       lhablock = 'D6',
                       lhacode = [ 241 ])

ReCPhiu11 = Parameter(name = 'ReCPhiu11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $u11}}',
                      lhablock = 'D6',
                      lhacode = [ 242 ])

ReCPhiu22 = Parameter(name = 'ReCPhiu22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $u22}}',
                      lhablock = 'D6',
                      lhacode = [ 243 ])

ReCPhiu33 = Parameter(name = 'ReCPhiu33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $u33}}',
                      lhablock = 'D6',
                      lhacode = [ 244 ])

ReCPhiu12 = Parameter(name = 'ReCPhiu12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $u12}}',
                      lhablock = 'D6',
                      lhacode = [ 245 ])

ReCPhiu13 = Parameter(name = 'ReCPhiu13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $u13}}',
                      lhablock = 'D6',
                      lhacode = [ 246 ])

ReCPhiu23 = Parameter(name = 'ReCPhiu23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $u23}}',
                      lhablock = 'D6',
                      lhacode = [ 247 ])

ImCPhiu12 = Parameter(name = 'ImCPhiu12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $u12}}',
                      lhablock = 'D6',
                      lhacode = [ 248 ])

ImCPhiu13 = Parameter(name = 'ImCPhiu13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{$\\phi $u13}}',
                      lhablock = 'D6',
                      lhacode = [ 249 ])

ImCPhiu23 = Parameter(name = 'ImCPhiu23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{$\\phi $u23}}',
                      lhablock = 'D6',
                      lhacode = [ 250 ])

ReCPhid11 = Parameter(name = 'ReCPhid11',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $d11}}',
                      lhablock = 'D6',
                      lhacode = [ 251 ])

ReCPhid22 = Parameter(name = 'ReCPhid22',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $d22}}',
                      lhablock = 'D6',
                      lhacode = [ 252 ])

ReCPhid33 = Parameter(name = 'ReCPhid33',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $d33}}',
                      lhablock = 'D6',
                      lhacode = [ 253 ])

ReCPhid12 = Parameter(name = 'ReCPhid12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $d12}}',
                      lhablock = 'D6',
                      lhacode = [ 254 ])

ReCPhid13 = Parameter(name = 'ReCPhid13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $d13}}',
                      lhablock = 'D6',
                      lhacode = [ 255 ])

ReCPhid23 = Parameter(name = 'ReCPhid23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ReC}_{\\text{$\\phi $d23}}',
                      lhablock = 'D6',
                      lhacode = [ 256 ])

ImCPhid12 = Parameter(name = 'ImCPhid12',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{$\\phi $d12}}',
                      lhablock = 'D6',
                      lhacode = [ 257 ])

ImCPhid13 = Parameter(name = 'ImCPhid13',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{$\\phi $d13}}',
                      lhablock = 'D6',
                      lhacode = [ 258 ])

ImCPhid23 = Parameter(name = 'ImCPhid23',
                      nature = 'external',
                      type = 'real',
                      value = 0,
                      texname = '\\text{ImC}_{\\text{$\\phi $d23}}',
                      lhablock = 'D6',
                      lhacode = [ 259 ])

ReCPhiud11 = Parameter(name = 'ReCPhiud11',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud11}}',
                       lhablock = 'D6',
                       lhacode = [ 260 ])

ImCPhiud11 = Parameter(name = 'ImCPhiud11',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud11}}',
                       lhablock = 'D6',
                       lhacode = [ 261 ])

ReCPhiud22 = Parameter(name = 'ReCPhiud22',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud22}}',
                       lhablock = 'D6',
                       lhacode = [ 262 ])

ImCPhiud22 = Parameter(name = 'ImCPhiud22',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud22}}',
                       lhablock = 'D6',
                       lhacode = [ 263 ])

ReCPhiud33 = Parameter(name = 'ReCPhiud33',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud33}}',
                       lhablock = 'D6',
                       lhacode = [ 264 ])

ImCPhiud33 = Parameter(name = 'ImCPhiud33',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud33}}',
                       lhablock = 'D6',
                       lhacode = [ 265 ])

ReCPhiud12 = Parameter(name = 'ReCPhiud12',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud12}}',
                       lhablock = 'D6',
                       lhacode = [ 266 ])

ImCPhiud12 = Parameter(name = 'ImCPhiud12',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud12}}',
                       lhablock = 'D6',
                       lhacode = [ 267 ])

ReCPhiud21 = Parameter(name = 'ReCPhiud21',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud21}}',
                       lhablock = 'D6',
                       lhacode = [ 268 ])

ImCPhiud21 = Parameter(name = 'ImCPhiud21',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud21}}',
                       lhablock = 'D6',
                       lhacode = [ 269 ])

ReCPhiud13 = Parameter(name = 'ReCPhiud13',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud13}}',
                       lhablock = 'D6',
                       lhacode = [ 270 ])

ImCPhiud13 = Parameter(name = 'ImCPhiud13',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud13}}',
                       lhablock = 'D6',
                       lhacode = [ 271 ])

ReCPhiud31 = Parameter(name = 'ReCPhiud31',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud31}}',
                       lhablock = 'D6',
                       lhacode = [ 272 ])

ImCPhiud31 = Parameter(name = 'ImCPhiud31',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud31}}',
                       lhablock = 'D6',
                       lhacode = [ 273 ])

ReCPhiud23 = Parameter(name = 'ReCPhiud23',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud23}}',
                       lhablock = 'D6',
                       lhacode = [ 274 ])

ImCPhiud23 = Parameter(name = 'ImCPhiud23',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud23}}',
                       lhablock = 'D6',
                       lhacode = [ 275 ])

ReCPhiud32 = Parameter(name = 'ReCPhiud32',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ReC}_{\\text{$\\phi $ud32}}',
                       lhablock = 'D6',
                       lhacode = [ 276 ])

ImCPhiud32 = Parameter(name = 'ImCPhiud32',
                       nature = 'external',
                       type = 'real',
                       value = 0,
                       texname = '\\text{ImC}_{\\text{$\\phi $ud32}}',
                       lhablock = 'D6',
                       lhacode = [ 277 ])

Cll1111 = Parameter(name = 'Cll1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll1111}}',
                    lhablock = 'D6',
                    lhacode = [ 278 ])

Cll2222 = Parameter(name = 'Cll2222',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll2222}}',
                    lhablock = 'D6',
                    lhacode = [ 279 ])

Cll3333 = Parameter(name = 'Cll3333',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll3333}}',
                    lhablock = 'D6',
                    lhacode = [ 280 ])

Cll1122 = Parameter(name = 'Cll1122',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll1122}}',
                    lhablock = 'D6',
                    lhacode = [ 281 ])

Cll1133 = Parameter(name = 'Cll1133',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll1133}}',
                    lhablock = 'D6',
                    lhacode = [ 282 ])

Cll2233 = Parameter(name = 'Cll2233',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll2233}}',
                    lhablock = 'D6',
                    lhacode = [ 283 ])

Cll1221 = Parameter(name = 'Cll1221',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll1221}}',
                    lhablock = 'D6',
                    lhacode = [ 284 ])

Cll2112 = Parameter(name = 'Cll2112',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{ll2112}}',
                    lhablock = 'D6',
                    lhacode = [ 285 ])

C1qq1111 = Parameter(name = 'C1qq1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1111}}',
                     lhablock = 'D6',
                     lhacode = [ 286 ])

C1qq2222 = Parameter(name = 'C1qq2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq2222}}',
                     lhablock = 'D6',
                     lhacode = [ 287 ])

C1qq3333 = Parameter(name = 'C1qq3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq3333}}',
                     lhablock = 'D6',
                     lhacode = [ 288 ])

C1qq1122 = Parameter(name = 'C1qq1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1122}}',
                     lhablock = 'D6',
                     lhacode = [ 289 ])

C1qq1133 = Parameter(name = 'C1qq1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1133}}',
                     lhablock = 'D6',
                     lhacode = [ 290 ])

C1qq2233 = Parameter(name = 'C1qq2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1221}}',
                     lhablock = 'D6',
                     lhacode = [ 291 ])

C1qq1221 = Parameter(name = 'C1qq1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1221}}',
                     lhablock = 'D6',
                     lhacode = [ 292 ])

C1qq1331 = Parameter(name = 'C1qq1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1331}}',
                     lhablock = 'D6',
                     lhacode = [ 293 ])

C1qq2332 = Parameter(name = 'C1qq2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq2332}}',
                     lhablock = 'D6',
                     lhacode = [ 294 ])

C1qq1212 = Parameter(name = 'C1qq1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1212}}',
                     lhablock = 'D6',
                     lhacode = [ 295 ])

C1qq1313 = Parameter(name = 'C1qq1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq1313}}',
                     lhablock = 'D6',
                     lhacode = [ 296 ])

C1qq2323 = Parameter(name = 'C1qq2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq2323}}',
                     lhablock = 'D6',
                     lhacode = [ 297 ])

C1qq2121 = Parameter(name = 'C1qq2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq2121}}',
                     lhablock = 'D6',
                     lhacode = [ 298 ])

C1qq3131 = Parameter(name = 'C1qq3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq3131}}',
                     lhablock = 'D6',
                     lhacode = [ 299 ])

C1qq3232 = Parameter(name = 'C1qq3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qq3232}}',
                     lhablock = 'D6',
                     lhacode = [ 300 ])

C3qq1111 = Parameter(name = 'C3qq1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq1111}}',
                     lhablock = 'D6',
                     lhacode = [ 301 ])

C3qq2222 = Parameter(name = 'C3qq2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq2222}}',
                     lhablock = 'D6',
                     lhacode = [ 302 ])

C3qq3333 = Parameter(name = 'C3qq3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq3333}}',
                     lhablock = 'D6',
                     lhacode = [ 303 ])

C3qq1122 = Parameter(name = 'C3qq1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq1122}}',
                     lhablock = 'D6',
                     lhacode = [ 304 ])

C3qq1133 = Parameter(name = 'C3qq1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq1133}}',
                     lhablock = 'D6',
                     lhacode = [ 305 ])

C3qq2233 = Parameter(name = 'C3qq2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq2233}}',
                     lhablock = 'D6',
                     lhacode = [ 306 ])

C3qq1221 = Parameter(name = 'C3qq1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq1221}}',
                     lhablock = 'D6',
                     lhacode = [ 307 ])

C3qq1331 = Parameter(name = 'C3qq1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq1331}}',
                     lhablock = 'D6',
                     lhacode = [ 308 ])

C3qq2332 = Parameter(name = 'C3qq2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq2332}}',
                     lhablock = 'D6',
                     lhacode = [ 309 ])

C3qq1212 = Parameter(name = 'C3qq1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq1212}}',
                     lhablock = 'D6',
                     lhacode = [ 310 ])

C3qq1313 = Parameter(name = 'C3qq1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq1313}}',
                     lhablock = 'D6',
                     lhacode = [ 311 ])

C3qq2323 = Parameter(name = 'C3qq2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq2323}}',
                     lhablock = 'D6',
                     lhacode = [ 312 ])

C3qq2121 = Parameter(name = 'C3qq2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq2121}}',
                     lhablock = 'D6',
                     lhacode = [ 313 ])

C3qq3131 = Parameter(name = 'C3qq3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq3131}}',
                     lhablock = 'D6',
                     lhacode = [ 314 ])

C3qq3232 = Parameter(name = 'C3qq3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{3 \\text{qq3232}}',
                     lhablock = 'D6',
                     lhacode = [ 315 ])

C1lq = Parameter(name = 'C1lq',
                 nature = 'external',
                 type = 'real',
                 value = 0,
                 texname = '\\text{Subsuperscript}[\\text{ReC},\\text{lq},\\text{(1)}]',
                 lhablock = 'D6',
                 lhacode = [ 316 ])

C3lq = Parameter(name = 'C3lq',
                 nature = 'external',
                 type = 'real',
                 value = 0,
                 texname = '\\text{Subsuperscript}[\\text{ReC},\\text{lq},\\text{(3)}]',
                 lhablock = 'D6',
                 lhacode = [ 317 ])

ReCledq = Parameter(name = 'ReCledq',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ReC}_{\\text{ledq}}',
                    lhablock = 'D6',
                    lhacode = [ 318 ])

ImCledq = Parameter(name = 'ImCledq',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{ImC}_{\\text{ledq}}',
                    lhablock = 'D6',
                    lhacode = [ 319 ])

ReC1quqd1331 = Parameter(name = 'ReC1quqd1331',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{\\text{quqd1331}}',
                         lhablock = 'D6',
                         lhacode = [ 320 ])

ReC1quqd3113 = Parameter(name = 'ReC1quqd3113',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{\\text{quqd3113}}',
                         lhablock = 'D6',
                         lhacode = [ 321 ])

ReC1quqd1133 = Parameter(name = 'ReC1quqd1133',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{\\text{quqd1133}}',
                         lhablock = 'D6',
                         lhacode = [ 322 ])

ReC1quqd3311 = Parameter(name = 'ReC1quqd3311',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{\\text{quqd3311}}',
                         lhablock = 'D6',
                         lhacode = [ 323 ])

ReC1quqd1313 = Parameter(name = 'ReC1quqd1313',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{\\text{quqd1313}}',
                         lhablock = 'D6',
                         lhacode = [ 324 ])

ReC1quqd3131 = Parameter(name = 'ReC1quqd3131',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{\\text{quqd3131}}',
                         lhablock = 'D6',
                         lhacode = [ 325 ])

ImC1quqd1331 = Parameter(name = 'ImC1quqd1331',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{\\text{quqd1331}}',
                         lhablock = 'D6',
                         lhacode = [ 326 ])

ImC1quqd3113 = Parameter(name = 'ImC1quqd3113',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{\\text{quqd3113}}',
                         lhablock = 'D6',
                         lhacode = [ 327 ])

ImC1quqd1133 = Parameter(name = 'ImC1quqd1133',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{\\text{quqd1133}}',
                         lhablock = 'D6',
                         lhacode = [ 328 ])

ImC1quqd3311 = Parameter(name = 'ImC1quqd3311',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{\\text{quqd3311}}',
                         lhablock = 'D6',
                         lhacode = [ 329 ])

ImC1quqd1313 = Parameter(name = 'ImC1quqd1313',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{\\text{quqd1313}}',
                         lhablock = 'D6',
                         lhacode = [ 330 ])

ImC1quqd3131 = Parameter(name = 'ImC1quqd3131',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{\\text{quqd3131}}',
                         lhablock = 'D6',
                         lhacode = [ 331 ])

ReC8quqd1331 = Parameter(name = 'ReC8quqd1331',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{8 \\text{quqd1331}}',
                         lhablock = 'D6',
                         lhacode = [ 332 ])

ReC8quqd3113 = Parameter(name = 'ReC8quqd3113',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{8 \\text{quqd3113}}',
                         lhablock = 'D6',
                         lhacode = [ 333 ])

ReC8quqd1133 = Parameter(name = 'ReC8quqd1133',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{8 \\text{quqd1133}}',
                         lhablock = 'D6',
                         lhacode = [ 334 ])

ReC8quqd3311 = Parameter(name = 'ReC8quqd3311',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{8 \\text{quqd3311}}',
                         lhablock = 'D6',
                         lhacode = [ 335 ])

ReC8quqd1313 = Parameter(name = 'ReC8quqd1313',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{8 \\text{quqd1313}}',
                         lhablock = 'D6',
                         lhacode = [ 336 ])

ReC8quqd3131 = Parameter(name = 'ReC8quqd3131',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ReC}_{8 \\text{quqd3131}}',
                         lhablock = 'D6',
                         lhacode = [ 337 ])

ImC8quqd1331 = Parameter(name = 'ImC8quqd1331',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{8 \\text{quqd1331}}',
                         lhablock = 'D6',
                         lhacode = [ 338 ])

ImC8quqd3113 = Parameter(name = 'ImC8quqd3113',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{8 \\text{quqd3113}}',
                         lhablock = 'D6',
                         lhacode = [ 339 ])

ImC8quqd1133 = Parameter(name = 'ImC8quqd1133',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{8 \\text{quqd1133}}',
                         lhablock = 'D6',
                         lhacode = [ 340 ])

ImC8quqd3311 = Parameter(name = 'ImC8quqd3311',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{8 \\text{quqd3311}}',
                         lhablock = 'D6',
                         lhacode = [ 341 ])

ImC8quqd1313 = Parameter(name = 'ImC8quqd1313',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{8 \\text{quqd1313}}',
                         lhablock = 'D6',
                         lhacode = [ 342 ])

ImC8quqd3131 = Parameter(name = 'ImC8quqd3131',
                         nature = 'external',
                         type = 'real',
                         value = 0,
                         texname = '\\text{ImC}_{8 \\text{quqd3131}}',
                         lhablock = 'D6',
                         lhacode = [ 343 ])

ReC1lequ = Parameter(name = 'ReC1lequ',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = '\\text{Subsuperscript}[\\text{ReC},\\text{lequ},\\text{(1)}]',
                     lhablock = 'D6',
                     lhacode = [ 344 ])

ImC1lequ = Parameter(name = 'ImC1lequ',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = '\\text{Subsuperscript}[\\text{ImC},\\text{lequ},\\text{(1)}]',
                     lhablock = 'D6',
                     lhacode = [ 345 ])

ReC3lequ = Parameter(name = 'ReC3lequ',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = '\\text{Subsuperscript}[\\text{ReC},\\text{lequ},\\text{(3)}]',
                     lhablock = 'D6',
                     lhacode = [ 346 ])

ImC3lequ = Parameter(name = 'ImC3lequ',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = '\\text{Subsuperscript}[\\text{ImC},\\text{lequ},\\text{(3)}]',
                     lhablock = 'D6',
                     lhacode = [ 347 ])

Cee = Parameter(name = 'Cee',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'C_e',
                lhablock = 'D6',
                lhacode = [ 348 ])

Cuu1111 = Parameter(name = 'Cuu1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu1111}}',
                    lhablock = 'D6',
                    lhacode = [ 349 ])

Cuu2222 = Parameter(name = 'Cuu2222',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu2222}}',
                    lhablock = 'D6',
                    lhacode = [ 350 ])

Cuu3333 = Parameter(name = 'Cuu3333',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu3333}}',
                    lhablock = 'D6',
                    lhacode = [ 351 ])

Cuu1122 = Parameter(name = 'Cuu1122',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu1122}}',
                    lhablock = 'D6',
                    lhacode = [ 352 ])

Cuu1133 = Parameter(name = 'Cuu1133',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu1133}}',
                    lhablock = 'D6',
                    lhacode = [ 353 ])

Cuu2233 = Parameter(name = 'Cuu2233',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu2233}}',
                    lhablock = 'D6',
                    lhacode = [ 354 ])

Cuu1221 = Parameter(name = 'Cuu1221',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu1221}}',
                    lhablock = 'D6',
                    lhacode = [ 355 ])

Cuu1331 = Parameter(name = 'Cuu1331',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu1331}}',
                    lhablock = 'D6',
                    lhacode = [ 356 ])

Cuu2332 = Parameter(name = 'Cuu2332',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu2332}}',
                    lhablock = 'D6',
                    lhacode = [ 357 ])

Cuu1212 = Parameter(name = 'Cuu1212',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu1212}}',
                    lhablock = 'D6',
                    lhacode = [ 358 ])

Cuu1313 = Parameter(name = 'Cuu1313',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu1313}}',
                    lhablock = 'D6',
                    lhacode = [ 359 ])

Cuu2323 = Parameter(name = 'Cuu2323',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu2323}}',
                    lhablock = 'D6',
                    lhacode = [ 360 ])

Cuu2121 = Parameter(name = 'Cuu2121',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu2121}}',
                    lhablock = 'D6',
                    lhacode = [ 361 ])

Cuu3131 = Parameter(name = 'Cuu3131',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu3131}}',
                    lhablock = 'D6',
                    lhacode = [ 362 ])

Cuu3232 = Parameter(name = 'Cuu3232',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{uu3232}}',
                    lhablock = 'D6',
                    lhacode = [ 363 ])

Cdd1111 = Parameter(name = 'Cdd1111',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd1111}}',
                    lhablock = 'D6',
                    lhacode = [ 364 ])

Cdd2222 = Parameter(name = 'Cdd2222',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd2222}}',
                    lhablock = 'D6',
                    lhacode = [ 365 ])

Cdd3333 = Parameter(name = 'Cdd3333',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd3333}}',
                    lhablock = 'D6',
                    lhacode = [ 366 ])

Cdd1122 = Parameter(name = 'Cdd1122',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd1122}}',
                    lhablock = 'D6',
                    lhacode = [ 367 ])

Cdd1133 = Parameter(name = 'Cdd1133',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd1133}}',
                    lhablock = 'D6',
                    lhacode = [ 368 ])

Cdd2233 = Parameter(name = 'Cdd2233',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd2233}}',
                    lhablock = 'D6',
                    lhacode = [ 369 ])

Cdd1221 = Parameter(name = 'Cdd1221',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd1221}}',
                    lhablock = 'D6',
                    lhacode = [ 370 ])

Cdd1331 = Parameter(name = 'Cdd1331',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd1331}}',
                    lhablock = 'D6',
                    lhacode = [ 371 ])

Cdd2332 = Parameter(name = 'Cdd2332',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd2332}}',
                    lhablock = 'D6',
                    lhacode = [ 372 ])

Cdd1212 = Parameter(name = 'Cdd1212',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd1212}}',
                    lhablock = 'D6',
                    lhacode = [ 373 ])

Cdd1313 = Parameter(name = 'Cdd1313',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd1313}}',
                    lhablock = 'D6',
                    lhacode = [ 374 ])

Cdd2323 = Parameter(name = 'Cdd2323',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd2323}}',
                    lhablock = 'D6',
                    lhacode = [ 375 ])

Cdd2121 = Parameter(name = 'Cdd2121',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd2121}}',
                    lhablock = 'D6',
                    lhacode = [ 376 ])

Cdd3131 = Parameter(name = 'Cdd3131',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd3131}}',
                    lhablock = 'D6',
                    lhacode = [ 377 ])

Cdd3232 = Parameter(name = 'Cdd3232',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = 'C_{\\text{dd3232}}',
                    lhablock = 'D6',
                    lhacode = [ 378 ])

Ceu = Parameter(name = 'Ceu',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'C_{\\text{eu}}',
                lhablock = 'D6',
                lhacode = [ 379 ])

Ced = Parameter(name = 'Ced',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'C_{\\text{ed}}',
                lhablock = 'D6',
                lhacode = [ 380 ])

C1ud1111 = Parameter(name = 'C1ud1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud1111}}',
                     lhablock = 'D6',
                     lhacode = [ 381 ])

C1ud2222 = Parameter(name = 'C1ud2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud2222}}',
                     lhablock = 'D6',
                     lhacode = [ 382 ])

C1ud3333 = Parameter(name = 'C1ud3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud3333}}',
                     lhablock = 'D6',
                     lhacode = [ 383 ])

C1ud1122 = Parameter(name = 'C1ud1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud1122}}',
                     lhablock = 'D6',
                     lhacode = [ 384 ])

C1ud1133 = Parameter(name = 'C1ud1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud1133}}',
                     lhablock = 'D6',
                     lhacode = [ 385 ])

C1ud2233 = Parameter(name = 'C1ud2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud2233}}',
                     lhablock = 'D6',
                     lhacode = [ 386 ])

C1ud2211 = Parameter(name = 'C1ud2211',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud2211}}',
                     lhablock = 'D6',
                     lhacode = [ 387 ])

C1ud3311 = Parameter(name = 'C1ud3311',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud3311}}',
                     lhablock = 'D6',
                     lhacode = [ 388 ])

C1ud3322 = Parameter(name = 'C1ud3322',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud3322}}',
                     lhablock = 'D6',
                     lhacode = [ 389 ])

C1ud1221 = Parameter(name = 'C1ud1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud1221}}',
                     lhablock = 'D6',
                     lhacode = [ 390 ])

C1ud1331 = Parameter(name = 'C1ud1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud1331}}',
                     lhablock = 'D6',
                     lhacode = [ 391 ])

C1ud2332 = Parameter(name = 'C1ud2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud2332}}',
                     lhablock = 'D6',
                     lhacode = [ 392 ])

C1ud2112 = Parameter(name = 'C1ud2112',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud2112}}',
                     lhablock = 'D6',
                     lhacode = [ 393 ])

C1ud3113 = Parameter(name = 'C1ud3113',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud3113}}',
                     lhablock = 'D6',
                     lhacode = [ 394 ])

C1ud3223 = Parameter(name = 'C1ud3223',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud3223}}',
                     lhablock = 'D6',
                     lhacode = [ 395 ])

C1ud1212 = Parameter(name = 'C1ud1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud1212}}',
                     lhablock = 'D6',
                     lhacode = [ 396 ])

C1ud1313 = Parameter(name = 'C1ud1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud1313}}',
                     lhablock = 'D6',
                     lhacode = [ 397 ])

C1ud2323 = Parameter(name = 'C1ud2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud2323}}',
                     lhablock = 'D6',
                     lhacode = [ 398 ])

C1ud2121 = Parameter(name = 'C1ud2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud2121}}',
                     lhablock = 'D6',
                     lhacode = [ 399 ])

C1ud3131 = Parameter(name = 'C1ud3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud3131}}',
                     lhablock = 'D6',
                     lhacode = [ 400 ])

C1ud3232 = Parameter(name = 'C1ud3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{ud3232}}',
                     lhablock = 'D6',
                     lhacode = [ 401 ])

C8ud1111 = Parameter(name = 'C8ud1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud1111}}',
                     lhablock = 'D6',
                     lhacode = [ 402 ])

C8ud2222 = Parameter(name = 'C8ud2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud2222}}',
                     lhablock = 'D6',
                     lhacode = [ 403 ])

C8ud3333 = Parameter(name = 'C8ud3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud3333}}',
                     lhablock = 'D6',
                     lhacode = [ 404 ])

C8ud1122 = Parameter(name = 'C8ud1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud1122}}',
                     lhablock = 'D6',
                     lhacode = [ 405 ])

C8ud1133 = Parameter(name = 'C8ud1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud1133}}',
                     lhablock = 'D6',
                     lhacode = [ 406 ])

C8ud2233 = Parameter(name = 'C8ud2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud2233}}',
                     lhablock = 'D6',
                     lhacode = [ 407 ])

C8ud2211 = Parameter(name = 'C8ud2211',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud2211}}',
                     lhablock = 'D6',
                     lhacode = [ 408 ])

C8ud3311 = Parameter(name = 'C8ud3311',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud3311}}',
                     lhablock = 'D6',
                     lhacode = [ 409 ])

C8ud3322 = Parameter(name = 'C8ud3322',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud3322}}',
                     lhablock = 'D6',
                     lhacode = [ 410 ])

C8ud1221 = Parameter(name = 'C8ud1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud1221}}',
                     lhablock = 'D6',
                     lhacode = [ 411 ])

C8ud1331 = Parameter(name = 'C8ud1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud1331}}',
                     lhablock = 'D6',
                     lhacode = [ 412 ])

C8ud2332 = Parameter(name = 'C8ud2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud2332}}',
                     lhablock = 'D6',
                     lhacode = [ 413 ])

C8ud2112 = Parameter(name = 'C8ud2112',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud2112}}',
                     lhablock = 'D6',
                     lhacode = [ 414 ])

C8ud3113 = Parameter(name = 'C8ud3113',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud3113}}',
                     lhablock = 'D6',
                     lhacode = [ 415 ])

C8ud3223 = Parameter(name = 'C8ud3223',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud3223}}',
                     lhablock = 'D6',
                     lhacode = [ 416 ])

C8ud1212 = Parameter(name = 'C8ud1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud1212}}',
                     lhablock = 'D6',
                     lhacode = [ 417 ])

C8ud1313 = Parameter(name = 'C8ud1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud1313}}',
                     lhablock = 'D6',
                     lhacode = [ 418 ])

C8ud2323 = Parameter(name = 'C8ud2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud2323}}',
                     lhablock = 'D6',
                     lhacode = [ 419 ])

C8ud2121 = Parameter(name = 'C8ud2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud2121}}',
                     lhablock = 'D6',
                     lhacode = [ 420 ])

C8ud3131 = Parameter(name = 'C8ud3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud3131}}',
                     lhablock = 'D6',
                     lhacode = [ 421 ])

C8ud3232 = Parameter(name = 'C8ud3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{ud3232}}',
                     lhablock = 'D6',
                     lhacode = [ 422 ])

Cle = Parameter(name = 'Cle',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'C_{\\text{le}}',
                lhablock = 'D6',
                lhacode = [ 423 ])

Clu = Parameter(name = 'Clu',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'C_{\\text{lu}}',
                lhablock = 'D6',
                lhacode = [ 424 ])

Cld = Parameter(name = 'Cld',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'C_{\\text{ld}}',
                lhablock = 'D6',
                lhacode = [ 425 ])

Cqe = Parameter(name = 'Cqe',
                nature = 'external',
                type = 'real',
                value = 0,
                texname = 'C_{\\text{qe}}',
                lhablock = 'D6',
                lhacode = [ 426 ])

C1qu1111 = Parameter(name = 'C1qu1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu1111}}',
                     lhablock = 'D6',
                     lhacode = [ 427 ])

C1qu2222 = Parameter(name = 'C1qu2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu2222}}',
                     lhablock = 'D6',
                     lhacode = [ 428 ])

C1qu3333 = Parameter(name = 'C1qu3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu3333}}',
                     lhablock = 'D6',
                     lhacode = [ 429 ])

C1qu1122 = Parameter(name = 'C1qu1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu1122}}',
                     lhablock = 'D6',
                     lhacode = [ 430 ])

C1qu1133 = Parameter(name = 'C1qu1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu1133}}',
                     lhablock = 'D6',
                     lhacode = [ 431 ])

C1qu2233 = Parameter(name = 'C1qu2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu2233}}',
                     lhablock = 'D6',
                     lhacode = [ 432 ])

C1qu2211 = Parameter(name = 'C1qu2211',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu2211}}',
                     lhablock = 'D6',
                     lhacode = [ 433 ])

C1qu3311 = Parameter(name = 'C1qu3311',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu3311}}',
                     lhablock = 'D6',
                     lhacode = [ 434 ])

C1qu3322 = Parameter(name = 'C1qu3322',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu3322}}',
                     lhablock = 'D6',
                     lhacode = [ 435 ])

C1qu1221 = Parameter(name = 'C1qu1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu1221}}',
                     lhablock = 'D6',
                     lhacode = [ 436 ])

C1qu2112 = Parameter(name = 'C1qu2112',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu2112}}',
                     lhablock = 'D6',
                     lhacode = [ 437 ])

C1qu1331 = Parameter(name = 'C1qu1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu1331}}',
                     lhablock = 'D6',
                     lhacode = [ 438 ])

C1qu3113 = Parameter(name = 'C1qu3113',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu3113}}',
                     lhablock = 'D6',
                     lhacode = [ 439 ])

C1qu2332 = Parameter(name = 'C1qu2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu2332}}',
                     lhablock = 'D6',
                     lhacode = [ 440 ])

C1qu3223 = Parameter(name = 'C1qu3223',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu3223}}',
                     lhablock = 'D6',
                     lhacode = [ 441 ])

C1qu1212 = Parameter(name = 'C1qu1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu1212}}',
                     lhablock = 'D6',
                     lhacode = [ 442 ])

C1qu1313 = Parameter(name = 'C1qu1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu1313}}',
                     lhablock = 'D6',
                     lhacode = [ 443 ])

C1qu2323 = Parameter(name = 'C1qu2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu2323}}',
                     lhablock = 'D6',
                     lhacode = [ 444 ])

C1qu2121 = Parameter(name = 'C1qu2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu2121}}',
                     lhablock = 'D6',
                     lhacode = [ 445 ])

C1qu3131 = Parameter(name = 'C1qu3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu3131}}',
                     lhablock = 'D6',
                     lhacode = [ 446 ])

C1qu3232 = Parameter(name = 'C1qu3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qu3232}}',
                     lhablock = 'D6',
                     lhacode = [ 447 ])

C8qu1111 = Parameter(name = 'C8qu1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu1111}}',
                     lhablock = 'D6',
                     lhacode = [ 448 ])

C8qu2222 = Parameter(name = 'C8qu2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu2222}}',
                     lhablock = 'D6',
                     lhacode = [ 449 ])

C8qu3333 = Parameter(name = 'C8qu3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu3333}}',
                     lhablock = 'D6',
                     lhacode = [ 450 ])

C8qu1122 = Parameter(name = 'C8qu1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu1122}}',
                     lhablock = 'D6',
                     lhacode = [ 451 ])

C8qu1133 = Parameter(name = 'C8qu1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu1133}}',
                     lhablock = 'D6',
                     lhacode = [ 452 ])

C8qu2233 = Parameter(name = 'C8qu2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu2233}}',
                     lhablock = 'D6',
                     lhacode = [ 453 ])

C8qu2211 = Parameter(name = 'C8qu2211',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu2211}}',
                     lhablock = 'D6',
                     lhacode = [ 454 ])

C8qu3311 = Parameter(name = 'C8qu3311',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu3311}}',
                     lhablock = 'D6',
                     lhacode = [ 455 ])

C8qu3322 = Parameter(name = 'C8qu3322',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu3322}}',
                     lhablock = 'D6',
                     lhacode = [ 456 ])

C8qu1221 = Parameter(name = 'C8qu1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu1221}}',
                     lhablock = 'D6',
                     lhacode = [ 457 ])

C8qu2112 = Parameter(name = 'C8qu2112',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu2112}}',
                     lhablock = 'D6',
                     lhacode = [ 458 ])

C8qu1331 = Parameter(name = 'C8qu1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu1331}}',
                     lhablock = 'D6',
                     lhacode = [ 459 ])

C8qu3113 = Parameter(name = 'C8qu3113',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu3113}}',
                     lhablock = 'D6',
                     lhacode = [ 460 ])

C8qu2332 = Parameter(name = 'C8qu2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu2332}}',
                     lhablock = 'D6',
                     lhacode = [ 461 ])

C8qu3223 = Parameter(name = 'C8qu3223',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu3223}}',
                     lhablock = 'D6',
                     lhacode = [ 462 ])

C8qu1212 = Parameter(name = 'C8qu1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu1212}}',
                     lhablock = 'D6',
                     lhacode = [ 463 ])

C8qu1313 = Parameter(name = 'C8qu1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu1313}}',
                     lhablock = 'D6',
                     lhacode = [ 464 ])

C8qu2323 = Parameter(name = 'C8qu2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu2323}}',
                     lhablock = 'D6',
                     lhacode = [ 465 ])

C8qu2121 = Parameter(name = 'C8qu2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu2121}}',
                     lhablock = 'D6',
                     lhacode = [ 466 ])

C8qu3131 = Parameter(name = 'C8qu3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu3131}}',
                     lhablock = 'D6',
                     lhacode = [ 467 ])

C8qu3232 = Parameter(name = 'C8qu3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qu3232}}',
                     lhablock = 'D6',
                     lhacode = [ 468 ])

C1qd1111 = Parameter(name = 'C1qd1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd1111}}',
                     lhablock = 'D6',
                     lhacode = [ 469 ])

C1qd2222 = Parameter(name = 'C1qd2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd2222}}',
                     lhablock = 'D6',
                     lhacode = [ 470 ])

C1qd3333 = Parameter(name = 'C1qd3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd3333}}',
                     lhablock = 'D6',
                     lhacode = [ 471 ])

C1qd1122 = Parameter(name = 'C1qd1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd1122}}',
                     lhablock = 'D6',
                     lhacode = [ 472 ])

C1qd1133 = Parameter(name = 'C1qd1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd1133}}',
                     lhablock = 'D6',
                     lhacode = [ 473 ])

C1qd2233 = Parameter(name = 'C1qd2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd2233}}',
                     lhablock = 'D6',
                     lhacode = [ 474 ])

C1qd2211 = Parameter(name = 'C1qd2211',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd2211}}',
                     lhablock = 'D6',
                     lhacode = [ 475 ])

C1qd3311 = Parameter(name = 'C1qd3311',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd3311}}',
                     lhablock = 'D6',
                     lhacode = [ 476 ])

C1qd3322 = Parameter(name = 'C1qd3322',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd3322}}',
                     lhablock = 'D6',
                     lhacode = [ 477 ])

C1qd1221 = Parameter(name = 'C1qd1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd1221}}',
                     lhablock = 'D6',
                     lhacode = [ 478 ])

C1qd2112 = Parameter(name = 'C1qd2112',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd2112}}',
                     lhablock = 'D6',
                     lhacode = [ 479 ])

C1qd1331 = Parameter(name = 'C1qd1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd1331}}',
                     lhablock = 'D6',
                     lhacode = [ 480 ])

C1qd3113 = Parameter(name = 'C1qd3113',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd3113}}',
                     lhablock = 'D6',
                     lhacode = [ 481 ])

C1qd2332 = Parameter(name = 'C1qd2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd2332}}',
                     lhablock = 'D6',
                     lhacode = [ 482 ])

C1qd3223 = Parameter(name = 'C1qd3223',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd3223}}',
                     lhablock = 'D6',
                     lhacode = [ 483 ])

C1qd1212 = Parameter(name = 'C1qd1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd1212}}',
                     lhablock = 'D6',
                     lhacode = [ 484 ])

C1qd1313 = Parameter(name = 'C1qd1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd1313}}',
                     lhablock = 'D6',
                     lhacode = [ 485 ])

C1qd2323 = Parameter(name = 'C1qd2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd2323}}',
                     lhablock = 'D6',
                     lhacode = [ 486 ])

C1qd2121 = Parameter(name = 'C1qd2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd2121}}',
                     lhablock = 'D6',
                     lhacode = [ 487 ])

C1qd3131 = Parameter(name = 'C1qd3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd3131}}',
                     lhablock = 'D6',
                     lhacode = [ 488 ])

C1qd3232 = Parameter(name = 'C1qd3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{\\text{qd3232}}',
                     lhablock = 'D6',
                     lhacode = [ 489 ])

C8qd1111 = Parameter(name = 'C8qd1111',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd1111}}',
                     lhablock = 'D6',
                     lhacode = [ 490 ])

C8qd2222 = Parameter(name = 'C8qd2222',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd2222}}',
                     lhablock = 'D6',
                     lhacode = [ 491 ])

C8qd3333 = Parameter(name = 'C8qd3333',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd3333}}',
                     lhablock = 'D6',
                     lhacode = [ 492 ])

C8qd1122 = Parameter(name = 'C8qd1122',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd1122}}',
                     lhablock = 'D6',
                     lhacode = [ 493 ])

C8qd1133 = Parameter(name = 'C8qd1133',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd1133}}',
                     lhablock = 'D6',
                     lhacode = [ 494 ])

C8qd2233 = Parameter(name = 'C8qd2233',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd2233}}',
                     lhablock = 'D6',
                     lhacode = [ 495 ])

C8qd2211 = Parameter(name = 'C8qd2211',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd2211}}',
                     lhablock = 'D6',
                     lhacode = [ 496 ])

C8qd3311 = Parameter(name = 'C8qd3311',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd3311}}',
                     lhablock = 'D6',
                     lhacode = [ 497 ])

C8qd3322 = Parameter(name = 'C8qd3322',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd3322}}',
                     lhablock = 'D6',
                     lhacode = [ 498 ])

C8qd1221 = Parameter(name = 'C8qd1221',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd1221}}',
                     lhablock = 'D6',
                     lhacode = [ 499 ])

C8qd2112 = Parameter(name = 'C8qd2112',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd2112}}',
                     lhablock = 'D6',
                     lhacode = [ 500 ])

C8qd1331 = Parameter(name = 'C8qd1331',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd1331}}',
                     lhablock = 'D6',
                     lhacode = [ 501 ])

C8qd3113 = Parameter(name = 'C8qd3113',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd3113}}',
                     lhablock = 'D6',
                     lhacode = [ 502 ])

C8qd2332 = Parameter(name = 'C8qd2332',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd2332}}',
                     lhablock = 'D6',
                     lhacode = [ 503 ])

C8qd3223 = Parameter(name = 'C8qd3223',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd3223}}',
                     lhablock = 'D6',
                     lhacode = [ 504 ])

C8qd1212 = Parameter(name = 'C8qd1212',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd1212}}',
                     lhablock = 'D6',
                     lhacode = [ 505 ])

C8qd1313 = Parameter(name = 'C8qd1313',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd1313}}',
                     lhablock = 'D6',
                     lhacode = [ 506 ])

C8qd2323 = Parameter(name = 'C8qd2323',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd2323}}',
                     lhablock = 'D6',
                     lhacode = [ 507 ])

C8qd2121 = Parameter(name = 'C8qd2121',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd2121}}',
                     lhablock = 'D6',
                     lhacode = [ 508 ])

C8qd3131 = Parameter(name = 'C8qd3131',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd3131}}',
                     lhablock = 'D6',
                     lhacode = [ 509 ])

C8qd3232 = Parameter(name = 'C8qd3232',
                     nature = 'external',
                     type = 'real',
                     value = 0,
                     texname = 'C_{8 \\text{qd3232}}',
                     lhablock = 'D6',
                     lhacode = [ 510 ])

ReCduq = Parameter(name = 'ReCduq',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{ReC}_{\\text{duq}}',
                   lhablock = 'D6',
                   lhacode = [ 511 ])

ImCduq = Parameter(name = 'ImCduq',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{ImC}_{\\text{duq}}',
                   lhablock = 'D6',
                   lhacode = [ 512 ])

ReCqqu = Parameter(name = 'ReCqqu',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{ReC}_{\\text{qqu}}',
                   lhablock = 'D6',
                   lhacode = [ 513 ])

ImCqqu = Parameter(name = 'ImCqqu',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{ImC}_{\\text{qqu}}',
                   lhablock = 'D6',
                   lhacode = [ 514 ])

ReC1qqq = Parameter(name = 'ReC1qqq',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{Subsuperscript}[\\text{ReC},\\text{qqu},\\text{(1)}]',
                    lhablock = 'D6',
                    lhacode = [ 515 ])

ImC1qqq = Parameter(name = 'ImC1qqq',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{Subsuperscript}[\\text{ImC},\\text{qqu},\\text{(1)}]',
                    lhablock = 'D6',
                    lhacode = [ 516 ])

ReC3qqq = Parameter(name = 'ReC3qqq',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{Subsuperscript}[\\text{ReC},\\text{qqu},\\text{(3)}]',
                    lhablock = 'D6',
                    lhacode = [ 517 ])

ImC3qqq = Parameter(name = 'ImC3qqq',
                    nature = 'external',
                    type = 'real',
                    value = 0,
                    texname = '\\text{Subsuperscript}[\\text{ImC},\\text{qqu},\\text{(3)}]',
                    lhablock = 'D6',
                    lhacode = [ 518 ])

ReCduu = Parameter(name = 'ReCduu',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{ReC}_{\\text{duu}}',
                   lhablock = 'D6',
                   lhacode = [ 519 ])

ImCduu = Parameter(name = 'ImCduu',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{ImC}_{\\text{duu}}',
                   lhablock = 'D6',
                   lhacode = [ 520 ])

ReCnunu = Parameter(name = 'ReCnunu',
                    nature = 'external',
                    type = 'real',
                    value = 1,
                    texname = '\\text{ReC}_{\\nu \\nu }',
                    lhablock = 'D6',
                    lhacode = [ 521 ])

ImCnunu = Parameter(name = 'ImCnunu',
                    nature = 'external',
                    type = 'real',
                    value = 1,
                    texname = '\\text{ImC}_{\\nu \\nu }',
                    lhablock = 'D6',
                    lhacode = [ 522 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 127.9,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.0000116637,
               texname = 'G_f',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.1184,
               texname = '\\alpha _s',
               lhablock = 'SMINPUTS',
               lhacode = [ 3 ])

ymdo = Parameter(name = 'ymdo',
                 nature = 'external',
                 type = 'real',
                 value = 0.00504,
                 texname = '\\text{ymdo}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 1 ])

ymup = Parameter(name = 'ymup',
                 nature = 'external',
                 type = 'real',
                 value = 0.00255,
                 texname = '\\text{ymup}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 2 ])

yms = Parameter(name = 'yms',
                nature = 'external',
                type = 'real',
                value = 0.101,
                texname = '\\text{yms}',
                lhablock = 'YUKAWA',
                lhacode = [ 3 ])

ymc = Parameter(name = 'ymc',
                nature = 'external',
                type = 'real',
                value = 1.27,
                texname = '\\text{ymc}',
                lhablock = 'YUKAWA',
                lhacode = [ 4 ])

ymb = Parameter(name = 'ymb',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = '\\text{ymb}',
                lhablock = 'YUKAWA',
                lhacode = [ 5 ])

ymt = Parameter(name = 'ymt',
                nature = 'external',
                type = 'real',
                value = 172,
                texname = '\\text{ymt}',
                lhablock = 'YUKAWA',
                lhacode = [ 6 ])

yme = Parameter(name = 'yme',
                nature = 'external',
                type = 'real',
                value = 0.000511,
                texname = '\\text{yme}',
                lhablock = 'YUKAWA',
                lhacode = [ 11 ])

ymm = Parameter(name = 'ymm',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{ymm}',
                lhablock = 'YUKAWA',
                lhacode = [ 13 ])

ymtau = Parameter(name = 'ymtau',
                  nature = 'external',
                  type = 'real',
                  value = 1.777,
                  texname = '\\text{ymtau}',
                  lhablock = 'YUKAWA',
                  lhacode = [ 15 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

Me = Parameter(name = 'Me',
               nature = 'external',
               type = 'real',
               value = 0.000511,
               texname = '\\text{Me}',
               lhablock = 'MASS',
               lhacode = [ 11 ])

MMU = Parameter(name = 'MMU',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{MMU}',
                lhablock = 'MASS',
                lhacode = [ 13 ])

MTA = Parameter(name = 'MTA',
                nature = 'external',
                type = 'real',
                value = 1.777,
                texname = '\\text{MTA}',
                lhablock = 'MASS',
                lhacode = [ 15 ])

MU = Parameter(name = 'MU',
               nature = 'external',
               type = 'real',
               value = 0.00255,
               texname = 'M',
               lhablock = 'MASS',
               lhacode = [ 2 ])

MC = Parameter(name = 'MC',
               nature = 'external',
               type = 'real',
               value = 1.27,
               texname = '\\text{MC}',
               lhablock = 'MASS',
               lhacode = [ 4 ])

MT = Parameter(name = 'MT',
               nature = 'external',
               type = 'real',
               value = 172,
               texname = '\\text{MT}',
               lhablock = 'MASS',
               lhacode = [ 6 ])

MD = Parameter(name = 'MD',
               nature = 'external',
               type = 'real',
               value = 0.00504,
               texname = '\\text{MD}',
               lhablock = 'MASS',
               lhacode = [ 1 ])

MS = Parameter(name = 'MS',
               nature = 'external',
               type = 'real',
               value = 0.101,
               texname = '\\text{MS}',
               lhablock = 'MASS',
               lhacode = [ 3 ])

MB = Parameter(name = 'MB',
               nature = 'external',
               type = 'real',
               value = 4.7,
               texname = '\\text{MB}',
               lhablock = 'MASS',
               lhacode = [ 5 ])

MH = Parameter(name = 'MH',
               nature = 'external',
               type = 'real',
               value = 125,
               texname = '\\text{MH}',
               lhablock = 'MASS',
               lhacode = [ 25 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.50833649,
               texname = '\\text{WT}',
               lhablock = 'DECAY',
               lhacode = [ 6 ])

WH = Parameter(name = 'WH',
               nature = 'external',
               type = 'real',
               value = 0.00407,
               texname = '\\text{WH}',
               lhablock = 'DECAY',
               lhacode = [ 25 ])

Cnunu = Parameter(name = 'Cnunu',
                  nature = 'internal',
                  type = 'complex',
                  value = 'ImCnunu + ReCnunu',
                  texname = 'C_{\\nu \\nu }')

Cledq = Parameter(name = 'Cledq',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*ImCledq + ReCledq',
                  texname = 'C_{\\text{ledq}}')

C1lequ = Parameter(name = 'C1lequ',
                   nature = 'internal',
                   type = 'complex',
                   value = 'complex(0,1)*ImC1lequ + ReC1lequ',
                   texname = '\\text{Subsuperscript}[C,\\text{lequ},\\text{(1)}]')

C3lequ = Parameter(name = 'C3lequ',
                   nature = 'internal',
                   type = 'complex',
                   value = 'complex(0,1)*ImC3lequ + ReC3lequ',
                   texname = '\\text{Subsuperscript}[C,\\text{lequ},\\text{(3)}]')

Cduq = Parameter(name = 'Cduq',
                 nature = 'internal',
                 type = 'complex',
                 value = 'complex(0,1)*ImCduq + ReCduq',
                 texname = 'C_{\\text{duq}}')

Cqqu = Parameter(name = 'Cqqu',
                 nature = 'internal',
                 type = 'complex',
                 value = 'complex(0,1)*ImCqqu + ReCqqu',
                 texname = 'C_{\\text{qqu}}')

C1qqq = Parameter(name = 'C1qqq',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*ImC1qqq + ReC1qqq',
                  texname = '\\text{Subsuperscript}[C,\\text{qqq},\\text{(1)}]')

C3qqq = Parameter(name = 'C3qqq',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*ImC3qqq + ReC3qqq',
                  texname = '\\text{Subsuperscript}[C,\\text{qqq},\\text{(3)}]')

Cduu = Parameter(name = 'Cduu',
                 nature = 'internal',
                 type = 'complex',
                 value = 'complex(0,1)*ImCduu + ReCduu',
                 texname = 'C_{\\text{duu}}')

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\alpha _{\\text{EW}}')

vevT = Parameter(name = 'vevT',
                 nature = 'internal',
                 type = 'real',
                 value = '(-(Cll1221*delta) - Cll2112*delta + 2*delta*(ReC3Phil11 + ReC3Phil22))/(4.*2**0.75*Gf**1.5) + 1/(2**0.25*cmath.sqrt(Gf))',
                 texname = 'v_T')

gsD6 = Parameter(name = 'gsD6',
                 nature = 'internal',
                 type = 'real',
                 value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)',
                 texname = 'g_{\\text{sD6}}')

CKMD61x1 = Parameter(name = 'CKMD61x1',
                     nature = 'internal',
                     type = 'complex',
                     value = 'cmath.cos(cabi)',
                     texname = '\\text{CKMD61x1}')

CKMD61x2 = Parameter(name = 'CKMD61x2',
                     nature = 'internal',
                     type = 'complex',
                     value = 'cmath.sin(cabi)',
                     texname = '\\text{CKMD61x2}')

CKMD61x3 = Parameter(name = 'CKMD61x3',
                     nature = 'internal',
                     type = 'complex',
                     value = '0',
                     texname = '\\text{CKMD61x3}')

CKMD62x1 = Parameter(name = 'CKMD62x1',
                     nature = 'internal',
                     type = 'complex',
                     value = '-cmath.sin(cabi)',
                     texname = '\\text{CKMD62x1}')

CKMD62x2 = Parameter(name = 'CKMD62x2',
                     nature = 'internal',
                     type = 'complex',
                     value = 'cmath.cos(cabi)',
                     texname = '\\text{CKMD62x2}')

CKMD62x3 = Parameter(name = 'CKMD62x3',
                     nature = 'internal',
                     type = 'complex',
                     value = '0',
                     texname = '\\text{CKMD62x3}')

CKMD63x1 = Parameter(name = 'CKMD63x1',
                     nature = 'internal',
                     type = 'complex',
                     value = '0',
                     texname = '\\text{CKMD63x1}')

CKMD63x2 = Parameter(name = 'CKMD63x2',
                     nature = 'internal',
                     type = 'complex',
                     value = '0',
                     texname = '\\text{CKMD63x2}')

CKMD63x3 = Parameter(name = 'CKMD63x3',
                     nature = 'internal',
                     type = 'complex',
                     value = '1',
                     texname = '\\text{CKMD63x3}')

CBkin = Parameter(name = 'CBkin',
                  nature = 'internal',
                  type = 'real',
                  value = '-2*CPhiB*delta*vevT**2',
                  texname = 'C_{\\text{Bkin}}')

CG0kin = Parameter(name = 'CG0kin',
                   nature = 'internal',
                   type = 'real',
                   value = '-(CPhiD*delta*vevT**2)/4.',
                   texname = 'C_{\\text{G0kin}}')

CGkin = Parameter(name = 'CGkin',
                  nature = 'internal',
                  type = 'real',
                  value = '-2*CPhiG*delta*vevT**2',
                  texname = 'C_{\\text{Gkin}}')

CHkin = Parameter(name = 'CHkin',
                  nature = 'internal',
                  type = 'real',
                  value = '(-CPhiD/4. + CPhiDAl)*delta*vevT**2',
                  texname = 'C_{\\text{Hkin}}')

CWkin = Parameter(name = 'CWkin',
                  nature = 'internal',
                  type = 'real',
                  value = '-2*CPhiW*delta*vevT**2',
                  texname = 'C_{\\text{Wkin}}')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEW)*cmath.sqrt(cmath.pi)',
               texname = 'e')

g1D6 = Parameter(name = 'g1D6',
                 nature = 'internal',
                 type = 'real',
                 value = 're(8*cmath.sqrt((MZ**2 - cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2))/vevT**2) + (vevT*(-MZ**2 + 4*aEW*cmath.pi*vevT**2 + cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2))*(CPhiD*delta*vevT*cmath.sqrt((MZ**2 - cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2))/vevT**2) + 4*CPhiWB*delta*cmath.sqrt(MZ**2 + cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2))))/(MZ**2 - 4*aEW*cmath.pi*vevT**2))/(4.*cmath.sqrt(2))',
                 texname = 'g_{\\text{D6}}')

gwD6 = Parameter(name = 'gwD6',
                 nature = 'internal',
                 type = 'real',
                 value = 're((8*cmath.sqrt(MZ**2 + cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2)) + (4*aEW*cmath.pi*vevT**4*cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2)*(4*CPhiWB*delta*vevT*cmath.sqrt((MZ**2 - cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2))/vevT**2) + CPhiD*delta*cmath.sqrt(MZ**2 + cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2))))/((MZ**2 - 4*aEW*cmath.pi*vevT**2)*(-MZ**2 + cmath.sqrt(MZ**4 - 4*aEW*cmath.pi*MZ**2*vevT**2))))/vevT)/(4.*cmath.sqrt(2))',
                 texname = 'g_{\\text{wD6}}')

cwD6 = Parameter(name = 'cwD6',
                 nature = 'internal',
                 type = 'real',
                 value = '(gwD6*(1 - (CPhiWB*delta*g1D6*gwD6*vevT**2)/(g1D6**2 + gwD6**2)))/cmath.sqrt(g1D6**2 + gwD6**2)',
                 texname = 'c_{\\text{wD6}}')

MW = Parameter(name = 'MW',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(gwD6**2*vevT**2)/2.',
               texname = 'M_W')

swD6 = Parameter(name = 'swD6',
                 nature = 'internal',
                 type = 'real',
                 value = '(g1D6*(1 + (CPhiWB*delta*gwD6**3*vevT**2)/(g1D6*(g1D6**2 + gwD6**2))))/cmath.sqrt(g1D6**2 + gwD6**2)',
                 texname = 's_{\\text{wD6}}')

g1 = Parameter(name = 'g1',
               nature = 'internal',
               type = 'real',
               value = '(1 + CBkin/2.)*g1D6',
               texname = 'g_1')

gs = Parameter(name = 'gs',
               nature = 'internal',
               type = 'real',
               value = '(1 + CGkin/2.)*gsD6',
               texname = 'g_s')

gw = Parameter(name = 'gw',
               nature = 'internal',
               type = 'real',
               value = '(1 + CWkin/2.)*gwD6',
               texname = 'g_w')

lam = Parameter(name = 'lam',
                nature = 'internal',
                type = 'real',
                value = '(Gf*MH**2*(Cll1221*delta + Cll2112*delta - 2*delta*ReC3Phil11 - 2*delta*ReC3Phil22) + 3*CPhi*delta*cmath.sqrt(2) + 2*(1 - 2*CHkin)*Gf**2*MH**2*cmath.sqrt(2))/(4.*Gf)',
                texname = '\\text{lam}')

ybD6 = Parameter(name = 'ybD6',
                 nature = 'internal',
                 type = 'complex',
                 value = '-(delta*(complex(0,1)*ImCdPhi33 + ReCdPhi33)*vevT**2) + ((1 + CHkin)*ymb*cmath.sqrt(2))/vevT',
                 texname = '\\text{ybD6}')

ycD6 = Parameter(name = 'ycD6',
                 nature = 'internal',
                 type = 'complex',
                 value = '-(delta*(complex(0,1)*ImCuPhi22 + ReCuPhi22)*vevT**2) + ((1 + CHkin)*ymc*cmath.sqrt(2))/vevT',
                 texname = '\\text{ycD6}')

ydoD6 = Parameter(name = 'ydoD6',
                  nature = 'internal',
                  type = 'complex',
                  value = '-(delta*(complex(0,1)*ImCdPhi11 + ReCdPhi11)*vevT**2) + ((1 + CHkin)*ymdo*cmath.sqrt(2))/vevT',
                  texname = '\\text{ydoD6}')

yeD6 = Parameter(name = 'yeD6',
                 nature = 'internal',
                 type = 'complex',
                 value = '-(delta*(complex(0,1)*ImCePhi11 + ReCePhi11)*vevT**2) + ((1 + CHkin)*yme*cmath.sqrt(2))/vevT',
                 texname = '\\text{yeD6}')

ysD6 = Parameter(name = 'ysD6',
                 nature = 'internal',
                 type = 'complex',
                 value = '-(delta*(complex(0,1)*ImCdPhi22 + ReCdPhi22)*vevT**2) + ((1 + CHkin)*yms*cmath.sqrt(2))/vevT',
                 texname = '\\text{ysD6}')

ytauD6 = Parameter(name = 'ytauD6',
                   nature = 'internal',
                   type = 'complex',
                   value = '-((delta*(complex(0,1)*ImCePhi33 + ReCePhi33)*vevT**2)/cmath.sqrt(2)) + ((1 + CHkin)*ymtau*cmath.sqrt(2))/vevT',
                   texname = '\\text{ytauD6}')

ytD6 = Parameter(name = 'ytD6',
                 nature = 'internal',
                 type = 'complex',
                 value = '-(delta*(complex(0,1)*ImCuPhi33 + ReCuPhi33)*vevT**2) + ((1 + CHkin)*ymt*cmath.sqrt(2))/vevT',
                 texname = '\\text{ytD6}')

yupD6 = Parameter(name = 'yupD6',
                  nature = 'internal',
                  type = 'complex',
                  value = '-(delta*(complex(0,1)*ImCuPhi11 + ReCuPhi11)*vevT**2) + ((1 + CHkin)*ymup*cmath.sqrt(2))/vevT',
                  texname = '\\text{yupD6}')

swD62 = Parameter(name = 'swD62',
                  nature = 'internal',
                  type = 'real',
                  value = 'swD6**2',
                  texname = '\\text{swD62}')

W3Bmix11 = Parameter(name = 'W3Bmix11',
                     nature = 'internal',
                     type = 'real',
                     value = 'cwD6*(1 - CWkin/2.)',
                     texname = '\\text{Mix}_{\\text{B11} (\\text{W3}\\&)}')

W3Bmix12 = Parameter(name = 'W3Bmix12',
                     nature = 'internal',
                     type = 'real',
                     value = '(1 - CWkin/2.)*swD6',
                     texname = '\\text{Mix}_{\\text{B12} (\\text{W3}\\&)}')

W3Bmix21 = Parameter(name = 'W3Bmix21',
                     nature = 'internal',
                     type = 'real',
                     value = '((-2 + CBkin)*swD6)/2. - CPhiWB*cwD6*delta*vevT**2',
                     texname = '\\text{Mix}_{\\text{B21} (\\text{W3}\\&)}')

W3Bmix22 = Parameter(name = 'W3Bmix22',
                     nature = 'internal',
                     type = 'real',
                     value = '(1 - CBkin/2.)*cwD6 - CPhiWB*delta*swD6*vevT**2',
                     texname = '\\text{Mix}_{\\text{B22} (\\text{W3}\\&)}')

vev = Parameter(name = 'vev',
                nature = 'internal',
                type = 'real',
                value = 'vevT*(1 - (3*CPhi*delta*vevT**2)/(8.*lam))',
                texname = 'v')

muH = Parameter(name = 'muH',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sqrt(lam*vev**2)',
                texname = '\\mu')

ymD6 = Parameter(name = 'ymD6',
                 nature = 'internal',
                 type = 'complex',
                 value = '-(delta*(complex(0,1)*ImCePhi22 + ReCePhi22)*vev**2) + ((1 + CHkin)*ymm*cmath.sqrt(2))/vevT',
                 texname = '\\text{ymD6}')

